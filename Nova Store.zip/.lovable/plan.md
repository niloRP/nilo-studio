## Escopo

Plano grande com 7 frentes. Vou implementar em fases para manter a loja estável. Confirme antes de começar.

## Fase 1 — Checkout: campo Número obrigatório (rápido, alto impacto)

- Adicionar campos estruturados no checkout: CEP, Rua, **Número (obrigatório)**, Complemento, Bairro, Cidade, UF.
- Auto-buscar CEP → preenche Rua/Bairro/Cidade/UF, foca em "Número", exibe "CEP encontrado. Informe o número da residência."
- Bloquear botão "Gerar Pix" enquanto Número estiver vazio.
- Migration: adicionar em `orders` as colunas `address_zipcode, address_street, address_number, address_complement, address_neighborhood, address_city, address_state` (manter `address` legado por compatibilidade, montado a partir dos campos).
- Mesma validação no fluxo de Endereços salvos (`/conta/enderecos` já tem; revisar consistência).

## Fase 2 — Rastreamento do pedido (timeline)

- Migration: `order_status_history (order_id, status, message, created_at)` + enum com 9 status (criado, pix_gerado, pix_confirmado, separacao, preparando_envio, enviado, em_transporte, saiu_entrega, entregue).
- Triggers: insert automático em `order_status_history` quando `orders.status` muda; webhook VirtualPay grava `pix_confirmado`.
- UI cliente: timeline visual em `/conta/pedidos/$id` com status atual destacado, data/hora e mensagens amigáveis.
- UI admin: dropdown em `admin.pedidos` para avançar status manualmente (separação → envio → entrega).

## Fase 3 — Dashboard admin com métricas

- Server fn `getAdminMetrics`: usuários totais, novos hoje, pedidos hoje, pedidos pagos hoje, faturamento dia/mês.
- Cards no `/admin` (substituindo/complementando o atual).
- Auto-refresh a cada 30s via TanStack Query.

## Fase 4 — Analytics de navegação

- Migration: `page_views (user_id, session_id, path, referrer, user_agent, device, started_at, ended_at, duration_ms)`.
- Hook client: registra view ao entrar na rota + envia `ended_at` no unmount/visibility change.
- Painel admin: páginas mais visitadas, produtos mais vistos, taxa de abandono (checkout sem pix_confirmado), conversão.

## Fase 5 — Logs de auditoria admin

- Migration: `admin_audit_logs (user_id, action, entity, entity_id, metadata, created_at)`.
- Server fn util `logAdminAction()` chamada nas mutações admin (produto, preço, estoque, pedidos, login).
- Tela `/admin/auditoria` com filtros por usuário/ação/data.

## Fase 6 — Tempo real

- Habilitar Realtime nas tabelas `orders`, `page_views`, `admin_audit_logs`.
- Widget "Ao vivo" no `/admin`: usuários online (page_views ativos < 60s), últimos pedidos, últimos logins.

## Confirmação

Esse escopo é grande (≈3 migrations, 10+ arquivos novos). Posso:

**A)** Executar tudo de uma vez (resposta longa, mais risco de regressão).
**B)** Ir fase por fase, você valida cada uma antes da próxima (recomendado).
**C)** Priorizar só as Fases 1+2 agora (correção do número + rastreamento) — que é o que afeta diretamente o cliente final — e fazer 3-6 depois.

Qual prefere?