import { Link, useNavigate } from "@tanstack/react-router";
import { ShoppingBag, BadgeCheck, Heart } from "lucide-react";
import { effectivePrice, formatBRL, type Product } from "@/lib/products";
import { useCart } from "@/lib/cart";
import { useFavorites } from "@/lib/use-favorites";

export function ProductCard({ product }: { product: Product }) {
  const { add, setOpen } = useCart();
  const navigate = useNavigate();
  const fav = useFavorites();
  const isFav = fav.isFavorite(product.id);
  const price = effectivePrice(product);
  const hasPromo = product.promo_price != null && product.promo_price < product.price;
  const discount = hasPromo
    ? Math.round(((product.price - product.promo_price!) / product.price) * 100)
    : 0;

  const specBits = [product.storage, product.ram, product.color].filter(Boolean).join(" · ");

  return (
    <div className="group surface-card relative flex flex-col overflow-hidden rounded-2xl transition-all duration-300 hover:border-border-strong hover:-translate-y-1">
      <Link
        to="/produto/$slug"
        params={{ slug: product.slug }}
        className="relative block aspect-square overflow-hidden bg-surface-elevated"
      >
        <span className="absolute right-3 top-3 z-10 rounded-full bg-background/80 px-2 py-1 text-[9px] font-bold uppercase tracking-wider text-foreground backdrop-blur">
          {product.condition === "seminovo" ? "Seminovo" : "Novo"}
        </span>
        {product.badge && (
          <span className="absolute left-3 top-3 z-10 rounded-full bg-primary px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
            {product.badge}
          </span>
        )}
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110"
        />
        <button
          type="button"
          aria-label={isFav ? "Remover dos favoritos" : "Favoritar"}
          onClick={(e) => {
            e.preventDefault();
            e.stopPropagation();
            if (!fav.isLoggedIn) {
              navigate({ to: "/auth" });
              return;
            }
            fav.toggle(product.id);
          }}
          className={`absolute bottom-3 right-3 z-10 grid h-9 w-9 place-items-center rounded-full backdrop-blur transition-all ${
            isFav
              ? "bg-destructive/90 text-destructive-foreground"
              : "bg-background/80 text-muted-foreground hover:text-foreground"
          }`}
        >
          <Heart className={`h-4 w-4 ${isFav ? "fill-current" : ""}`} />
        </button>
      </Link>

      <div className="flex flex-1 flex-col gap-2 p-4">
        <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
          <span>{product.brand ?? "—"}</span>
          {product.condition === "novo" && (
            <span className="flex items-center gap-1 text-primary">
              <BadgeCheck className="h-3 w-3" />
              Lacrado
            </span>
          )}
        </div>

        <Link
          to="/produto/$slug"
          params={{ slug: product.slug }}
          className="line-clamp-2 font-display text-base font-semibold leading-tight text-foreground transition-colors hover:text-primary"
        >
          {product.name}
        </Link>

        {specBits && (
          <p className="line-clamp-1 text-xs text-muted-foreground">{specBits}</p>
        )}

        <div className="mt-auto pt-3">
          {hasPromo && (
            <div className="flex items-center gap-2 text-xs">
              <span className="text-muted-foreground line-through">
                {formatBRL(product.price)}
              </span>
              <span className="rounded-md bg-discount/15 px-1.5 py-0.5 font-mono font-semibold text-discount">
                −{discount}%
              </span>
            </div>
          )}
          <div className="mt-1 flex items-end justify-between gap-2">
            <div>
              <div className="font-display text-xl font-bold text-price">
                {formatBRL(price)}
              </div>
              <div className="text-[10px] text-muted-foreground">via Pix</div>
            </div>
            <button
              type="button"
              aria-label="Adicionar ao carrinho"
              disabled={product.stock <= 0}
              onClick={() => {
                add(
                  {
                    id: product.id,
                    slug: product.slug,
                    name: product.name,
                    brand: product.brand,
                    price,
                    image: product.image,
                  },
                  1,
                );
                setOpen(true);
              }}
              className="grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground transition-all hover:bg-primary-glow hover:shadow-[var(--shadow-glow)] active:scale-95 disabled:opacity-40 disabled:cursor-not-allowed"
            >
              <ShoppingBag className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
