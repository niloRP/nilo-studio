import { Link, useNavigate } from "@tanstack/react-router";
import {
  ShoppingBag,
  Menu,
  Smartphone,
  LayoutDashboard,
  User as UserIcon,
  Heart,
  MapPin,
  Settings as SettingsIcon,
  LogOut,
  ChevronDown,
} from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { useCart } from "@/lib/cart";
import { useAuth } from "@/lib/use-auth";
import { useProfile } from "@/lib/use-profile";
import { useStoreSettings } from "@/lib/use-store-settings";
import { supabase } from "@/integrations/supabase/client";

const CATEGORIES = [
  { slug: "iphone", name: "iPhone" },
  { slug: "xiaomi", name: "Xiaomi" },
] as const;

export function Header() {
  const navigate = useNavigate();
  const { count, setOpen } = useCart();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const settings = useStoreSettings();
  const [menuOpen, setMenuOpen] = useState(false);
  const [userMenuOpen, setUserMenuOpen] = useState(false);
  const userMenuRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!userMenuOpen) return;
    const handler = (e: MouseEvent) => {
      if (!userMenuRef.current?.contains(e.target as Node)) setUserMenuOpen(false);
    };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, [userMenuOpen]);

  const initial = (profile?.name ?? user?.email ?? "U").trim().charAt(0).toUpperCase();
  const displayName =
    profile?.name?.split(" ")[0] ?? user?.user_metadata?.name?.split(" ")[0] ?? "Conta";

  const signOut = async () => {
    setUserMenuOpen(false);
    await supabase.auth.signOut();
    navigate({ to: "/" });
  };

  const userLinks = [
    { to: "/conta", label: "Minha Conta", icon: UserIcon },
    { to: "/conta/pedidos", label: "Meus Pedidos", icon: ShoppingBag },
    { to: "/conta/enderecos", label: "Endereços", icon: MapPin },
    { to: "/conta/favoritos", label: "Favoritos", icon: Heart },
    { to: "/conta/configuracoes", label: "Configurações", icon: SettingsIcon },
  ];

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-xl">
      <div className="mx-auto flex h-16 max-w-7xl items-center gap-4 px-4 md:px-6">
        <button
          type="button"
          className="md:hidden -ml-1 grid h-9 w-9 place-items-center rounded-lg text-foreground hover:bg-surface"
          onClick={() => setMenuOpen((v) => !v)}
          aria-label="Menu"
        >
          <Menu className="h-5 w-5" />
        </button>

        <Link to="/" className="flex items-center gap-2">
          {settings.logo_url ? (
            <img
              src={settings.logo_url}
              alt={settings.store_name}
              className="h-8 w-8 rounded-lg object-cover"
            />
          ) : (
            <div className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground shadow-[var(--shadow-glow)]">
              <Smartphone className="h-4 w-4" />
            </div>
          )}
          <span className="font-display text-lg font-bold tracking-tight">
            {settings.store_name}
          </span>
        </Link>

        <nav className="hidden flex-1 items-center gap-1 md:flex">
          {CATEGORIES.map((c) => (
            <a
              key={c.slug}
              href={`/#cat-${c.slug}`}
              className="rounded-lg px-3 py-1.5 text-sm text-muted-foreground transition-colors hover:bg-surface hover:text-foreground"
            >
              {c.name}
            </a>
          ))}
        </nav>

        <div className="ml-auto flex items-center gap-2">
          {user ? (
            <div ref={userMenuRef} className="relative">
              <button
                type="button"
                onClick={() => setUserMenuOpen((v) => !v)}
                className="inline-flex items-center gap-2 rounded-xl border border-border bg-surface px-2 py-1.5 text-xs font-semibold text-foreground hover:bg-surface-elevated"
              >
                {profile?.avatar_url ? (
                  <img
                    src={profile.avatar_url}
                    alt=""
                    className="h-7 w-7 rounded-lg object-cover"
                  />
                ) : (
                  <span className="grid h-7 w-7 place-items-center rounded-lg bg-primary text-[11px] font-bold text-primary-foreground">
                    {initial}
                  </span>
                )}
                <span className="hidden max-w-[100px] truncate md:inline">{displayName}</span>
                <ChevronDown className="h-3 w-3 text-muted-foreground" />
              </button>

              {userMenuOpen && (
                <div className="absolute right-0 top-full z-50 mt-2 w-60 overflow-hidden rounded-2xl border border-border bg-surface shadow-xl">
                  <div className="border-b border-border p-3">
                    <div className="truncate font-display text-sm font-semibold">
                      {profile?.name ?? "Cliente"}
                    </div>
                    <div className="truncate text-[11px] text-muted-foreground">
                      {profile?.email ?? user.email}
                    </div>
                  </div>
                  <nav className="p-1.5">
                    {userLinks.map((l) => (
                      <Link
                        key={l.to}
                        to={l.to}
                        onClick={() => setUserMenuOpen(false)}
                        className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-muted-foreground hover:bg-surface-elevated hover:text-foreground"
                      >
                        <l.icon className="h-4 w-4" />
                        {l.label}
                      </Link>
                    ))}
                    <Link
                      to="/admin"
                      onClick={() => setUserMenuOpen(false)}
                      className="flex items-center gap-2 rounded-lg px-3 py-2 text-sm text-muted-foreground hover:bg-surface-elevated hover:text-foreground"
                    >
                      <LayoutDashboard className="h-4 w-4" />
                      Painel admin
                    </Link>
                    <button
                      onClick={signOut}
                      className="flex w-full items-center gap-2 rounded-lg px-3 py-2 text-sm text-muted-foreground hover:bg-surface-elevated hover:text-foreground"
                    >
                      <LogOut className="h-4 w-4" />
                      Sair
                    </button>
                  </nav>
                </div>
              )}
            </div>
          ) : (
            <Link
              to="/auth"
              className="inline-flex items-center gap-1.5 rounded-xl border border-border bg-surface px-3 py-2 text-xs font-semibold text-muted-foreground hover:text-foreground"
            >
              Entrar
            </Link>
          )}
          <button
            type="button"
            aria-label="Carrinho"
            onClick={() => setOpen(true)}
            className="relative grid h-10 w-10 place-items-center rounded-xl border border-border bg-surface text-foreground transition-colors hover:border-border-strong hover:bg-surface-elevated"
          >
            <ShoppingBag className="h-4 w-4" />
            {count > 0 && (
              <span className="absolute -right-1.5 -top-1.5 grid h-5 min-w-5 place-items-center rounded-full bg-primary px-1 font-mono text-[10px] font-bold text-primary-foreground">
                {count}
              </span>
            )}
          </button>
        </div>
      </div>

      {menuOpen && (
        <div className="border-t border-border bg-background md:hidden">
          <nav className="flex flex-col p-2">
            {CATEGORIES.map((c) => (
              <a
                key={c.slug}
                href={`/#cat-${c.slug}`}
                onClick={() => setMenuOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm text-muted-foreground hover:bg-surface hover:text-foreground"
              >
                {c.name}
              </a>
            ))}
            {user ? (
              <>
                <Link
                  to="/conta"
                  onClick={() => setMenuOpen(false)}
                  className="rounded-lg px-3 py-2.5 text-sm font-semibold text-primary hover:bg-surface"
                >
                  Minha conta
                </Link>
                <Link
                  to="/admin"
                  onClick={() => setMenuOpen(false)}
                  className="rounded-lg px-3 py-2.5 text-sm text-muted-foreground hover:bg-surface"
                >
                  Painel admin
                </Link>
              </>
            ) : (
              <Link
                to="/auth"
                onClick={() => setMenuOpen(false)}
                className="rounded-lg px-3 py-2.5 text-sm font-semibold text-primary hover:bg-surface"
              >
                Entrar
              </Link>
            )}
          </nav>
        </div>
      )}
    </header>
  );
}
