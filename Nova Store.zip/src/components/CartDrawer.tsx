import { Link } from "@tanstack/react-router";
import { X, Trash2, Minus, Plus, ShoppingBag } from "lucide-react";
import { useCart } from "@/lib/cart";
import { formatBRL } from "@/lib/products";

export function CartDrawer() {
  const { isOpen, setOpen, detailed, total, setQty, remove, count } = useCart();

  return (
    <>
      <div
        className={`fixed inset-0 z-50 bg-background/70 backdrop-blur-sm transition-opacity ${
          isOpen ? "opacity-100" : "pointer-events-none opacity-0"
        }`}
        onClick={() => setOpen(false)}
      />
      <aside
        className={`fixed right-0 top-0 z-50 flex h-dvh w-full max-w-md flex-col border-l border-border bg-surface shadow-2xl transition-transform duration-300 ${
          isOpen ? "translate-x-0" : "translate-x-full"
        }`}
        aria-hidden={!isOpen}
      >
        <header className="flex items-center justify-between border-b border-border px-5 py-4">
          <div>
            <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
              Seu carrinho
            </div>
            <div className="font-display text-lg font-semibold">
              {count} {count === 1 ? "item" : "itens"}
            </div>
          </div>
          <button
            type="button"
            onClick={() => setOpen(false)}
            aria-label="Fechar"
            className="grid h-9 w-9 place-items-center rounded-lg text-muted-foreground hover:bg-surface-elevated hover:text-foreground"
          >
            <X className="h-4 w-4" />
          </button>
        </header>

        <div className="flex-1 overflow-y-auto px-5 py-4">
          {detailed.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center gap-3 text-center">
              <div className="grid h-16 w-16 place-items-center rounded-2xl bg-surface-elevated text-muted-foreground">
                <ShoppingBag className="h-7 w-7" />
              </div>
              <p className="font-display text-base font-medium">
                Seu carrinho está vazio
              </p>
              <p className="max-w-xs text-sm text-muted-foreground">
                Confira nossos iPhones e Xiaomi disponíveis.
              </p>
              <button
                type="button"
                onClick={() => setOpen(false)}
                className="mt-2 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary-glow"
              >
                Explorar produtos
              </button>
            </div>
          ) : (
            <ul className="flex flex-col gap-3">
              {detailed.map(({ product, qty, subtotal }) => (
                <li
                  key={product.id}
                  className="flex gap-3 rounded-xl border border-border bg-surface-elevated p-3"
                >
                  <img
                    src={product.image}
                    alt={product.name}
                    className="h-20 w-20 shrink-0 rounded-lg object-cover"
                  />
                  <div className="flex flex-1 flex-col">
                    <div className="flex justify-between gap-2">
                      <div>
                        <div className="text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
                          {product.brand}
                        </div>
                        <div className="line-clamp-2 text-sm font-medium leading-tight">
                          {product.name}
                        </div>
                      </div>
                      <button
                        type="button"
                        onClick={() => remove(product.id)}
                        aria-label="Remover"
                        className="text-muted-foreground hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                    <div className="mt-auto flex items-end justify-between pt-2">
                      <div className="flex items-center rounded-lg border border-border">
                        <button
                          type="button"
                          onClick={() => setQty(product.id, qty - 1)}
                          className="grid h-7 w-7 place-items-center text-muted-foreground hover:text-foreground"
                          aria-label="Diminuir"
                        >
                          <Minus className="h-3 w-3" />
                        </button>
                        <span className="w-7 text-center font-mono text-sm">{qty}</span>
                        <button
                          type="button"
                          onClick={() => setQty(product.id, qty + 1)}
                          className="grid h-7 w-7 place-items-center text-muted-foreground hover:text-foreground"
                          aria-label="Aumentar"
                        >
                          <Plus className="h-3 w-3" />
                        </button>
                      </div>
                      <div className="font-display text-sm font-semibold">
                        {formatBRL(subtotal)}
                      </div>
                    </div>
                  </div>
                </li>
              ))}
            </ul>
          )}
        </div>

        {detailed.length > 0 && (
          <footer className="border-t border-border bg-surface px-5 py-4">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                  Total via Pix
                </div>
                <div className="font-display text-2xl font-bold text-price">
                  {formatBRL(total)}
                </div>
              </div>
              <div className="rounded-lg bg-discount/15 px-2 py-1 font-mono text-[10px] font-semibold uppercase text-discount">
                Pix instantâneo
              </div>
            </div>
            <Link
              to="/checkout"
              onClick={() => setOpen(false)}
              className="flex w-full items-center justify-center rounded-xl bg-primary px-4 py-3 font-display text-sm font-bold text-primary-foreground transition-all hover:bg-primary-glow hover:shadow-[var(--shadow-glow)]"
            >
              Finalizar pedido
            </Link>
          </footer>
        )}
      </aside>
    </>
  );
}
