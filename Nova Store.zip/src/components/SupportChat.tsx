import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { MessageCircle, X, Send, Phone, ShieldCheck } from "lucide-react";
import {
  openConversation,
  sendCustomerMessage,
  pollCustomerMessages,
  getSupportStatus,
  type SupportMessage,
} from "@/lib/support.functions";
import { useStoreSettings } from "@/lib/use-store-settings";

const SESSION_KEY = "iphonesp.support.session";
const STATE_KEY = "iphonesp.support.lead";

function getSessionToken(): string {
  if (typeof window === "undefined") return "";
  let t = localStorage.getItem(SESSION_KEY);
  if (!t) {
    t = (crypto.randomUUID?.() ?? Math.random().toString(36).slice(2) + Date.now()).replace(/-/g, "");
    localStorage.setItem(SESSION_KEY, t);
  }
  return t;
}

type Lead = { name: string; phone: string; email?: string };

const QUICK_OPTIONS: { key: string; label: string; reply: string }[] = [
  {
    key: "produtos",
    label: "📱 Ver produtos",
    reply: "Temos iPhone e Xiaomi com garantia. Role a página inicial para ver todos os modelos disponíveis. Quer indicação de algum modelo específico?",
  },
  {
    key: "pagamento",
    label: "💳 Formas de pagamento",
    reply: "Aceitamos pagamento via Pix com aprovação instantânea e desconto. Após a confirmação, seu pedido é liberado automaticamente.",
  },
  {
    key: "frete",
    label: "🚚 Frete e entrega",
    reply: "Enviamos para todo o Brasil. O prazo e o valor são calculados com base no seu CEP no momento do checkout.",
  },
  {
    key: "confiavel",
    label: "🛡️ Loja confiável",
    reply: "Somos a iPhone SP — loja especializada com CNPJ ativo, nota fiscal, garantia em todos os produtos e milhares de clientes satisfeitos.",
  },
  {
    key: "endereco",
    label: "📍 Endereço da loja",
    reply: "Confira nosso endereço no rodapé do site. Atendimento presencial mediante agendamento prévio.",
  },
  {
    key: "atendente",
    label: "👨‍💼 Falar com atendente",
    reply: "Certo! Vou transferir para um atendente humano. Pode descrever sua dúvida que respondemos o mais rápido possível 👇",
  },
  {
    key: "duvidas",
    label: "❓ Outras dúvidas",
    reply: "Manda sua dúvida aqui que respondemos em instantes 👇",
  },
];

const WELCOME = "Olá! 👋 Seja bem-vindo à iPhone SP. Como podemos ajudar você hoje?";

export function SupportChat() {
  const settings = useStoreSettings();
  const [open, setOpen] = useState(false);
  const [mounted, setMounted] = useState(false);
  const [lead, setLead] = useState<Lead | null>(null);
  const [askingLead, setAskingLead] = useState(false);
  const [leadDraft, setLeadDraft] = useState<Lead>({ name: "", phone: "", email: "" });
  const [messages, setMessages] = useState<(SupportMessage | { id: string; sender: string; content: string; created_at: string })[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const [status, setStatus] = useState<"online" | "away" | "offline">("online");
  const [whatsapp, setWhatsapp] = useState<string | null>(null);
  const [unread, setUnread] = useState(0);
  const [showQuick, setShowQuick] = useState(true);
  const listRef = useRef<HTMLDivElement>(null);
  const lastTsRef = useRef<string | null>(null);
  const sessionToken = useMemo(() => (mounted ? getSessionToken() : ""), [mounted]);

  // Mount + restore lead
  useEffect(() => {
    setMounted(true);
    try {
      const raw = localStorage.getItem(STATE_KEY);
      if (raw) setLead(JSON.parse(raw) as Lead);
    } catch {}
  }, []);

  // Initial welcome
  useEffect(() => {
    if (!mounted) return;
    setMessages([
      { id: "w", sender: "bot", content: WELCOME, created_at: new Date().toISOString() },
    ]);
  }, [mounted]);

  // Fetch global status
  useEffect(() => {
    if (!mounted) return;
    getSupportStatus()
      .then((s) => {
        setStatus(s.status);
        setWhatsapp(s.whatsapp);
      })
      .catch(() => {});
  }, [mounted]);

  // Auto-scroll
  useEffect(() => {
    if (listRef.current) listRef.current.scrollTop = listRef.current.scrollHeight;
  }, [messages, open]);

  // Notification beep
  const beep = useCallback(() => {
    try {
      const AC = (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext);
      if (!AC) return;
      const ctx = new AC();
      const o = ctx.createOscillator();
      const g = ctx.createGain();
      o.frequency.value = 880;
      o.connect(g);
      g.connect(ctx.destination);
      g.gain.value = 0.05;
      o.start();
      setTimeout(() => { o.stop(); ctx.close(); }, 180);
    } catch {}
  }, []);

  // Poll admin replies once conversation exists
  useEffect(() => {
    if (!mounted || !lead || !sessionToken) return;
    let active = true;
    const tick = async () => {
      try {
        const r = await pollCustomerMessages({
          data: { session_token: sessionToken, since: lastTsRef.current ?? undefined },
        });
        if (!active) return;
        if (r.messages.length) {
          let gotAdmin = false;
          setMessages((prev) => {
            const ids = new Set(prev.map((m) => m.id));
            const fresh = r.messages.filter((m) => !ids.has(m.id));
            for (const m of fresh) {
              if (m.sender === "admin") gotAdmin = true;
              lastTsRef.current = m.created_at;
            }
            return [...prev, ...fresh];
          });
          if (gotAdmin) {
            if (!open) setUnread((u) => u + 1);
            beep();
          }
        }
      } catch {}
    };
    tick();
    const id = setInterval(tick, 4000);
    return () => { active = false; clearInterval(id); };
  }, [mounted, lead, sessionToken, open, beep]);

  // Clear unread when opened
  useEffect(() => {
    if (open) setUnread(0);
  }, [open]);

  const ensureLeadOrAsk = (): Lead | null => {
    if (lead) return lead;
    setAskingLead(true);
    return null;
  };

  const persistLead = async (l: Lead) => {
    setLead(l);
    localStorage.setItem(STATE_KEY, JSON.stringify(l));
    try {
      await openConversation({
        data: { session_token: sessionToken, name: l.name, phone: l.phone, email: l.email || null },
      });
    } catch {}
  };

  const sendMessage = async (content: string, sender: "customer" | "bot" = "customer") => {
    const l = sender === "customer" ? ensureLeadOrAsk() : lead;
    if (sender === "customer" && !l) return;
    const local = {
      id: `local-${Date.now()}-${Math.random()}`,
      sender,
      content,
      created_at: new Date().toISOString(),
    };
    setMessages((prev) => [...prev, local]);
    try {
      if (!l && sender === "customer") return;
      // ensure conversation exists
      if (l) await openConversation({ data: { session_token: sessionToken, name: l.name, phone: l.phone, email: l.email || null } });
      await sendCustomerMessage({
        data: { session_token: sessionToken, sender, content },
      });
    } catch {}
  };

  const handleQuick = async (opt: (typeof QUICK_OPTIONS)[number]) => {
    setShowQuick(false);
    setMessages((prev) => [
      ...prev,
      { id: `q-${opt.key}-${Date.now()}`, sender: "customer", content: opt.label, created_at: new Date().toISOString() },
      { id: `b-${opt.key}-${Date.now() + 1}`, sender: "bot", content: opt.reply, created_at: new Date().toISOString() },
    ]);
    if (lead) {
      try {
        await openConversation({ data: { session_token: sessionToken, name: lead.name, phone: lead.phone, email: lead.email || null } });
        await sendCustomerMessage({ data: { session_token: sessionToken, sender: "customer", content: opt.label } });
        await sendCustomerMessage({ data: { session_token: sessionToken, sender: "bot", content: opt.reply } });
      } catch {}
    }
    if (opt.key === "atendente") setAskingLead(!lead);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const text = input.trim();
    if (!text || sending) return;
    setSending(true);
    setInput("");
    setShowQuick(false);
    await sendMessage(text, "customer");
    setSending(false);
  };

  const handleLeadSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (leadDraft.name.trim().length < 2 || leadDraft.phone.replace(/\D/g, "").length < 8) return;
    await persistLead({ ...leadDraft, name: leadDraft.name.trim(), phone: leadDraft.phone.trim() });
    setAskingLead(false);
  };

  const openWhatsapp = () => {
    if (!whatsapp && !settings.whatsapp) return;
    const num = (whatsapp ?? settings.whatsapp ?? "").replace(/\D/g, "");
    const msg = encodeURIComponent(`Olá ${settings.store_name}! Vim do site e gostaria de tirar uma dúvida.`);
    window.open(`https://wa.me/${num}?text=${msg}`, "_blank", "noopener");
  };

  if (!mounted) return null;

  const statusDot =
    status === "online" ? "bg-emerald-500" : status === "away" ? "bg-amber-500" : "bg-zinc-500";
  const statusLabel = status === "online" ? "Online" : status === "away" ? "Ausente" : "Offline";

  return (
    <>
      {/* Floating button */}
      <button
        type="button"
        onClick={() => setOpen((v) => !v)}
        aria-label="Abrir chat de suporte"
        style={{ zIndex: 2147483000 }}
        className="fixed bottom-4 right-4 grid h-14 w-14 place-items-center rounded-full bg-primary text-primary-foreground shadow-2xl shadow-primary/40 transition-transform hover:scale-105 active:scale-95 md:bottom-6 md:right-6 md:h-16 md:w-16"
      >
        {open ? <X className="h-6 w-6" /> : <MessageCircle className="h-6 w-6" />}
        {!open && unread > 0 && (
          <span className="absolute -right-1 -top-1 grid h-6 min-w-6 place-items-center rounded-full bg-destructive px-1 font-mono text-[11px] font-bold text-destructive-foreground">
            {unread}
          </span>
        )}
        <span className={`absolute bottom-1 right-1 h-3 w-3 rounded-full ring-2 ring-background ${statusDot}`} />
      </button>

      {/* Window */}
      {open && (
        <div
          style={{ zIndex: 2147483000 }}
          className="fixed inset-x-2 bottom-20 mx-auto flex max-h-[80vh] w-auto max-w-[420px] flex-col overflow-hidden rounded-3xl border border-border bg-background shadow-2xl sm:right-4 sm:left-auto sm:bottom-24 sm:w-[400px] md:right-6"
        >
          {/* Header */}
          <div className="flex items-center gap-3 border-b border-border bg-surface px-4 py-3">
            <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15 text-primary">
              <ShieldCheck className="h-5 w-5" />
            </div>
            <div className="min-w-0 flex-1">
              <div className="truncate font-display text-sm font-bold">Suporte {settings.store_name}</div>
              <div className="flex items-center gap-1.5 text-[11px] text-muted-foreground">
                <span className={`h-1.5 w-1.5 rounded-full ${statusDot}`} />
                {statusLabel}
              </div>
            </div>
            {(whatsapp || settings.whatsapp) && (
              <button
                type="button"
                onClick={openWhatsapp}
                className="inline-flex items-center gap-1 rounded-lg bg-emerald-500/15 px-2.5 py-1.5 text-[11px] font-semibold text-emerald-500 hover:bg-emerald-500/25"
              >
                <Phone className="h-3 w-3" /> WhatsApp
              </button>
            )}
            <button
              type="button"
              onClick={() => setOpen(false)}
              aria-label="Fechar"
              className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-surface-elevated hover:text-foreground"
            >
              <X className="h-4 w-4" />
            </button>
          </div>

          {/* Messages */}
          <div ref={listRef} className="flex-1 space-y-3 overflow-y-auto bg-background px-3 py-4">
            {messages.map((m) => {
              const isCustomer = m.sender === "customer";
              const isSystem = m.sender === "system";
              if (isSystem) {
                return (
                  <div key={m.id} className="text-center text-[11px] text-muted-foreground">
                    {m.content}
                  </div>
                );
              }
              return (
                <div key={m.id} className={`flex ${isCustomer ? "justify-end" : "justify-start"}`}>
                  <div
                    className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm leading-relaxed ${
                      isCustomer
                        ? "bg-primary text-primary-foreground rounded-br-md"
                        : "bg-surface text-foreground rounded-bl-md border border-border"
                    }`}
                  >
                    {m.content}
                  </div>
                </div>
              );
            })}

            {showQuick && (
              <div className="flex flex-wrap gap-1.5 pt-1">
                {QUICK_OPTIONS.map((o) => (
                  <button
                    key={o.key}
                    type="button"
                    onClick={() => handleQuick(o)}
                    className="rounded-full border border-border bg-surface px-3 py-1.5 text-xs text-foreground transition-colors hover:border-primary hover:text-primary"
                  >
                    {o.label}
                  </button>
                ))}
              </div>
            )}
          </div>

          {/* Lead form */}
          {askingLead && (
            <form onSubmit={handleLeadSubmit} className="space-y-2 border-t border-border bg-surface px-3 py-3">
              <div className="text-[11px] font-mono uppercase tracking-widest text-muted-foreground">
                Antes de continuar
              </div>
              <input
                required
                placeholder="Seu nome"
                value={leadDraft.name}
                onChange={(e) => setLeadDraft({ ...leadDraft, name: e.target.value })}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm"
              />
              <input
                required
                placeholder="WhatsApp / Telefone"
                value={leadDraft.phone}
                onChange={(e) => setLeadDraft({ ...leadDraft, phone: e.target.value })}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm"
              />
              <input
                type="email"
                placeholder="E-mail (opcional)"
                value={leadDraft.email}
                onChange={(e) => setLeadDraft({ ...leadDraft, email: e.target.value })}
                className="w-full rounded-lg border border-border bg-background px-3 py-2 text-sm"
              />
              <button
                type="submit"
                className="w-full rounded-lg bg-primary py-2 text-sm font-semibold text-primary-foreground hover:bg-primary-glow"
              >
                Iniciar atendimento
              </button>
            </form>
          )}

          {/* Composer */}
          {!askingLead && (
            <form onSubmit={handleSubmit} className="flex items-center gap-2 border-t border-border bg-surface px-3 py-2.5">
              <input
                type="text"
                value={input}
                onChange={(e) => setInput(e.target.value)}
                placeholder={status === "offline" ? "Deixe sua mensagem…" : "Escreva uma mensagem…"}
                maxLength={2000}
                className="flex-1 rounded-xl border border-border bg-background px-3 py-2 text-sm outline-none focus:border-primary"
              />
              <button
                type="submit"
                disabled={!input.trim() || sending}
                aria-label="Enviar"
                className="grid h-10 w-10 place-items-center rounded-xl bg-primary text-primary-foreground transition-colors hover:bg-primary-glow disabled:opacity-50"
              >
                <Send className="h-4 w-4" />
              </button>
            </form>
          )}
        </div>
      )}
    </>
  );
}
