import { Smartphone, Instagram, Facebook, Twitter, Youtube, Music2, Mail, Phone, MapPin } from "lucide-react";
import { useStoreSettings } from "@/lib/use-store-settings";

export function Footer() {
  const s = useStoreSettings();
  const socials = [
    { url: s.instagram_url, Icon: Instagram, label: "Instagram" },
    { url: s.facebook_url, Icon: Facebook, label: "Facebook" },
    { url: s.twitter_url, Icon: Twitter, label: "Twitter" },
    { url: s.youtube_url, Icon: Youtube, label: "YouTube" },
    { url: s.tiktok_url, Icon: Music2, label: "TikTok" },
  ].filter((x) => x.url);

  return (
    <footer className="mt-24 border-t border-border bg-surface">
      <div className="mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-4 md:px-6">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2">
            {s.logo_url ? (
              <img src={s.logo_url} alt={s.store_name} className="h-8 w-8 rounded-lg object-cover" />
            ) : (
              <div className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground">
                <Smartphone className="h-4 w-4" />
              </div>
            )}
            <span className="font-display text-lg font-bold">{s.store_name}</span>
          </div>
          {s.description && (
            <p className="mt-3 max-w-sm text-sm text-muted-foreground">{s.description}</p>
          )}
          {socials.length > 0 && (
            <div className="mt-5 flex gap-2">
              {socials.map(({ url, Icon, label }) => (
                <a
                  key={label}
                  href={url!}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={label}
                  className="grid h-9 w-9 place-items-center rounded-lg border border-border text-muted-foreground transition-colors hover:border-primary hover:text-primary"
                >
                  <Icon className="h-4 w-4" />
                </a>
              ))}
            </div>
          )}
        </div>

        <div>
          <div className="mb-3 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Loja</div>
          <ul className="space-y-2 text-sm">
            <li><a href="/#cat-iphone" className="hover:text-primary">iPhone</a></li>
            <li><a href="/#cat-xiaomi" className="hover:text-primary">Xiaomi</a></li>
          </ul>
        </div>

        <div>
          <div className="mb-3 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">Contato</div>
          <ul className="space-y-2 text-sm">
            {s.contact_email && (
              <li className="flex items-center gap-2"><Mail className="h-3.5 w-3.5 text-muted-foreground" /><a href={`mailto:${s.contact_email}`} className="hover:text-primary">{s.contact_email}</a></li>
            )}
            {s.whatsapp && (
              <li className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 text-muted-foreground" /><a href={`https://wa.me/${s.whatsapp.replace(/\D/g, "")}`} target="_blank" rel="noreferrer" className="hover:text-primary">WhatsApp {s.whatsapp}</a></li>
            )}
            {s.contact_phone && !s.whatsapp && (
              <li className="flex items-center gap-2"><Phone className="h-3.5 w-3.5 text-muted-foreground" />{s.contact_phone}</li>
            )}
            {s.address && (
              <li className="flex items-start gap-2"><MapPin className="mt-0.5 h-3.5 w-3.5 text-muted-foreground" /><span>{s.address}</span></li>
            )}
          </ul>
        </div>
      </div>
      <div className="border-t border-border">
        <div className="mx-auto flex max-w-7xl flex-col gap-2 px-4 py-5 text-xs text-muted-foreground md:flex-row md:items-center md:justify-between md:px-6">
          <span>© {new Date().getFullYear()} {s.store_name}. {s.footer_text ?? "Todos os direitos reservados."}</span>
          {s.cnpj && <span className="font-mono">CNPJ {s.cnpj}</span>}
        </div>
      </div>
    </footer>
  );
}
