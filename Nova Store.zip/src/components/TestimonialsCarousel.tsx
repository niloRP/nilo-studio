import { useQuery } from "@tanstack/react-query";
import { Star, User } from "lucide-react";
import { listPublicTestimonials, type Testimonial } from "@/lib/settings.functions";

export function TestimonialsCarousel() {
  const { data } = useQuery({
    queryKey: ["testimonials-public"],
    queryFn: () => listPublicTestimonials(),
    staleTime: 60_000,
  });

  const items = data ?? [];
  if (items.length === 0) return null;

  // duplicate for seamless infinite scroll
  const track = [...items, ...items];
  // tune speed by item count
  const duration = Math.max(20, items.length * 6);

  return (
    <section className="relative mx-auto w-full max-w-7xl px-2 py-12 sm:px-4 md:px-6 md:py-16">
      <div className="flex items-end justify-between gap-4 px-2 sm:px-0">
        <div>
          <div className="text-[10px] font-mono uppercase tracking-widest text-primary">
            📸 Clientes que receberam
          </div>
          <h2 className="mt-1 font-display text-2xl font-bold md:text-3xl">
            Fotos reais e avaliações
          </h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Confira fotos reais e avaliações de clientes satisfeitos.
          </p>
        </div>
      </div>

      <div className="relative mt-8 overflow-hidden [mask-image:linear-gradient(to_right,transparent,#000_3%,#000_97%,transparent)]">
        <div
          className="flex w-max gap-3 sm:gap-4 animate-marquee"
          style={{ animationDuration: `${duration}s` }}
        >
          {track.map((t, i) => (
            <TestimonialCard key={`${t.id}-${i}`} t={t} />
          ))}
        </div>
      </div>
    </section>
  );
}

function TestimonialCard({ t }: { t: Testimonial }) {
  return (
    <article className="w-[88vw] max-w-[420px] shrink-0 rounded-3xl border border-border bg-gradient-to-br from-surface to-surface-elevated p-5 shadow-lg shadow-black/20 transition-transform duration-300 hover:scale-[1.01] sm:w-[420px] md:w-[460px] md:p-6">
      <div className="flex items-center gap-4">
        {t.image_url ? (
          <img
            src={t.image_url}
            alt={t.customer_name}
            className="h-16 w-16 rounded-full object-cover ring-2 ring-primary/40 md:h-20 md:w-20"
          />
        ) : (
          <div className="grid h-16 w-16 place-items-center rounded-full bg-surface-elevated text-muted-foreground md:h-20 md:w-20">
            <User className="h-7 w-7" />
          </div>
        )}
        <div className="min-w-0 flex-1">
          <div className="truncate text-base font-bold text-foreground md:text-lg">
            {t.customer_name}
          </div>
          {t.city && (
            <div className="truncate text-sm text-muted-foreground">{t.city}</div>
          )}
          <div className="mt-1.5 flex gap-0.5">
            {Array.from({ length: 5 }).map((_, i) => (
              <Star
                key={i}
                className={`h-4 w-4 md:h-5 md:w-5 ${
                  i < t.rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"
                }`}
              />
            ))}
          </div>
        </div>
      </div>
      <p className="mt-4 line-clamp-5 text-[15px] leading-relaxed text-foreground/85 md:text-base">
        “{t.comment}”
      </p>
    </article>
  );
}
