import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (!data) throw new Error("Acesso restrito ao administrador.");
}

export type SupportMessage = {
  id: string;
  conversation_id: string;
  sender: "customer" | "admin" | "bot" | "system";
  content: string;
  created_at: string;
};

export type SupportConversation = {
  id: string;
  session_token: string;
  customer_name: string | null;
  customer_phone: string | null;
  customer_email: string | null;
  status: "bot" | "waiting" | "active" | "closed";
  unread_admin: number;
  unread_customer: number;
  last_message_at: string;
  created_at: string;
};

function sanitize(s: string) {
  return s.replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, "").trim().slice(0, 2000);
}

// ===== PUBLIC (visitor) =====

const openSchema = z.object({
  session_token: z.string().min(10).max(80),
  name: z.string().max(120).optional().nullable(),
  phone: z.string().max(40).optional().nullable(),
  email: z.string().max(200).optional().nullable(),
});

export const openConversation = createServerFn({ method: "POST" })
  .inputValidator((d) => openSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: existing } = await supabaseAdmin
      .from("support_conversations")
      .select("*")
      .eq("session_token", data.session_token)
      .maybeSingle();
    if (existing) {
      const patch: Partial<{ customer_name: string; customer_phone: string; customer_email: string }> = {};
      if (data.name && !existing.customer_name) patch.customer_name = data.name;
      if (data.phone && !existing.customer_phone) patch.customer_phone = data.phone;
      if (data.email && !existing.customer_email) patch.customer_email = data.email;
      if (Object.keys(patch).length) {
        await supabaseAdmin.from("support_conversations").update(patch).eq("id", existing.id);
      }
      return { id: existing.id as string };
    }
    const { data: created, error } = await supabaseAdmin
      .from("support_conversations")
      .insert({
        session_token: data.session_token,
        customer_name: data.name ?? null,
        customer_phone: data.phone ?? null,
        customer_email: data.email ?? null,
        status: "bot",
      })
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: created.id as string };
  });

const sendSchema = z.object({
  session_token: z.string().min(10).max(80),
  sender: z.enum(["customer", "bot"]),
  content: z.string().min(1).max(2000),
});

export const sendCustomerMessage = createServerFn({ method: "POST" })
  .inputValidator((d) => sendSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: conv } = await supabaseAdmin
      .from("support_conversations")
      .select("id,status,unread_admin")
      .eq("session_token", data.session_token)
      .maybeSingle();
    if (!conv) throw new Error("Conversa não encontrada.");
    const content = sanitize(data.content);
    if (!content) throw new Error("Mensagem vazia.");
    const { error } = await supabaseAdmin.from("support_messages").insert({
      conversation_id: conv.id,
      sender: data.sender,
      content,
    });
    if (error) throw new Error(error.message);
    const patch: Partial<{ last_message_at: string; unread_admin: number; status: "waiting" }> = { last_message_at: new Date().toISOString() };
    if (data.sender === "customer") {
      patch.unread_admin = (conv.unread_admin ?? 0) + 1;
      if (conv.status === "bot") patch.status = "waiting";
    }
    await supabaseAdmin.from("support_conversations").update(patch).eq("id", conv.id);
    return { ok: true };
  });

const pollSchema = z.object({
  session_token: z.string().min(10).max(80),
  since: z.string().optional(),
});

export const pollCustomerMessages = createServerFn({ method: "POST" })
  .inputValidator((d) => pollSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: conv } = await supabaseAdmin
      .from("support_conversations")
      .select("id,status")
      .eq("session_token", data.session_token)
      .maybeSingle();
    if (!conv) return { conversation: null, messages: [] as SupportMessage[] };
    let q = supabaseAdmin
      .from("support_messages")
      .select("*")
      .eq("conversation_id", conv.id)
      .order("created_at", { ascending: true });
    if (data.since) q = q.gt("created_at", data.since);
    const { data: msgs } = await q;
    // Mark admin/bot messages as read by customer
    await supabaseAdmin
      .from("support_conversations")
      .update({ unread_customer: 0 })
      .eq("id", conv.id);
    return {
      conversation: { id: conv.id as string, status: conv.status as SupportConversation["status"] },
      messages: (msgs ?? []) as SupportMessage[],
    };
  });

// ===== ADMIN =====

export const listConversations = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ q: z.string().max(120).optional() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    let q = supabaseAdmin
      .from("support_conversations")
      .select("*")
      .order("last_message_at", { ascending: false })
      .limit(200);
    if (data.q && data.q.trim()) {
      const t = `%${data.q.trim()}%`;
      q = q.or(
        `customer_name.ilike.${t},customer_phone.ilike.${t},customer_email.ilike.${t}`,
      );
    }
    const { data: rows, error } = await q;
    if (error) throw new Error(error.message);
    return (rows ?? []) as SupportConversation[];
  });

export const getConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: conv } = await supabaseAdmin
      .from("support_conversations")
      .select("*")
      .eq("id", data.id)
      .single();
    const { data: msgs } = await supabaseAdmin
      .from("support_messages")
      .select("*")
      .eq("conversation_id", data.id)
      .order("created_at", { ascending: true });
    await supabaseAdmin
      .from("support_conversations")
      .update({ unread_admin: 0 })
      .eq("id", data.id);
    return {
      conversation: conv as SupportConversation,
      messages: (msgs ?? []) as SupportMessage[],
    };
  });

export const replyAsAdmin = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ id: z.string().uuid(), content: z.string().min(1).max(2000) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const content = sanitize(data.content);
    if (!content) throw new Error("Mensagem vazia.");
    const { data: conv } = await supabaseAdmin
      .from("support_conversations")
      .select("unread_customer,status")
      .eq("id", data.id)
      .single();
    await supabaseAdmin.from("support_messages").insert({
      conversation_id: data.id,
      sender: "admin",
      content,
    });
    await supabaseAdmin
      .from("support_conversations")
      .update({
        last_message_at: new Date().toISOString(),
        unread_customer: (conv?.unread_customer ?? 0) + 1,
        status: conv?.status === "closed" ? "active" : "active",
        assigned_admin_id: context.userId,
      })
      .eq("id", data.id);
    return { ok: true };
  });

export const closeConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin
      .from("support_conversations")
      .update({ status: "closed" })
      .eq("id", data.id);
    await supabaseAdmin.from("support_messages").insert({
      conversation_id: data.id,
      sender: "system",
      content: "Atendimento encerrado.",
    });
    return { ok: true };
  });

export const deleteConversation = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("support_conversations").delete().eq("id", data.id);
    return { ok: true };
  });

export const setSupportStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ status: z.enum(["online", "away", "offline"]) }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    await supabaseAdmin.from("store_settings").upsert({ id: 1, support_status: data.status });
    return { ok: true };
  });

export const getSupportStatus = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("store_settings")
    .select("support_status,whatsapp")
    .eq("id", 1)
    .maybeSingle();
  return {
    status: (data?.support_status ?? "online") as "online" | "away" | "offline",
    whatsapp: (data?.whatsapp ?? null) as string | null,
  };
});
