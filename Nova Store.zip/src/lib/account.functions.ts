import { createServerFn } from "@tanstack/react-start";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import { z } from "zod";

// ---------------- PROFILE ----------------

const profileSchema = z.object({
  name: z.string().trim().min(2).max(120),
  phone: z
    .string()
    .trim()
    .max(25)
    .optional()
    .or(z.literal("").transform(() => undefined)),
  cpf: z
    .string()
    .trim()
    .max(14)
    .optional()
    .or(z.literal("").transform(() => undefined)),
});

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabase, userId } = context;
    // Ensure row exists (fallback if trigger missed it)
    const { data: existing } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .maybeSingle();
    if (existing) {
      // touch last_login_at quietly
      await supabase
        .from("profiles")
        .update({ last_login_at: new Date().toISOString() })
        .eq("id", userId);
      return existing;
    }
    // Fallback: use admin client to read auth.users metadata and insert
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: u } = await supabaseAdmin.auth.admin.getUserById(userId);
    const meta = (u.user?.user_metadata ?? {}) as Record<string, unknown>;
    const insertPayload = {
      id: userId,
      email: u.user?.email ?? null,
      name:
        (meta.full_name as string | undefined) ??
        (meta.name as string | undefined) ??
        u.user?.email?.split("@")[0] ??
        null,
      avatar_url: (meta.avatar_url as string | undefined) ?? null,
      last_login_at: new Date().toISOString(),
    };
    const { data: created, error } = await supabase
      .from("profiles")
      .insert(insertPayload)
      .select("*")
      .single();
    if (error) throw new Error(error.message);
    return created;
  });

export const updateMyProfile = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => profileSchema.parse(d))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("profiles")
      .update({
        name: data.name,
        phone: data.phone ?? null,
        cpf: data.cpf ? data.cpf.replace(/\D/g, "") : null,
      })
      .eq("id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------------- ADDRESSES ----------------

const addressSchema = z.object({
  id: z.string().uuid().optional(),
  label: z.string().trim().max(60).optional().nullable(),
  cep: z.string().trim().min(8).max(12),
  street: z.string().trim().min(2).max(160),
  number: z.string().trim().min(1).max(20),
  complement: z.string().trim().max(120).optional().nullable(),
  district: z.string().trim().min(2).max(120),
  city: z.string().trim().min(2).max(80),
  state: z.string().trim().length(2),
  is_default: z.boolean().optional(),
});

export const listMyAddresses = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("addresses")
      .select("*")
      .order("is_default", { ascending: false })
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const upsertMyAddress = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => addressSchema.parse(d))
  .handler(async ({ context, data }) => {
    const payload = {
      user_id: context.userId,
      label: data.label ?? null,
      cep: data.cep.replace(/\D/g, ""),
      street: data.street,
      number: data.number,
      complement: data.complement ?? null,
      district: data.district,
      city: data.city,
      state: data.state.toUpperCase(),
      is_default: data.is_default ?? false,
    };
    if (data.id) {
      const { error } = await context.supabase
        .from("addresses")
        .update(payload)
        .eq("id", data.id)
        .eq("user_id", context.userId);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await context.supabase
      .from("addresses")
      .insert(payload)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const deleteMyAddress = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("addresses")
      .delete()
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setDefaultAddress = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("addresses")
      .update({ is_default: true })
      .eq("id", data.id)
      .eq("user_id", context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------------- FAVORITES ----------------

export const listMyFavorites = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("favorites")
      .select("product_id, created_at")
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return (data ?? []).map((r) => r.product_id as string);
  });

export const toggleFavorite = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ product_id: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }) => {
    const { data: exists } = await context.supabase
      .from("favorites")
      .select("id")
      .eq("user_id", context.userId)
      .eq("product_id", data.product_id)
      .maybeSingle();
    if (exists) {
      const { error } = await context.supabase
        .from("favorites")
        .delete()
        .eq("id", exists.id);
      if (error) throw new Error(error.message);
      return { favorited: false };
    }
    const { error } = await context.supabase
      .from("favorites")
      .insert({ user_id: context.userId, product_id: data.product_id });
    if (error) throw new Error(error.message);
    return { favorited: true };
  });

// ---------------- RECENTLY VIEWED ----------------

export const registerRecentlyViewed = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ product_id: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }) => {
    await context.supabase.from("recently_viewed").upsert(
      {
        user_id: context.userId,
        product_id: data.product_id,
        viewed_at: new Date().toISOString(),
      },
      { onConflict: "user_id,product_id" },
    );
    return { ok: true };
  });

export const listRecentlyViewed = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("recently_viewed")
      .select("product_id, viewed_at")
      .order("viewed_at", { ascending: false })
      .limit(12);
    if (error) throw new Error(error.message);
    return (data ?? []).map((r) => r.product_id as string);
  });

// ---------------- SAVED CART ----------------

const cartItemSchema = z.object({
  id: z.string(),
  slug: z.string(),
  name: z.string(),
  brand: z.string().nullable(),
  price: z.number(),
  image: z.string(),
  qty: z.number().int().min(1).max(99),
});

type SavedCartItem = z.infer<typeof cartItemSchema>;

export const getSavedCart = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }): Promise<SavedCartItem[]> => {
    const { data } = await context.supabase
      .from("saved_carts")
      .select("items")
      .eq("user_id", context.userId)
      .maybeSingle();
    return (data?.items as SavedCartItem[] | null) ?? [];
  });

export const saveCart = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ items: z.array(cartItemSchema) }).parse(d))
  .handler(async ({ context, data }) => {
    const { error } = await context.supabase
      .from("saved_carts")
      .upsert(
        {
          user_id: context.userId,
          items: data.items,
          updated_at: new Date().toISOString(),
        },
        { onConflict: "user_id" },
      );
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// ---------------- ORDERS ----------------

export const linkOrderToMe = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ order_id: z.string().uuid() }).parse(d))
  .handler(async ({ context, data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: order } = await supabaseAdmin
      .from("orders")
      .select("id,user_id")
      .eq("id", data.order_id)
      .maybeSingle();
    if (!order) throw new Error("Pedido não encontrado.");
    if (order.user_id && order.user_id !== context.userId) {
      throw new Error("Pedido pertence a outro usuário.");
    }
    if (!order.user_id) {
      const { error } = await supabaseAdmin
        .from("orders")
        .update({ user_id: context.userId })
        .eq("id", data.order_id);
      if (error) throw new Error(error.message);
    }
    return { ok: true };
  });

export const listMyOrders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { data, error } = await context.supabase
      .from("orders")
      .select(
        "id, code, status, total, created_at, address_city, address_uf, order_items(product_id, product_name, product_slug, unit_price, qty, subtotal)",
      )
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return data ?? [];
  });

// ---------------- DELETE ACCOUNT ----------------

export const deleteMyAccount = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin.auth.admin.deleteUser(context.userId);
    if (error) throw new Error(error.message);
    return { ok: true };
  });
