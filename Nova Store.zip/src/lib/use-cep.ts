const cache = new Map<string, ViaCepResult>();

export type ViaCepResult = {
  cep: string;
  logradouro: string;
  bairro: string;
  localidade: string;
  uf: string;
  complemento: string;
  erro?: boolean;
};

export async function fetchCep(rawCep: string): Promise<ViaCepResult> {
  const cep = rawCep.replace(/\D/g, "");
  if (cep.length !== 8) throw new Error("CEP inválido. Informe 8 dígitos.");
  const cached = cache.get(cep);
  if (cached) return cached;
  const res = await fetch(`https://viacep.com.br/ws/${cep}/json/`);
  if (!res.ok) throw new Error("Não foi possível consultar o CEP.");
  const json = (await res.json()) as ViaCepResult;
  if (json.erro) throw new Error("CEP não encontrado.");
  cache.set(cep, json);
  return json;
}
