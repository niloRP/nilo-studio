import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";
import type { OrderStatus } from "./products";

async function assertAdmin(userId: string) {
  const { supabaseAdmin } = await import(
    "@/integrations/supabase/client.server"
  );
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Acesso restrito ao administrador.");
}

export const checkIsAdmin = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { data } = await supabaseAdmin
      .from("user_roles")
      .select("role")
      .eq("user_id", context.userId)
      .eq("role", "admin")
      .maybeSingle();
    return { isAdmin: !!data, userId: context.userId };
  });



// =========== PRODUCTS ===========

const productSchema = z.object({
  id: z.string().uuid().optional().nullable(),
  slug: z
    .string()
    .min(2)
    .max(160)
    .regex(/^[a-z0-9-]+$/, "Slug deve conter apenas letras minúsculas, números e hífens"),
  name: z.string().min(2).max(200),
  brand: z.string().max(80).nullable().optional(),
  model: z.string().max(120).nullable().optional(),
  color: z.string().max(60).nullable().optional(),
  storage: z.string().max(40).nullable().optional(),
  ram: z.string().max(40).nullable().optional(),
  condition: z.enum(["novo", "seminovo"]).default("novo"),
  category_slug: z.string().max(80).nullable().optional(),
  price: z.number().min(0).max(1_000_000),
  promo_price: z.number().min(0).max(1_000_000).nullable().optional(),
  old_price: z.number().min(0).max(1_000_000).nullable().optional(),
  badge: z.string().max(40).nullable().optional(),
  stock: z.number().int().min(0).max(1_000_000),
  low_stock_threshold: z.number().int().min(0).max(10_000).default(5),
  short_description: z.string().max(280).nullable().optional(),
  description: z.string().max(5000).nullable().optional(),
  specs: z
    .array(z.object({ label: z.string().max(60), value: z.string().max(160) }))
    .max(40)
    .default([]),
  tags: z.array(z.string().max(40)).max(20).default([]),
  featured: z.boolean().default(false),
  active: z.boolean().default(true),
});

export const listAllProducts = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { data, error } = await supabaseAdmin
      .from("products")
      .select(
        "id,slug,name,brand,category_slug,price,old_price,stock,low_stock_threshold,active,updated_at, product_images(id,url,storage_path,is_primary,sort_order)",
      )
      .order("updated_at", { ascending: false });
    if (error) throw new Error(error.message);
    type ImageRow = { url: string; storage_path: string | null };
    const rows = (data ?? []) as Array<{ product_images?: ImageRow[] | null }>;
    const paths = rows.flatMap((r) =>
      (r.product_images ?? []).flatMap((im) => (im.storage_path ? [im.storage_path] : [])),
    );
    if (paths.length > 0) {
      const { data: signed, error: signedError } = await supabaseAdmin.storage
        .from("product-media")
        .createSignedUrls(paths, 60 * 60 * 24 * 365 * 10);
      if (signedError) throw new Error(signedError.message);
      const signedMap = new Map<string, string>();
      for (const s of signed ?? []) {
        if (s.path && s.signedUrl) signedMap.set(s.path, s.signedUrl);
      }
      for (const row of rows) {
        for (const im of row.product_images ?? []) {
          if (im.storage_path && signedMap.has(im.storage_path)) {
            im.url = signedMap.get(im.storage_path)!;
          }
        }
      }
    }
    return rows;
  });

export const getAdminProduct = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { data: row, error } = await supabaseAdmin
      .from("products")
      .select(
        "*, product_images(id,url,storage_path,is_primary,sort_order), product_videos(id,url,storage_path,title,sort_order)",
      )
      .eq("id", data.id)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) return row;
    // Re-sign media URLs from storage_path so private bucket files load.
    const paths: string[] = [];
    type MediaRow = { storage_path: string | null; url: string };
    for (const im of (row.product_images ?? []) as MediaRow[]) {
      if (im.storage_path) paths.push(im.storage_path);
    }
    for (const v of (row.product_videos ?? []) as MediaRow[]) {
      if (v.storage_path) paths.push(v.storage_path);
    }
    if (paths.length > 0) {
      const { data: signed } = await supabaseAdmin.storage
        .from("product-media")
        .createSignedUrls(paths, 60 * 60 * 24 * 365 * 10);
      const map = new Map<string, string>();
      for (const s of signed ?? []) {
        if (s.path && s.signedUrl) map.set(s.path, s.signedUrl);
      }
      for (const im of (row.product_images ?? []) as MediaRow[]) {
        if (im.storage_path && map.has(im.storage_path)) im.url = map.get(im.storage_path)!;
      }
      for (const v of (row.product_videos ?? []) as MediaRow[]) {
        if (v.storage_path && map.has(v.storage_path)) v.url = map.get(v.storage_path)!;
      }
    }
    return row;
  });

export const upsertProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => productSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const payload = {
      slug: data.slug,
      name: data.name,
      brand: data.brand ?? null,
      model: data.model ?? null,
      color: data.color ?? null,
      storage: data.storage ?? null,
      ram: data.ram ?? null,
      condition: data.condition,
      category_slug: data.category_slug ?? null,
      price: data.price,
      promo_price: data.promo_price ?? null,
      old_price: data.old_price ?? null,
      badge: data.badge ?? null,
      stock: data.stock,
      low_stock_threshold: data.low_stock_threshold,
      short_description: data.short_description ?? null,
      description: data.description ?? null,
      specs: data.specs,
      tags: data.tags,
      featured: data.featured,
      active: data.active,
    };
    if (data.id) {
      const { data: row, error } = await supabaseAdmin
        .from("products")
        .update(payload)
        .eq("id", data.id)
        .select("id")
        .single();
      if (error) throw new Error(error.message);
      return { id: row.id };
    } else {
      const { data: row, error } = await supabaseAdmin
        .from("products")
        .insert(payload)
        .select("id")
        .single();
      if (error) throw new Error(error.message);
      return { id: row.id };
    }
  });

export const deleteProduct = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { error } = await supabaseAdmin
      .from("products")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const toggleProductActive = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ id: z.string().uuid(), active: z.boolean() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { error } = await supabaseAdmin
      .from("products")
      .update({ active: data.active })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// =========== MEDIA ===========

export const addProductImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        product_id: z.string().uuid(),
        url: z.string().url().max(2000).nullable().optional(),
        storage_path: z.string().max(500).nullable().optional(),
        is_primary: z.boolean().default(false),
      })
      .refine((v) => !!v.url || !!v.storage_path, {
        message: "Informe uma URL ou um arquivo enviado.",
        path: ["url"],
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    let finalUrl = data.url ?? "";
    if (data.storage_path) {
      console.log("[upload imagem] Validando arquivo no storage", {
        product_id: data.product_id,
        storage_path: data.storage_path,
      });
      const { error: infoError } = await supabaseAdmin.storage
        .from("product-media")
        .info(data.storage_path);
      if (infoError) throw new Error(`Arquivo não encontrado no storage: ${infoError.message}`);
      const { data: signedRead, error: signedReadErr } = await supabaseAdmin.storage
        .from("product-media")
        .createSignedUrl(data.storage_path, 60 * 60 * 24 * 365 * 10);
      if (signedReadErr) throw new Error(`Falha ao gerar URL da imagem: ${signedReadErr.message}`);
      finalUrl = signedRead.signedUrl;
      console.log("[upload imagem] URL retornada", { storage_path: data.storage_path, url: finalUrl });
    }
    if (data.is_primary) {
      await supabaseAdmin
        .from("product_images")
        .update({ is_primary: false })
        .eq("product_id", data.product_id);
    }
    const { data: maxRow } = await supabaseAdmin
      .from("product_images")
      .select("sort_order")
      .eq("product_id", data.product_id)
      .order("sort_order", { ascending: false })
      .limit(1)
      .maybeSingle();
    const nextOrder = (maxRow?.sort_order ?? -1) + 1;
    const { data: inserted, error } = await supabaseAdmin.from("product_images").insert({
      product_id: data.product_id,
      url: finalUrl,
      storage_path: data.storage_path ?? null,
      is_primary: data.is_primary,
      sort_order: nextOrder,
    }).select("id,url,storage_path,is_primary,sort_order").single();
    if (error) throw new Error(error.message);
    console.log("[upload imagem] URL salva no banco", {
      id: inserted.id,
      product_id: data.product_id,
      storage_path: inserted.storage_path,
      url: inserted.url,
    });
    return inserted;
  });

export const removeProductImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { data: img } = await supabaseAdmin
      .from("product_images")
      .select("storage_path")
      .eq("id", data.id)
      .maybeSingle();
    if (img?.storage_path) {
      await supabaseAdmin.storage.from("product-media").remove([img.storage_path]);
    }
    const { error } = await supabaseAdmin
      .from("product_images")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const setPrimaryImage = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z.object({ id: z.string().uuid(), product_id: z.string().uuid() }).parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    await supabaseAdmin
      .from("product_images")
      .update({ is_primary: false })
      .eq("product_id", data.product_id);
    const { error } = await supabaseAdmin
      .from("product_images")
      .update({ is_primary: true })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const reorderImages = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        product_id: z.string().uuid(),
        ordered_ids: z.array(z.string().uuid()).min(1).max(50),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    for (let i = 0; i < data.ordered_ids.length; i++) {
      await supabaseAdmin
        .from("product_images")
        .update({ sort_order: i })
        .eq("id", data.ordered_ids[i])
        .eq("product_id", data.product_id);
    }
    return { ok: true };
  });

export const addProductVideo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        product_id: z.string().uuid(),
        url: z.string().url().max(2000).nullable().optional(),
        storage_path: z.string().max(500).nullable().optional(),
        title: z.string().max(120).nullable().optional(),
      })
      .refine((v) => !!v.url || !!v.storage_path, {
        message: "Informe uma URL ou um vídeo enviado.",
        path: ["url"],
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    let finalUrl = data.url ?? "";
    if (data.storage_path) {
      const { error: infoError } = await supabaseAdmin.storage
        .from("product-media")
        .info(data.storage_path);
      if (infoError) throw new Error(`Arquivo não encontrado no storage: ${infoError.message}`);
      const { data: signedRead, error: signedReadErr } = await supabaseAdmin.storage
        .from("product-media")
        .createSignedUrl(data.storage_path, 60 * 60 * 24 * 365 * 10);
      if (signedReadErr) throw new Error(`Falha ao gerar URL do vídeo: ${signedReadErr.message}`);
      finalUrl = signedRead.signedUrl;
    }
    const { error } = await supabaseAdmin.from("product_videos").insert({
      product_id: data.product_id,
      url: finalUrl,
      storage_path: data.storage_path ?? null,
      title: data.title ?? null,
    });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const removeProductVideo = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { data: v } = await supabaseAdmin
      .from("product_videos")
      .select("storage_path")
      .eq("id", data.id)
      .maybeSingle();
    if (v?.storage_path) {
      await supabaseAdmin.storage.from("product-media").remove([v.storage_path]);
    }
    const { error } = await supabaseAdmin
      .from("product_videos")
      .delete()
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// =========== UPLOAD (signed URL) ===========

export const createMediaUploadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        product_id: z.string().uuid(),
        filename: z
          .string()
          .min(1)
          .max(200)
          .regex(/^[a-zA-Z0-9._-]+$/),
        kind: z.enum(["image", "video"]),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const path = `${data.kind}s/${data.product_id}/${Date.now()}-${data.filename}`;
    const { data: signed, error } = await supabaseAdmin.storage
      .from("product-media")
      .createSignedUploadUrl(path);
    if (error) throw new Error(error.message);
    return {
      signedUrl: signed.signedUrl,
      token: signed.token,
      path,
      publicUrl: "",
    };
  });

// =========== ORDERS ===========

export const listOrders = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { data, error } = await supabaseAdmin
      .from("orders")
      .select(
        "id,code,customer_name,customer_phone,customer_email,total,status,created_at, order_items(id,product_name,qty,unit_price,subtotal)",
      )
      .order("created_at", { ascending: false })
      .limit(200);
    if (error) throw new Error(error.message);
    return data ?? [];
  });

export const updateOrderStatus = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        id: z.string().uuid(),
        status: z.enum([
          "aguardando_pagamento",
          "pago",
          "separando",
          "em_envio",
          "entregue",
          "cancelado",
        ]),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { error } = await supabaseAdmin
      .from("orders")
      .update({ status: data.status as OrderStatus })
      .eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// =========== DASHBOARD ===========

export const getDashboardStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const [orders, products] = await Promise.all([
      supabaseAdmin.from("orders").select("status,total", { count: "exact" }),
      supabaseAdmin.from("products").select("stock,low_stock_threshold,active"),
    ]);
    const o = orders.data ?? [];
    const p = products.data ?? [];
    return {
      ordersTotal: o.length,
      revenue: o
        .filter((x) => ["pago", "separando", "em_envio", "entregue"].includes(x.status))
        .reduce((s, x) => s + Number(x.total ?? 0), 0),
      pending: o.filter((x) => x.status === "aguardando_pagamento").length,
      paid: o.filter((x) => x.status === "pago").length,
      delivered: o.filter((x) => x.status === "entregue").length,
      productsCount: p.length,
      activeProducts: p.filter((x) => x.active).length,
      outOfStock: p.filter((x) => x.stock <= 0).length,
      lowStock: p.filter((x) => x.stock > 0 && x.stock <= x.low_stock_threshold).length,
    };
  });

// =========== ADMIN EMAILS (WHITELIST) ===========

const emailSchema = z
  .string()
  .trim()
  .toLowerCase()
  .min(3)
  .max(255)
  .email("E-mail inválido");

export const listAdminEmails = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { data: emails, error } = await supabaseAdmin
      .from("admin_emails")
      .select("email,created_at")
      .order("created_at", { ascending: true });
    if (error) throw new Error(error.message);

    // Cross-reference with auth.users to show who is already active
    const { data: usersRes } = await supabaseAdmin.auth.admin.listUsers({
      page: 1,
      perPage: 1000,
    });
    const userByEmail = new Map<string, { id: string; last_sign_in_at: string | null }>();
    for (const u of usersRes?.users ?? []) {
      if (u.email) userByEmail.set(u.email.toLowerCase(), { id: u.id, last_sign_in_at: u.last_sign_in_at ?? null });
    }
    return (emails ?? []).map((e) => {
      const u = userByEmail.get(e.email.toLowerCase());
      return {
        email: e.email,
        created_at: e.created_at,
        active: !!u,
        last_sign_in_at: u?.last_sign_in_at ?? null,
      };
    });
  });

export const addAdminEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ email: emailSchema }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { error } = await supabaseAdmin
      .from("admin_emails")
      .upsert({ email: data.email }, { onConflict: "email" });
    if (error) throw new Error(error.message);

    // Grant admin role immediately if the user already exists
    const { data: usersRes } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 });
    const user = (usersRes?.users ?? []).find(
      (u) => u.email?.toLowerCase() === data.email,
    );
    if (user) {
      await supabaseAdmin
        .from("user_roles")
        .upsert(
          { user_id: user.id, role: "admin" },
          { onConflict: "user_id,role" },
        );
    }
    return { ok: true, granted: !!user };
  });

export const removeAdminEmail = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ email: emailSchema }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);

    // Protect against locking yourself out
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { data: meRes } = await supabaseAdmin.auth.admin.getUserById(context.userId);
    if (meRes?.user?.email?.toLowerCase() === data.email) {
      throw new Error("Você não pode remover o próprio e-mail da lista.");
    }

    const { error } = await supabaseAdmin
      .from("admin_emails")
      .delete()
      .eq("email", data.email);
    if (error) throw new Error(error.message);

    // Revoke admin role immediately from any matching user
    const { data: usersRes } = await supabaseAdmin.auth.admin.listUsers({ page: 1, perPage: 1000 });
    const user = (usersRes?.users ?? []).find(
      (u) => u.email?.toLowerCase() === data.email,
    );
    if (user) {
      await supabaseAdmin
        .from("user_roles")
        .delete()
        .eq("user_id", user.id)
        .eq("role", "admin");
    }
    return { ok: true, revoked: !!user };
  });
