import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import {
  primaryImage,
  type Category,
  type Product,
  type ProductCondition,
  type ProductImage,
  type ProductSpec,
  type ProductVideo,
} from "./products";

type RawProductRow = {
  id: string;
  slug: string;
  name: string;
  brand: string | null;
  model: string | null;
  color: string | null;
  storage: string | null;
  ram: string | null;
  condition: string | null;
  category_slug: string | null;
  price: number | string;
  promo_price: number | string | null;
  old_price: number | string | null;
  badge: string | null;
  rating: number | string;
  reviews: number;
  stock: number;
  low_stock_threshold: number;
  short_description: string | null;
  description: string | null;
  specs: unknown;
  tags: string[] | null;
  featured: boolean | null;
  active: boolean;
  product_images?: ProductImage[] | null;
  product_videos?: ProductVideo[] | null;
};

const SELECT_COLS =
  "id,slug,name,brand,model,color,storage,ram,condition,category_slug,price,promo_price,old_price,badge,rating,reviews,stock,low_stock_threshold,short_description,description,specs,tags,featured,active, product_images(id,url,storage_path,is_primary,sort_order), product_videos(id,url,storage_path,title,sort_order)";

const SIGNED_TTL = 60 * 60 * 24 * 365 * 10; // 10 years

type SupabaseAdminClient = Awaited<
  typeof import("@/integrations/supabase/client.server")
>["supabaseAdmin"];

async function resignMediaUrls(
  supabaseAdmin: SupabaseAdminClient,
  rows: RawProductRow[],
): Promise<void> {
  const paths = new Set<string>();
  for (const r of rows) {
    for (const im of r.product_images ?? []) {
      if (im.storage_path) paths.add(im.storage_path);
    }
    for (const v of r.product_videos ?? []) {
      if (v.storage_path) paths.add(v.storage_path);
    }
  }
  if (paths.size === 0) return;
  const list = Array.from(paths);
  const { data: signed } = await supabaseAdmin.storage
    .from("product-media")
    .createSignedUrls(list, SIGNED_TTL);
  const map = new Map<string, string>();
  for (const s of signed ?? []) {
    if (s.path && s.signedUrl) map.set(s.path, s.signedUrl);
  }
  for (const r of rows) {
    for (const im of r.product_images ?? []) {
      if (im.storage_path && map.has(im.storage_path)) {
        im.url = map.get(im.storage_path)!;
      }
    }
    for (const v of r.product_videos ?? []) {
      if (v.storage_path && map.has(v.storage_path)) {
        v.url = map.get(v.storage_path)!;
      }
    }
  }
}

function num(v: number | string | null | undefined): number {
  if (v == null) return 0;
  return typeof v === "string" ? Number(v) : v;
}

function specsArray(v: unknown): ProductSpec[] {
  if (!Array.isArray(v)) return [];
  return v.filter(
    (s): s is ProductSpec =>
      !!s && typeof s === "object" && "label" in s && "value" in s,
  );
}

function mapProduct(row: RawProductRow): Product {
  const images = (row.product_images ?? []).slice().sort((a, b) => {
    if (a.is_primary !== b.is_primary) return a.is_primary ? -1 : 1;
    return a.sort_order - b.sort_order;
  });
  const videos = (row.product_videos ?? [])
    .slice()
    .sort((a, b) => a.sort_order - b.sort_order);
  return {
    id: row.id,
    slug: row.slug,
    name: row.name,
    brand: row.brand,
    model: row.model,
    color: row.color,
    storage: row.storage,
    ram: row.ram,
    condition: (row.condition === "seminovo" ? "seminovo" : "novo") as ProductCondition,
    category_slug: row.category_slug,
    price: num(row.price),
    promo_price: row.promo_price == null ? null : num(row.promo_price),
    old_price: row.old_price == null ? null : num(row.old_price),
    badge: row.badge,
    rating: num(row.rating),
    reviews: row.reviews,
    stock: row.stock,
    low_stock_threshold: row.low_stock_threshold,
    short_description: row.short_description,
    description: row.description,
    specs: specsArray(row.specs),
    tags: row.tags ?? [],
    featured: !!row.featured,
    active: row.active,
    image: primaryImage(images),
    images,
    videos,
  };
}

export const listPublicCatalog = createServerFn({ method: "GET" }).handler(
  async (): Promise<{ products: Product[]; categories: Category[] }> => {
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const [{ data: products, error: pe }, { data: cats, error: ce }] =
      await Promise.all([
        supabaseAdmin
          .from("products")
          .select(SELECT_COLS)
          .eq("active", true)
          .order("created_at", { ascending: false }),
        supabaseAdmin
          .from("categories")
          .select("*")
          .order("sort_order", { ascending: true }),
      ]);
    if (pe) throw new Error(pe.message);
    if (ce) throw new Error(ce.message);
    const rows = (products as RawProductRow[] | null) ?? [];
    await resignMediaUrls(supabaseAdmin, rows);
    return {
      products: rows.map(mapProduct),
      categories: (cats as Category[] | null) ?? [],
    };
  },
);

export const getPublicProductBySlug = createServerFn({ method: "GET" })
  .inputValidator((d) => z.object({ slug: z.string().min(1).max(160) }).parse(d))
  .handler(async ({ data }): Promise<Product | null> => {
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );
    const { data: row, error } = await supabaseAdmin
      .from("products")
      .select(SELECT_COLS)
      .eq("slug", data.slug)
      .eq("active", true)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!row) return null;
    const r = row as RawProductRow;
    await resignMediaUrls(supabaseAdmin, [r]);
    return mapProduct(r);
  });
