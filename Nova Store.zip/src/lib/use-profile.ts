import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { getMyProfile } from "@/lib/account.functions";
import { useAuth } from "@/lib/use-auth";

export function useProfile() {
  const { user } = useAuth();
  const fn = useServerFn(getMyProfile);
  return useQuery({
    queryKey: ["my-profile", user?.id],
    queryFn: () => fn(),
    enabled: !!user,
    staleTime: 60_000,
  });
}
