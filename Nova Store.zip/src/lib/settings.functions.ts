import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

async function assertAdmin(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (!data) throw new Error("Acesso restrito ao administrador.");
}

export type StoreSettings = {
  store_name: string;
  tagline: string | null;
  description: string | null;
  logo_url: string | null;
  favicon_url: string | null;
  primary_color: string | null;
  contact_email: string | null;
  contact_phone: string | null;
  whatsapp: string | null;
  address: string | null;
  cnpj: string | null;
  instagram_url: string | null;
  facebook_url: string | null;
  twitter_url: string | null;
  youtube_url: string | null;
  tiktok_url: string | null;
  footer_text: string | null;
};

export const getStoreSettings = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("store_settings")
    .select("*")
    .eq("id", 1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  return (data ?? { store_name: "iPhone SP" }) as StoreSettings;
});

const settingsSchema = z.object({
  store_name: z.string().min(1).max(120),
  tagline: z.string().max(200).nullable().optional(),
  description: z.string().max(1000).nullable().optional(),
  logo_url: z.string().max(2000).nullable().optional(),
  favicon_url: z.string().max(2000).nullable().optional(),
  primary_color: z.string().max(40).nullable().optional(),
  contact_email: z.string().max(200).nullable().optional(),
  contact_phone: z.string().max(40).nullable().optional(),
  whatsapp: z.string().max(40).nullable().optional(),
  address: z.string().max(300).nullable().optional(),
  cnpj: z.string().max(40).nullable().optional(),
  instagram_url: z.string().max(2000).nullable().optional(),
  facebook_url: z.string().max(2000).nullable().optional(),
  twitter_url: z.string().max(2000).nullable().optional(),
  youtube_url: z.string().max(2000).nullable().optional(),
  tiktok_url: z.string().max(2000).nullable().optional(),
  footer_text: z.string().max(500).nullable().optional(),
});

export const updateStoreSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => settingsSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("store_settings")
      .upsert({ id: 1, ...data });
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// =========== TESTIMONIALS ===========

export type Testimonial = {
  id: string;
  customer_name: string;
  city: string | null;
  comment: string;
  rating: number;
  image_url: string | null;
  storage_path: string | null;
  sort_order: number;
  active: boolean;
};

async function signTestimonialImages<T extends { image_url: string | null; storage_path: string | null }>(
  rows: T[],
): Promise<T[]> {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const paths = rows.flatMap((r) => (r.storage_path ? [r.storage_path] : []));
  if (paths.length === 0) return rows;
  const { data: signed } = await supabaseAdmin.storage
    .from("product-media")
    .createSignedUrls(paths, 60 * 60 * 24 * 365 * 10);
  const map = new Map<string, string>();
  for (const s of signed ?? []) {
    if (s.path && s.signedUrl) map.set(s.path, s.signedUrl);
  }
  return rows.map((r) =>
    r.storage_path && map.has(r.storage_path)
      ? { ...r, image_url: map.get(r.storage_path)! }
      : r,
  );
}

export const listPublicTestimonials = createServerFn({ method: "GET" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("testimonials")
    .select("id,customer_name,city,comment,rating,image_url,storage_path,sort_order,active")
    .eq("active", true)
    .order("sort_order", { ascending: true })
    .order("created_at", { ascending: false });
  if (error) throw new Error(error.message);
  return await signTestimonialImages((data ?? []) as Testimonial[]);
});

export const listAdminTestimonials = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("testimonials")
      .select("id,customer_name,city,comment,rating,image_url,storage_path,sort_order,active")
      .order("sort_order", { ascending: true })
      .order("created_at", { ascending: false });
    if (error) throw new Error(error.message);
    return await signTestimonialImages((data ?? []) as Testimonial[]);
  });

const testimonialSchema = z.object({
  id: z.string().uuid().optional().nullable(),
  customer_name: z.string().min(1).max(120),
  city: z.string().max(120).nullable().optional(),
  comment: z.string().min(1).max(800),
  rating: z.number().int().min(1).max(5),
  image_url: z.string().max(2000).nullable().optional(),
  storage_path: z.string().max(500).nullable().optional(),
  sort_order: z.number().int().min(0).max(10000).default(0),
  active: z.boolean().default(true),
});

export const upsertTestimonial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => testimonialSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const payload = {
      customer_name: data.customer_name,
      city: data.city ?? null,
      comment: data.comment,
      rating: data.rating,
      image_url: data.image_url ?? null,
      storage_path: data.storage_path ?? null,
      sort_order: data.sort_order,
      active: data.active,
    };
    if (data.id) {
      const { error } = await supabaseAdmin
        .from("testimonials")
        .update(payload)
        .eq("id", data.id);
      if (error) throw new Error(error.message);
      return { id: data.id };
    }
    const { data: row, error } = await supabaseAdmin
      .from("testimonials")
      .insert(payload)
      .select("id")
      .single();
    if (error) throw new Error(error.message);
    return { id: row.id };
  });

export const deleteTestimonial = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ id: z.string().uuid() }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: row } = await supabaseAdmin
      .from("testimonials")
      .select("storage_path")
      .eq("id", data.id)
      .maybeSingle();
    if (row?.storage_path) {
      await supabaseAdmin.storage.from("product-media").remove([row.storage_path]);
    }
    const { error } = await supabaseAdmin.from("testimonials").delete().eq("id", data.id);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

// =========== UPLOAD (signed URL) for settings/testimonials ===========

export const createBrandUploadUrl = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) =>
    z
      .object({
        scope: z.enum(["logo", "favicon", "testimonial"]),
        filename: z
          .string()
          .min(1)
          .max(200)
          .regex(/^[a-zA-Z0-9._-]+$/),
      })
      .parse(d),
  )
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const path = `branding/${data.scope}/${Date.now()}-${data.filename}`;
    const { data: signed, error } = await supabaseAdmin.storage
      .from("product-media")
      .createSignedUploadUrl(path);
    if (error) throw new Error(error.message);
    return { signedUrl: signed.signedUrl, token: signed.token, path };
  });

export const finalizeBrandUpload = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => z.object({ path: z.string().min(1).max(500) }).parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error: infoErr } = await supabaseAdmin.storage
      .from("product-media")
      .info(data.path);
    if (infoErr) throw new Error(`Arquivo não encontrado: ${infoErr.message}`);
    const { data: signed, error } = await supabaseAdmin.storage
      .from("product-media")
      .createSignedUrl(data.path, 60 * 60 * 24 * 365 * 10);
    if (error) throw new Error(error.message);
    return { url: signed.signedUrl, path: data.path };
  });
