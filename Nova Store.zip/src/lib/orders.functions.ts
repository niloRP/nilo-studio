import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";

const orderItemSchema = z.object({
  product_id: z.string().uuid(),
  qty: z.number().int().min(1).max(99),
});

function isValidCpf(value: string) {
  const cpf = value.replace(/\D/g, "");
  if (cpf.length !== 11 || /^(\d)\1+$/.test(cpf)) return false;
  const calc = (base: string, factor: number) => {
    let total = 0;
    for (const digit of base) total += Number(digit) * factor--;
    const rest = (total * 10) % 11;
    return rest === 10 ? 0 : rest;
  };
  return calc(cpf.slice(0, 9), 10) === Number(cpf[9]) && calc(cpf.slice(0, 10), 11) === Number(cpf[10]);
}

const createOrderSchema = z.object({
  customer_name: z.string().trim().min(2).max(120),
  customer_document: z
    .string()
    .trim()
    .regex(/^\d{11}$/, "CPF inválido")
    .refine(isValidCpf, "CPF inválido"),
  customer_phone: z
    .string()
    .trim()
    .min(8)
    .max(25)
    .regex(/^[0-9()\s+-]+$/, "Telefone inválido"),
  customer_email: z
    .string()
    .trim()
    .email()
    .max(160)
    .optional()
    .or(z.literal("").transform(() => undefined)),
  address_cep: z.string().trim().min(8).max(12),
  address_street: z.string().trim().min(2).max(160),
  address_number: z.string().trim().min(1).max(20),
  address_complement: z.string().trim().max(80).optional().or(z.literal("").transform(() => undefined)),
  address_neighborhood: z.string().trim().min(2).max(120),
  address_city: z.string().trim().min(2).max(80),
  address_uf: z.string().trim().length(2),
  notes: z.string().max(500).optional(),
  items: z.array(orderItemSchema).min(1).max(50),
});


export const createOrder = createServerFn({ method: "POST" })
  .inputValidator((d) => createOrderSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import(
      "@/integrations/supabase/client.server"
    );

    // Try to identify the user from the incoming bearer token (optional)
    let userId: string | null = null;
    try {
      const { getRequest } = await import("@tanstack/react-start/server");
      const req = getRequest();
      const auth = req?.headers?.get("authorization") ?? null;
      const token = auth?.startsWith("Bearer ") ? auth.slice(7) : null;
      if (token) {
        const { data: u } = await supabaseAdmin.auth.getUser(token);
        userId = u.user?.id ?? null;
      }
    } catch {
      // ignore — anonymous order
    }

    const ids = data.items.map((i) => i.product_id);
    const { data: products, error: pe } = await supabaseAdmin
      .from("products")
      .select("id,name,slug,price,promo_price,stock,active")
      .in("id", ids);
    if (pe) throw new Error(pe.message);

    const items = data.items.map((it) => {
      const p = products?.find((x) => x.id === it.product_id);
      if (!p || !p.active) throw new Error("Produto indisponível.");
      const price = Number(p.price);
      const promo = p.promo_price == null ? null : Number(p.promo_price);
      const unit = promo != null && promo > 0 && promo < price ? promo : price;
      return {
        product_id: p.id,
        product_name: p.name,
        product_slug: p.slug,
        unit_price: unit,
        qty: it.qty,
        subtotal: unit * it.qty,
      };
    });
    const total = items.reduce((s, i) => s + i.subtotal, 0);

    const addressLine = [
      `${data.address_street}, ${data.address_number}`,
      data.address_complement ? `(${data.address_complement})` : null,
      data.address_neighborhood,
    ]
      .filter(Boolean)
      .join(" — ");

    const { data: order, error: oe } = await supabaseAdmin
      .from("orders")
      .insert({
        user_id: userId,
        customer_name: data.customer_name,
        customer_document: data.customer_document,
        customer_phone: data.customer_phone,
        customer_email: data.customer_email ?? null,
        address_cep: data.address_cep,
        address_line: addressLine,
        address_street: data.address_street,
        address_number: data.address_number,
        address_complement: data.address_complement ?? null,
        address_neighborhood: data.address_neighborhood,
        address_city: data.address_city,
        address_uf: data.address_uf.toUpperCase(),
        notes: data.notes ?? null,
        total,
      })
      .select("id,code")
      .single();
    if (oe) throw new Error(oe.message);


    const { error: ie } = await supabaseAdmin
      .from("order_items")
      .insert(items.map((i) => ({ ...i, order_id: order.id })));
    if (ie) throw new Error(ie.message);

    return { id: order.id, code: order.code, total };
  });
