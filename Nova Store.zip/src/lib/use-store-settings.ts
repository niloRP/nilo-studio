import { useQuery, queryOptions } from "@tanstack/react-query";
import { getStoreSettings, type StoreSettings } from "@/lib/settings.functions";

export const storeSettingsQO = queryOptions({
  queryKey: ["store-settings"],
  queryFn: () => getStoreSettings(),
  staleTime: 60_000,
});

const DEFAULTS: StoreSettings = {
  store_name: "iPhone SP",
  tagline: null,
  description: null,
  logo_url: null,
  favicon_url: null,
  primary_color: null,
  contact_email: null,
  contact_phone: null,
  whatsapp: null,
  address: null,
  cnpj: null,
  instagram_url: null,
  facebook_url: null,
  twitter_url: null,
  youtube_url: null,
  tiktok_url: null,
  footer_text: null,
};

export function useStoreSettings(): StoreSettings {
  const { data } = useQuery(storeSettingsQO);
  return (data ?? DEFAULTS) as StoreSettings;
}
