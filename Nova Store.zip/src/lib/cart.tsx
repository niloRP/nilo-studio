import { createContext, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";
import { supabase } from "@/integrations/supabase/client";
import { getSavedCart, saveCart } from "@/lib/account.functions";

export type CartItem = {
  id: string;
  slug: string;
  name: string;
  brand: string | null;
  price: number;
  image: string;
  qty: number;
};

type CartContextValue = {
  items: CartItem[];
  detailed: { product: CartItem; qty: number; subtotal: number }[];
  count: number;
  total: number;
  add: (item: Omit<CartItem, "qty">, qty?: number) => void;
  remove: (id: string) => void;
  setQty: (id: string, qty: number) => void;
  clear: () => void;
  isOpen: boolean;
  setOpen: (v: boolean) => void;
};

const CartContext = createContext<CartContextValue | null>(null);
const STORAGE_KEY = "iphone sp.cart.v2";

function mergeCarts(a: CartItem[], b: CartItem[]): CartItem[] {
  const map = new Map<string, CartItem>();
  for (const it of a) map.set(it.id, { ...it });
  for (const it of b) {
    const cur = map.get(it.id);
    if (cur) map.set(it.id, { ...cur, qty: Math.max(cur.qty, it.qty) });
    else map.set(it.id, { ...it });
  }
  return Array.from(map.values());
}

export function CartProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [isOpen, setOpen] = useState(false);
  const [hydrated, setHydrated] = useState(false);
  const userIdRef = useRef<string | null>(null);
  const skipNextSyncRef = useRef(false);

  // Load localStorage cart on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) setItems(JSON.parse(raw));
    } catch {}
    setHydrated(true);
  }, []);

  // Persist to localStorage
  useEffect(() => {
    if (!hydrated) return;
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(items));
    } catch {}
  }, [items, hydrated]);

  // Sync with backend on auth changes
  useEffect(() => {
    if (!hydrated) return;
    let cancelled = false;

    const loadRemote = async (uid: string) => {
      try {
        const remote = (await getSavedCart()) as CartItem[];
        if (cancelled) return;
        const local = items;
        const merged = mergeCarts(local, remote ?? []);
        skipNextSyncRef.current = true;
        setItems(merged);
        // push merged back to remote
        await saveCart({ data: { items: merged } });
      } catch {
        // ignore
      }
    };

    supabase.auth.getSession().then(({ data }) => {
      const uid = data.session?.user.id ?? null;
      if (uid && uid !== userIdRef.current) {
        userIdRef.current = uid;
        void loadRemote(uid);
      }
    });

    const { data: sub } = supabase.auth.onAuthStateChange((event, session) => {
      const uid = session?.user.id ?? null;
      if (event === "SIGNED_IN" && uid && uid !== userIdRef.current) {
        userIdRef.current = uid;
        void loadRemote(uid);
      } else if (event === "SIGNED_OUT") {
        userIdRef.current = null;
      }
    });

    return () => {
      cancelled = true;
      sub.subscription.unsubscribe();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [hydrated]);

  // Push cart changes to backend (debounced)
  useEffect(() => {
    if (!hydrated) return;
    if (!userIdRef.current) return;
    if (skipNextSyncRef.current) {
      skipNextSyncRef.current = false;
      return;
    }
    const t = setTimeout(() => {
      saveCart({ data: { items } }).catch(() => {});
    }, 600);
    return () => clearTimeout(t);
  }, [items, hydrated]);

  const value = useMemo<CartContextValue>(() => {
    const detailed = items.map((i) => ({
      product: i,
      qty: i.qty,
      subtotal: i.price * i.qty,
    }));
    const count = items.reduce((s, i) => s + i.qty, 0);
    const total = detailed.reduce((s, d) => s + d.subtotal, 0);

    return {
      items,
      detailed,
      count,
      total,
      isOpen,
      setOpen,
      add: (item, qty = 1) =>
        setItems((prev) => {
          const existing = prev.find((i) => i.id === item.id);
          if (existing) return prev.map((i) => (i.id === item.id ? { ...i, qty: i.qty + qty } : i));
          return [...prev, { ...item, qty }];
        }),
      remove: (id) => setItems((prev) => prev.filter((i) => i.id !== id)),
      setQty: (id, qty) =>
        setItems((prev) =>
          qty <= 0 ? prev.filter((i) => i.id !== id) : prev.map((i) => (i.id === id ? { ...i, qty } : i)),
        ),
      clear: () => setItems([]),
    };
  }, [items, isOpen]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart deve ser usado dentro de <CartProvider>");
  return ctx;
}
