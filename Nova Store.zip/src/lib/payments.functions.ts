import { createServerFn } from "@tanstack/react-start";
import { z } from "zod";
import { requireSupabaseAuth } from "@/integrations/supabase/auth-middleware";

/** VirtualPay V2 recebe valor em reais. R$ 820,00 = 820. */
export function toVirtualPayAmount(reais: number): number {
  if (!Number.isFinite(reais) || reais <= 0) throw new Error("Valor inválido");
  return Math.max(1, Math.round(reais * 100) / 100);
}

function vpHeaders(clientId: string, clientSecret: string): Record<string, string> {
  return {
    "Content-Type": "application/json",
    Accept: "application/json",
    "x-client-id": clientId,
    "x-client-secret": clientSecret,
  };
}

const cleanDigits = (value: unknown) => String(value ?? "").replace(/\D/g, "");

function maskSensitivePayload(payload: Record<string, any>) {
  const clone = JSON.parse(JSON.stringify(payload));
  const maskDoc = (doc: unknown) => {
    const d = cleanDigits(doc);
    return d ? `${d.slice(0, 3)}***${d.slice(-2)}` : null;
  };
  const maskEmail = (email: unknown) => {
    const e = String(email ?? "");
    const [name, domain] = e.split("@");
    return name && domain ? `${name.slice(0, 2)}***@${domain}` : null;
  };
  if (clone.document) clone.document = maskDoc(clone.document);
  if (clone.email) clone.email = maskEmail(clone.email);
  if (clone.customer?.document) clone.customer.document = maskDoc(clone.customer.document);
  if (clone.customer?.email) clone.customer.email = maskEmail(clone.customer.email);
  if (clone.payer?.document) clone.payer.document = maskDoc(clone.payer.document);
  if (clone.payer?.email) clone.payer.email = maskEmail(clone.payer.email);
  return clone;
}

function collectProviderErrors(body: any): string {
  const errors = body?.errors ?? body?.error ?? body?.data?.errors;
  if (!errors) return "";
  if (Array.isArray(errors)) return errors.map(String).join(" ");
  if (typeof errors === "string") return errors;
  if (typeof errors === "object") return Object.values(errors).flat().map(String).join(" ");
  return "";
}

function providerErrorMessage(body: any, status: number) {
  const message = body?.message ?? body?.data?.message ?? body?.error_message ?? body?.error;
  const errors = collectProviderErrors(body);
  const detail = [message, errors].filter(Boolean).join(" ").trim();
  return detail || `Erro VirtualPay (HTTP ${status})`;
}

function extractPixData(body: any) {
  const d = body?.data ?? body?.transaction ?? body;
  const pix = d?.pix ?? d?.pix_qr_code ?? d?.payment?.pix ?? body?.pix ?? {};
  return {
    transactionId: d?.id ?? d?.uuid ?? d?.transactionId ?? d?.transaction_id ?? d?.identifier ?? null,
    copy:
      d?.copy_paste ??
      d?.copyPaste ??
      d?.pix_copy_paste ??
      d?.pixCopyPaste ??
      d?.qrcode ??
      d?.qr_code_text ??
      pix?.qrcode ??
      pix?.qrCode ??
      pix?.copy_paste ??
      pix?.copyPaste ??
      pix?.payload ??
      null,
    qr:
      d?.qr_code_image ??
      d?.qrCodeImage ??
      d?.qr_code ??
      d?.qrcode_image ??
      pix?.base64 ??
      pix?.qr_code ??
      pix?.qrCodeImage ??
      pix?.image ??
      null,
    status: String(d?.status ?? body?.status ?? "pending").toLowerCase(),
  };
}

async function loadSettings() {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("payment_settings")
    .select("*")
    .eq("id", 1)
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Configurações de pagamento não encontradas.");
  return data;
}

async function assertAdmin(userId: string) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin
    .from("user_roles")
    .select("role")
    .eq("user_id", userId)
    .eq("role", "admin")
    .maybeSingle();
  if (error) throw new Error(error.message);
  if (!data) throw new Error("Acesso negado.");
}

/* ============================================================
   ADMIN: configurações
   ============================================================ */

export const getPaymentSettings = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const s = await loadSettings();
    return {
      client_id: s.client_id ?? "",
      client_secret: s.client_secret ?? "",
      api_url: s.api_url ?? "",
      webhook_secret: s.webhook_secret ?? "",
      webhook_signature_header: s.webhook_signature_header ?? "x-webhook-signature",
      active: !!s.active,
      updated_at: s.updated_at,
    };
  });

const savePaymentSchema = z.object({
  client_id: z.string().trim().max(200),
  client_secret: z.string().trim().max(500),
  api_url: z.string().trim().url().max(300),
  webhook_secret: z.string().trim().max(500),
  webhook_signature_header: z.string().trim().min(1).max(120),
  active: z.boolean(),
});

export const savePaymentSettings = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .inputValidator((d) => savePaymentSchema.parse(d))
  .handler(async ({ data, context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { error } = await supabaseAdmin
      .from("payment_settings")
      .update({
        client_id: data.client_id || null,
        client_secret: data.client_secret || null,
        api_url: data.api_url,
        webhook_secret: data.webhook_secret || null,
        webhook_signature_header: data.webhook_signature_header,
        active: data.active,
      })
      .eq("id", 1);
    if (error) throw new Error(error.message);
    return { ok: true };
  });

export const testVirtualPayConnection = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const s = await loadSettings();
    if (!s.client_id || !s.client_secret) {
      return { ok: false, message: "Client ID e Secret são obrigatórios." };
    }
    try {
      const res = await fetch(`${s.api_url}/balance`, {
        method: "POST",
        headers: vpHeaders(s.client_id, s.client_secret),
      });
      const txt = await res.text();
      if (!res.ok) return { ok: false, message: `HTTP ${res.status}: ${txt.slice(0, 240)}` };
      return { ok: true, message: "Conexão OK com VirtualPay V2." };
    } catch (e) {
      return { ok: false, message: e instanceof Error ? e.message : "Falha na requisição." };
    }
  });

export const getVirtualPayBalance = createServerFn({ method: "POST" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const s = await loadSettings();
    if (!s.client_id || !s.client_secret) throw new Error("Credenciais não configuradas.");
    const res = await fetch(`${s.api_url}/balance`, {
      method: "POST",
      headers: vpHeaders(s.client_id, s.client_secret),
    });
    const txt = await res.text();
    let body: any = {};
    try { body = JSON.parse(txt); } catch {}
    if (!res.ok) throw new Error(body?.message || `HTTP ${res.status}`);
    return body;
  });

/* ============================================================
   FINANCEIRO (admin)
   ============================================================ */

export const getFinancialStats = createServerFn({ method: "GET" })
  .middleware([requireSupabaseAuth])
  .handler(async ({ context }) => {
    await assertAdmin(context.userId);
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data, error } = await supabaseAdmin
      .from("orders")
      .select("id,total,status,created_at");
    if (error) throw new Error(error.message);

    const now = new Date();
    const startToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    let salesToday = 0,
      salesMonth = 0,
      received = 0,
      pending = 0,
      ordersCount = 0,
      paidCount = 0;

    for (const o of data ?? []) {
      const t = Number(o.total);
      const created = new Date(o.created_at as string);
      ordersCount++;
      if (o.status === "pago" || o.status === "separando" || o.status === "em_envio" || o.status === "entregue") {
        received += t;
        paidCount++;
        if (created >= startToday) salesToday += t;
        if (created >= startMonth) salesMonth += t;
      } else if (o.status === "aguardando_pagamento") {
        pending += t;
      }
    }

    return {
      salesToday,
      salesMonth,
      received,
      pending,
      ordersCount,
      paidCount,
      avgTicket: paidCount > 0 ? received / paidCount : 0,
    };
  });

/* ============================================================
   PÚBLICO: criar cobrança PIX para um pedido
   ============================================================ */

const createPixSchema = z.object({
  order_id: z.string().uuid(),
});

export const createPixCharge = createServerFn({ method: "POST" })
  .inputValidator((d) => createPixSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

    const { data: order, error: oe } = await supabaseAdmin
      .from("orders")
      .select("id,code,total,status,customer_name,customer_document,customer_phone,customer_email,address_cep,address_city,address_uf")
      .eq("id", data.order_id)
      .maybeSingle();
    if (oe) throw new Error(oe.message);
    if (!order) throw new Error("Pedido não encontrado.");
    if (order.status !== "aguardando_pagamento") {
      // já existe / já pago — devolve a última transação se houver
      const { data: existing } = await supabaseAdmin
        .from("pix_transactions")
        .select("reference,copy_paste,qr_code,status,amount")
        .eq("order_id", order.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();
      if (existing) {
        return {
          reference: existing.reference,
          copy_paste: existing.copy_paste,
          qr_code: existing.qr_code,
          status: existing.status,
          amount: Number(existing.amount),
        };
      }
      throw new Error("Pedido não está aguardando pagamento.");
    }

    // reutiliza transação pendente se já existir
    const { data: pending } = await supabaseAdmin
      .from("pix_transactions")
      .select("reference,copy_paste,qr_code,status,amount")
      .eq("order_id", order.id)
      .eq("status", "pending")
      .order("created_at", { ascending: false })
      .limit(1)
      .maybeSingle();
    if (pending && pending.copy_paste) {
      return {
        reference: pending.reference,
        copy_paste: pending.copy_paste,
        qr_code: pending.qr_code,
        status: pending.status,
        amount: Number(pending.amount),
      };
    }

    const s = await loadSettings();
    if (!s.active) throw new Error("Pagamento PIX indisponível no momento.");
    if (!s.client_id || !s.client_secret) throw new Error("Credenciais da VirtualPay não configuradas.");

    const totalReais = Number(order.total);
    const amountSent = toVirtualPayAmount(totalReais);
    const reference = `${order.code}-${Date.now().toString(36).toUpperCase()}`;
    const customerName = String(order.customer_name ?? "").trim();
    const customerDocument = cleanDigits(order.customer_document);
    const customerPhone = cleanDigits(order.customer_phone);
    const customerEmail = String(order.customer_email ?? "").trim().toLowerCase();

    if (!customerName || customerName.length < 3) throw new Error("Informe o nome completo do comprador.");
    if (customerDocument.length !== 11) throw new Error("Informe um CPF válido para gerar o Pix.");
    if (customerPhone.length < 10) throw new Error("Informe um celular válido para gerar o Pix.");
    if (!/^\S+@\S+\.\S+$/.test(customerEmail)) throw new Error("Informe um e-mail válido para gerar o Pix.");

    const payload = {
      type: "deposit",
      payment_method: "pix",
      description: `Pedido ${order.code}`,
      amount: amountSent,
      reference,
      name: customerName,
      email: customerEmail,
      phone: customerPhone,
      document: customerDocument,
    };

    console.info("[VirtualPay] criando cobrança PIX", {
      order_id: order.id,
      reference,
      amount_reais: totalReais,
      amount_sent: amountSent,
      api_url: s.api_url,
      payload: maskSensitivePayload(payload),
    });

    const res = await fetch(`${s.api_url}/transactions`, {
      method: "POST",
      headers: vpHeaders(s.client_id, s.client_secret),
      body: JSON.stringify(payload),
    });
    
    const txt = await res.text();
    let body: any = {};
    try { body = JSON.parse(txt); } catch {}
    console.info("[VirtualPay] resposta criação PIX", {
      reference,
      http_status: res.status,
      ok: res.ok,
      provider_status: body?.status ?? body?.data?.status ?? null,
      provider_code: body?.code ?? body?.error_code ?? null,
      message: body?.message ?? body?.data?.message ?? null,
      errors: body?.errors ?? body?.data?.errors ?? null,
    });
    if (!res.ok) {
      console.error("[VirtualPay] criar cobrança falhou", {
        reference,
        http_status: res.status,
        response: txt.slice(0, 2000),
      });
      throw new Error(providerErrorMessage(body, res.status));
    }

    const { transactionId, copy, qr, status } = extractPixData(body);
    if (!copy) {
      console.error("[VirtualPay] resposta sem Pix copia e cola", {
        reference,
        transaction_id: transactionId,
        response: txt.slice(0, 2000),
      });
      throw new Error("A VirtualPay aprovou a solicitação, mas não retornou o código Pix. Tente novamente em instantes.");
    }


    const { error: ie } = await supabaseAdmin.from("pix_transactions").insert({
      order_id: order.id,
      reference,
      transaction_id: transactionId,
      amount: totalReais,
      amount_sent: amountSent,
      status: status || "pending",
      copy_paste: copy,
      qr_code: qr,
      raw_response: body,
    });
    if (ie) throw new Error(ie.message);

    return {
      reference,
      copy_paste: copy,
      qr_code: qr,
      status: status || "pending",
      amount: totalReais,
    };
  });

/* ============================================================
   PÚBLICO: consultar status de uma cobrança (polling)
   ============================================================ */

const getPixStatusSchema = z.object({ reference: z.string().min(4).max(120) });

export const getPixStatus = createServerFn({ method: "POST" })
  .inputValidator((d) => getPixStatusSchema.parse(d))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: tx, error } = await supabaseAdmin
      .from("pix_transactions")
      .select("status,transaction_id,order_id,reference")
      .eq("reference", data.reference)
      .maybeSingle();
    if (error) throw new Error(error.message);
    if (!tx) throw new Error("Transação não encontrada.");

    // Se já pago no banco, devolve direto
    if (tx.status === "paid") return { status: "paid" as const };

    // Reconsulta API VirtualPay se tivermos transaction_id
    if (tx.transaction_id) {
      try {
        const s = await loadSettings();
        if (s.active && s.client_id && s.client_secret) {
          const res = await fetch(`${s.api_url}/transactions/${tx.transaction_id}`, {
            method: "GET",
            headers: vpHeaders(s.client_id, s.client_secret),
          });
          if (res.ok) {
            const body = await res.json().catch(() => ({}));
            const remoteStatus = (body?.status ?? body?.data?.status ?? "").toLowerCase();
            if (remoteStatus && remoteStatus !== tx.status) {
              await applyStatusChange(tx.order_id, tx.reference, remoteStatus, body);
              return { status: remoteStatus as string };
            }
          }
        }
      } catch (e) {
        console.error("[VirtualPay] poll status falhou:", e);
      }
    }

    return { status: tx.status };
  });

/* ============================================================
   Util compartilhado: aplicar mudança de status (webhook + polling)
   ============================================================ */

export async function applyStatusChange(
  orderId: string,
  reference: string,
  newStatus: string,
  raw: unknown,
) {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const raw_norm = newStatus.toLowerCase();
  // Normaliza status VirtualPay V2: paid/approved/completed → paid; refused/cancelled/expired/refunded → cancelled
  const isPaid = ["paid", "approved", "completed", "success"].includes(raw_norm);
  const isCancelled = ["refused", "cancelled", "canceled", "expired", "refunded", "chargeback", "failed"].includes(raw_norm);
  const norm = isPaid ? "paid" : isCancelled ? "cancelled" : raw_norm;
  const patch = {
    status: norm,
    raw_response: raw as any,
    ...(isPaid ? { paid_at: new Date().toISOString() } : {}),
  };

  await supabaseAdmin.from("pix_transactions").update(patch).eq("reference", reference);

  if (isPaid) {
    await supabaseAdmin.from("orders").update({ status: "pago" }).eq("id", orderId);
  } else if (isCancelled) {
    await supabaseAdmin.from("orders").update({ status: "cancelado" }).eq("id", orderId);
  }
}
