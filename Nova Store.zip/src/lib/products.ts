export type ProductImage = {
  id: string;
  url: string;
  storage_path: string | null;
  is_primary: boolean;
  sort_order: number;
};

export type ProductVideo = {
  id: string;
  url: string;
  storage_path: string | null;
  title: string | null;
  sort_order: number;
};

export type ProductSpec = { label: string; value: string };

export type ProductCondition = "novo" | "seminovo";

export type Product = {
  id: string;
  slug: string;
  name: string;
  brand: string | null;
  model: string | null;
  color: string | null;
  storage: string | null;
  ram: string | null;
  condition: ProductCondition;
  category_slug: string | null;
  price: number;
  promo_price: number | null;
  old_price: number | null;
  badge: string | null;
  rating: number;
  reviews: number;
  stock: number;
  low_stock_threshold: number;
  short_description: string | null;
  description: string | null;
  specs: ProductSpec[];
  tags: string[];
  featured: boolean;
  active: boolean;
  image: string;
  images: ProductImage[];
  videos: ProductVideo[];
};

export type Category = {
  id: string;
  slug: string;
  name: string;
  icon: string | null;
  sort_order: number;
};

export const ORDER_STATUSES = [
  { value: "aguardando_pagamento", label: "Aguardando pagamento" },
  { value: "pago", label: "Pago" },
  { value: "separando", label: "Separando pedido" },
  { value: "em_envio", label: "Em envio" },
  { value: "entregue", label: "Entregue" },
  { value: "cancelado", label: "Cancelado" },
] as const;

export type OrderStatus = (typeof ORDER_STATUSES)[number]["value"];

export function formatBRL(v: number) {
  return v.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

const PLACEHOLDER_IMG =
  "data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 400 400'><rect width='400' height='400' fill='%231a1a1a'/><text x='200' y='200' fill='%23555' font-family='monospace' font-size='14' text-anchor='middle' dominant-baseline='middle'>SEM FOTO</text></svg>";

export function primaryImage(images: ProductImage[] | null | undefined): string {
  if (!images || images.length === 0) return PLACEHOLDER_IMG;
  const primary = images.find((i) => i.is_primary) ?? images[0];
  return primary.url;
}

export function effectivePrice(p: Pick<Product, "price" | "promo_price">): number {
  return p.promo_price != null && p.promo_price > 0 && p.promo_price < p.price
    ? p.promo_price
    : p.price;
}
