import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { listMyFavorites, toggleFavorite } from "@/lib/account.functions";
import { useAuth } from "@/lib/use-auth";

export function useFavorites() {
  const { user } = useAuth();
  const list = useServerFn(listMyFavorites);
  const toggle = useServerFn(toggleFavorite);
  const qc = useQueryClient();

  const query = useQuery({
    queryKey: ["my-favorites", user?.id],
    queryFn: () => list(),
    enabled: !!user,
    staleTime: 30_000,
  });

  const mutation = useMutation({
    mutationFn: (product_id: string) => toggle({ data: { product_id } }),
    onMutate: async (product_id) => {
      await qc.cancelQueries({ queryKey: ["my-favorites", user?.id] });
      const prev = qc.getQueryData<string[]>(["my-favorites", user?.id]) ?? [];
      const next = prev.includes(product_id)
        ? prev.filter((id) => id !== product_id)
        : [...prev, product_id];
      qc.setQueryData(["my-favorites", user?.id], next);
      return { prev };
    },
    onError: (_e, _v, ctx) => {
      if (ctx?.prev) qc.setQueryData(["my-favorites", user?.id], ctx.prev);
    },
    onSettled: () => qc.invalidateQueries({ queryKey: ["my-favorites", user?.id] }),
  });

  return {
    ids: query.data ?? [],
    isFavorite: (id: string) => (query.data ?? []).includes(id),
    toggle: mutation.mutate,
    isLoggedIn: !!user,
  };
}
