import { createFileRoute, Link } from "@tanstack/react-router";
import { useSuspenseQuery, queryOptions } from "@tanstack/react-query";
import { ArrowRight, Truck, ShieldCheck, Zap, Sparkles, Smartphone, PackageOpen } from "lucide-react";
import { ProductCard } from "@/components/ProductCard";
import { TestimonialsCarousel } from "@/components/TestimonialsCarousel";
import { listPublicCatalog } from "@/lib/products.functions";
import { effectivePrice, formatBRL, type Product, type Category } from "@/lib/products";

const catalogQO = queryOptions({
  queryKey: ["catalog"],
  queryFn: () => listPublicCatalog(),
});

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "IPHONE SP — iPhone e Xiaomi com pagamento via Pix" },
      {
        name: "description",
        content:
          "Loja especializada em iPhone e Xiaomi. Modelos novos e seminovos com garantia, envio para todo o Brasil e pagamento exclusivo via Pix.",
      },
      { property: "og:title", content: "IPHONE SP — iPhone e Xiaomi" },
      {
        property: "og:description",
        content: "iPhone e Xiaomi com pagamento via Pix e garantia oficial.",
      },
    ],
  }),
  loader: ({ context }) => context.queryClient.ensureQueryData(catalogQO),
  component: Home,
  errorComponent: ({ error }) => (
    <div className="mx-auto max-w-md p-8 text-center text-sm text-muted-foreground">
      Erro ao carregar produtos: {error.message}
    </div>
  ),
  notFoundComponent: () => <div className="p-8">Sem produtos.</div>,
});

function Home() {
  const { data } = useSuspenseQuery(catalogQO);
  const products = data.products;
  const categories = data.categories;
  const featured = products.filter((p) => p.featured);
  const hero = featured[0] ?? products[0];

  return (
    <div className="flex flex-col">
      <section className="relative overflow-hidden border-b border-border">
        <div className="absolute inset-0 grid-bg opacity-50" aria-hidden />
        <div
          className="pointer-events-none absolute -top-40 left-1/2 h-[500px] w-[800px] -translate-x-1/2 rounded-full opacity-30 blur-3xl"
          style={{
            background: "radial-gradient(circle, var(--color-primary), transparent 60%)",
          }}
          aria-hidden
        />
        <div className="relative mx-auto grid max-w-7xl gap-10 px-4 py-12 md:grid-cols-2 md:px-6 md:py-20">
          <div className="flex flex-col justify-center">
            <span className="chip mb-5 w-fit">
              <Sparkles className="h-3 w-3 text-primary" />
              Especialistas em iPhone & Xiaomi
            </span>
            <h1 className="font-display text-4xl font-bold leading-[1.05] tracking-tight md:text-6xl">
              Seu próximo
              <br />
              <span className="text-primary glow-text">smartphone</span> está aqui.
            </h1>
            <p className="mt-5 max-w-md text-sm text-muted-foreground md:text-base">
              Aparelhos novos e seminovos, com garantia, nota fiscal e pagamento instantâneo via Pix. Curadoria 100%
              iPhone e Xiaomi.
            </p>
            <div className="mt-7 flex flex-wrap gap-3">
              <a
                href="#cat-iphone"
                className="group inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-3 font-display text-sm font-bold text-primary-foreground transition-all hover:bg-primary-glow hover:shadow-[var(--shadow-glow)]"
              >
                Ver iPhones
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </a>
              <a
                href="#cat-xiaomi"
                className="inline-flex items-center gap-2 rounded-xl border border-border-strong bg-surface px-5 py-3 font-display text-sm font-bold text-foreground transition-colors hover:bg-surface-elevated"
              >
                Ver Xiaomi
              </a>
            </div>
          </div>

          {hero ? (
            <HeroProduct product={hero} />
          ) : (
            <div className="grid place-items-center rounded-3xl border border-dashed border-border bg-surface/40 p-10 text-center">
              <PackageOpen className="h-10 w-10 text-muted-foreground" />
              <p className="mt-3 text-sm text-muted-foreground">
                Nenhum produto cadastrado ainda. Acesse o painel para adicionar o primeiro iPhone ou Xiaomi.
              </p>
            </div>
          )}
        </div>

        <div className="relative border-t border-border bg-surface/50">
          <div className="mx-auto grid max-w-7xl gap-3 px-4 py-4 text-xs md:grid-cols-4 md:px-6">
            {[
              { i: Zap, t: "Pagamento via Pix", d: "Aprovação instantânea" },
              { i: Truck, t: "Envio para todo Brasil", d: "Despacho em 24h" },
              { i: ShieldCheck, t: "Garantia oficial", d: "12 meses + NF" },
              { i: Smartphone, t: "iPhone & Xiaomi", d: "Novos e seminovos" },
            ].map(({ i: Icon, t, d }) => (
              <div key={t} className="flex items-center gap-3">
                <div className="grid h-9 w-9 place-items-center rounded-lg border border-border bg-background text-primary">
                  <Icon className="h-4 w-4" />
                </div>
                <div>
                  <div className="text-sm font-semibold text-foreground">{t}</div>
                  <div className="text-muted-foreground">{d}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {featured.length > 1 && (
        <ProductSection
          id="destaques"
          eyebrow="Destaques"
          title="Selecionados pela loja"
          products={featured.slice(1)}
        />
      )}

      {categories.map((c: Category) => {
        const list = products.filter((p) => p.category_slug === c.slug);
        return (
          <ProductSection
            key={c.slug}
            id={`cat-${c.slug}`}
            eyebrow={c.name}
            title={`Linha ${c.name}`}
            products={list}
            emptyMessage={`Nenhum ${c.name} disponível no momento.`}
          />
        );
      })}

      <TestimonialsCarousel />
    </div>
  );
}

function HeroProduct({ product }: { product: Product }) {
  const price = effectivePrice(product);
  return (
    <div className="relative">
      <div
        className="absolute inset-0 -m-4 rounded-3xl border border-border-strong bg-surface/40 backdrop-blur"
        aria-hidden
      />
      <div className="relative aspect-[4/5] overflow-hidden rounded-3xl border border-border-strong bg-surface md:aspect-[5/6]">
        <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/30 to-transparent" />
        <div className="absolute bottom-0 left-0 right-0 p-6">
          <span className="chip mb-3">
            <Zap className="h-3 w-3 fill-primary text-primary" />
            Destaque
          </span>
          <h3 className="font-display text-2xl font-bold">{product.name}</h3>
          {product.short_description && (
            <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">{product.short_description}</p>
          )}
          <div className="mt-3 flex items-center gap-3">
            <div className="font-display text-2xl font-bold text-price">{formatBRL(price)}</div>
            {product.promo_price && product.promo_price < product.price && (
              <span className="text-sm text-muted-foreground line-through">{formatBRL(product.price)}</span>
            )}
          </div>
          <Link
            to="/produto/$slug"
            params={{ slug: product.slug }}
            className="mt-4 inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground transition-all hover:bg-primary-glow"
          >
            Comprar agora
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </div>
    </div>
  );
}

function SectionHeader({ eyebrow, title }: { eyebrow: string; title: string }) {
  return (
    <div className="flex items-end justify-between gap-4">
      <div>
        <div className="text-[10px] font-mono uppercase tracking-widest text-primary">{eyebrow}</div>
        <h2 className="mt-1 font-display text-2xl font-bold md:text-3xl">{title}</h2>
      </div>
    </div>
  );
}

function ProductSection({
  id,
  eyebrow,
  title,
  products,
  emptyMessage,
}: {
  id: string;
  eyebrow: string;
  title: string;
  products: Product[];
  emptyMessage?: string;
}) {
  return (
    <section id={id} className="mx-auto w-full max-w-7xl scroll-mt-20 px-4 py-10 md:px-6 md:py-14">
      <SectionHeader eyebrow={eyebrow} title={title} />
      {products.length === 0 ? (
        <div className="mt-6 rounded-2xl border border-dashed border-border bg-surface/40 p-8 text-center text-sm text-muted-foreground">
          {emptyMessage ?? "Em breve."}
        </div>
      ) : (
        <div className="mt-6 grid grid-cols-2 gap-4 md:grid-cols-3 lg:grid-cols-4">
          {products.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </section>
  );
}
