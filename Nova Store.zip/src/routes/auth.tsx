import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { z } from "zod";
import { Smartphone, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { lovable } from "@/integrations/lovable";

export const Route = createFileRoute("/auth")({
  validateSearch: z.object({ redirect: z.string().optional() }),
  head: () => ({
    meta: [{ title: "Entrar — IPHONE SP" }, { name: "robots", content: "noindex" }],
  }),
  component: AuthPage,
});

function AuthPage() {
  const navigate = useNavigate();
  const { redirect } = useSearch({ from: "/auth" });
  const [loading, setLoading] = useState<"google" | null>(null);
  const [error, setError] = useState<string | null>(null);

  const routeAfterLogin = async () => {
    if (redirect) return navigate({ to: redirect });
    const { data: sess } = await supabase.auth.getSession();
    const uid = sess.session?.user.id;
    if (!uid) return navigate({ to: "/" });
    const { data: role } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", uid)
      .eq("role", "admin")
      .maybeSingle();
    navigate({ to: role ? "/admin" : "/conta" });
  };

  useEffect(() => {
    supabase.auth.getSession().then(({ data }) => {
      if (data.session) void routeAfterLogin();
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const signInGoogle = async () => {
    setError(null);
    setLoading("google");
    try {
      const result = await lovable.auth.signInWithOAuth("google", {
        redirect_uri: window.location.origin + "/auth",
      });
      if (result.error) {
        setError(result.error instanceof Error ? result.error.message : "Falha no login Google.");
        setLoading(null);
        return;
      }
      if (result.redirected) return;
      await routeAfterLogin();
    } catch (e) {
      setError(e instanceof Error ? e.message : "Erro inesperado.");
      setLoading(null);
    }
  };

  return (
    <div className="mx-auto flex min-h-[80vh] max-w-md flex-col justify-center px-4 py-10">
      <Link
        to="/"
        className="mb-6 inline-flex items-center gap-2 self-start text-sm text-muted-foreground hover:text-foreground"
      >
        <div className="grid h-7 w-7 place-items-center rounded-lg bg-primary text-primary-foreground">
          <Smartphone className="h-3.5 w-3.5" />
        </div>
        iPhone SP
      </Link>

      <div className="rounded-3xl border border-border bg-surface p-8">
        <h1 className="font-display text-2xl font-bold">Entrar na iPhone SP</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Acesse com sua conta Google. Administradores entram automaticamente no painel.
        </p>

        <div className="mt-6 flex flex-col gap-4">
          <button
            type="button"
            onClick={signInGoogle}
            disabled={loading === "google"}
            className="inline-flex h-12 items-center justify-center gap-3 rounded-xl border border-border bg-background px-5 font-display text-sm font-bold text-foreground transition-colors hover:bg-surface-elevated disabled:opacity-60"
          >
            {loading === "google" ? <Loader2 className="h-4 w-4 animate-spin" /> : <GoogleIcon />}
            Continuar com Google
          </button>

          {error && (
            <div className="rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
              {error}
            </div>
          )}

          <p className="text-center text-[11px] text-muted-foreground">
            Ao continuar, você concorda com nossos termos de uso. Sua sessão permanece ativa entre visitas.
          </p>
        </div>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="h-4 w-4" aria-hidden="true">
      <path
        fill="#EA4335"
        d="M12 10.2v3.9h5.5c-.2 1.4-1.7 4.1-5.5 4.1-3.3 0-6-2.7-6-6.1s2.7-6.1 6-6.1c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.7 3.4 14.6 2.4 12 2.4 6.7 2.4 2.4 6.7 2.4 12s4.3 9.6 9.6 9.6c5.5 0 9.2-3.9 9.2-9.4 0-.6-.1-1.1-.2-1.6H12z"
      />
    </svg>
  );
}
