import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { LogOut, ShieldAlert, Trash2, Loader2 } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { deleteMyAccount } from "@/lib/account.functions";
import { useProfile } from "@/lib/use-profile";

export const Route = createFileRoute("/_authenticated/conta/configuracoes")({
  component: Settings,
});

function Settings() {
  const navigate = useNavigate();
  const { data: profile } = useProfile();
  const [confirming, setConfirming] = useState(false);
  const deleteFn = useServerFn(deleteMyAccount);

  const delMut = useMutation({
    mutationFn: () => deleteFn(),
    onSuccess: async () => {
      await supabase.auth.signOut();
      navigate({ to: "/" });
    },
  });

  return (
    <div className="space-y-5">
      <h1 className="font-display text-2xl font-bold">Configurações</h1>

      <section className="rounded-2xl border border-border bg-surface p-6">
        <h2 className="font-display font-semibold">Conta conectada</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Você está conectado com o Google usando <strong>{profile?.email}</strong>.
        </p>
      </section>

      <section className="rounded-2xl border border-border bg-surface p-6">
        <h2 className="font-display font-semibold">Sessões</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Encerre a sessão atual neste dispositivo.
        </p>
        <button
          onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/" });
          }}
          className="mt-4 inline-flex items-center gap-2 rounded-xl border border-border bg-background px-4 py-2 text-sm hover:bg-surface-elevated"
        >
          <LogOut className="h-4 w-4" />
          Sair desta sessão
        </button>
      </section>

      <section className="rounded-2xl border border-destructive/40 bg-destructive/5 p-6">
        <h2 className="flex items-center gap-2 font-display font-semibold text-destructive">
          <ShieldAlert className="h-4 w-4" /> Zona de risco
        </h2>
        <p className="mt-1 text-sm text-muted-foreground">
          Excluir sua conta remove permanentemente seu perfil, endereços, favoritos e carrinho salvo. Pedidos
          anteriores são mantidos no histórico da loja.
        </p>
        {!confirming ? (
          <button
            onClick={() => setConfirming(true)}
            className="mt-4 inline-flex items-center gap-2 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-2 text-sm text-destructive hover:bg-destructive/20"
          >
            <Trash2 className="h-4 w-4" />
            Excluir minha conta
          </button>
        ) : (
          <div className="mt-4 flex flex-wrap gap-2">
            <button
              onClick={() => delMut.mutate()}
              disabled={delMut.isPending}
              className="inline-flex items-center gap-2 rounded-xl bg-destructive px-4 py-2 text-sm font-bold text-destructive-foreground hover:opacity-90 disabled:opacity-50"
            >
              {delMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              Confirmar exclusão
            </button>
            <button
              onClick={() => setConfirming(false)}
              className="rounded-xl border border-border px-4 py-2 text-sm"
            >
              Cancelar
            </button>
          </div>
        )}
        {delMut.error && (
          <div className="mt-3 text-sm text-destructive">{(delMut.error as Error).message}</div>
        )}
      </section>
    </div>
  );
}
