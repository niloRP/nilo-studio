import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Heart } from "lucide-react";
import { listMyFavorites } from "@/lib/account.functions";
import { listPublicCatalog } from "@/lib/products.functions";
import { useAuth } from "@/lib/use-auth";
import { ProductCard } from "@/components/ProductCard";

export const Route = createFileRoute("/_authenticated/conta/favoritos")({
  component: FavoritesPage,
});

function FavoritesPage() {
  const { user } = useAuth();
  const favFn = useServerFn(listMyFavorites);
  const catFn = useServerFn(listPublicCatalog);

  const { data: favIds = [] } = useQuery({
    queryKey: ["my-favorites", user?.id],
    queryFn: () => favFn(),
    enabled: !!user,
  });

  const { data: catalog } = useQuery({
    queryKey: ["public-catalog"],
    queryFn: () => catFn(),
  });

  const favorites = (catalog?.products ?? []).filter((p) => favIds.includes(p.id));

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-bold">Favoritos</h1>
      {favorites.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-border bg-surface p-10 text-center text-sm text-muted-foreground">
          <Heart className="mx-auto h-8 w-8 opacity-50" />
          <p className="mt-3">Você ainda não favoritou nenhum produto.</p>
          <Link to="/" className="mt-4 inline-block text-primary hover:underline">
            Explorar a loja
          </Link>
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {favorites.map((p) => (
            <ProductCard key={p.id} product={p} />
          ))}
        </div>
      )}
    </div>
  );
}
