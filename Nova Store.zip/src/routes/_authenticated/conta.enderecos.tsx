import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { MapPin, Plus, Star, Trash2, Loader2, X, AlertCircle, CheckCircle2 } from "lucide-react";
import {
  listMyAddresses,
  upsertMyAddress,
  deleteMyAddress,
  setDefaultAddress,
} from "@/lib/account.functions";
import { useAuth } from "@/lib/use-auth";
import { fetchCep } from "@/lib/use-cep";

export const Route = createFileRoute("/_authenticated/conta/enderecos")({
  component: AddressesPage,
});

const onlyDigits = (v: string) => v.replace(/\D/g, "");
const maskCep = (v: string) => onlyDigits(v).slice(0, 8).replace(/(\d{5})(\d)/, "$1-$2");

const UFS = [
  "AC","AL","AP","AM","BA","CE","DF","ES","GO","MA","MT","MS","MG","PA","PB",
  "PR","PE","PI","RJ","RN","RS","RO","RR","SC","SP","SE","TO",
];

type AddressForm = {
  id?: string;
  label: string;
  cep: string;
  street: string;
  number: string;
  complement: string;
  district: string;
  city: string;
  state: string;
  is_default: boolean;
};

type Errors = Partial<Record<keyof AddressForm, string>>;

const emptyForm: AddressForm = {
  label: "Casa",
  cep: "",
  street: "",
  number: "",
  complement: "",
  district: "",
  city: "",
  state: "",
  is_default: false,
};

function validate(form: AddressForm): Errors {
  const e: Errors = {};
  if (!form.label.trim()) e.label = "Informe um rótulo (ex: Casa, Trabalho).";
  if (onlyDigits(form.cep).length !== 8) e.cep = "CEP deve ter 8 dígitos.";
  if (form.street.trim().length < 2) e.street = "Informe a rua.";
  if (!form.number.trim()) e.number = "Informe o número (use S/N se não houver).";
  if (form.district.trim().length < 2) e.district = "Informe o bairro.";
  if (form.city.trim().length < 2) e.city = "Informe a cidade.";
  if (!UFS.includes(form.state.toUpperCase())) e.state = "UF inválida.";
  return e;
}

function AddressesPage() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const listFn = useServerFn(listMyAddresses);
  const saveFn = useServerFn(upsertMyAddress);
  const delFn = useServerFn(deleteMyAddress);
  const defaultFn = useServerFn(setDefaultAddress);

  const { data = [], isLoading } = useQuery({
    queryKey: ["my-addresses", user?.id],
    queryFn: () => listFn(),
    enabled: !!user,
  });

  const [editing, setEditing] = useState<AddressForm | null>(null);
  const [errors, setErrors] = useState<Errors>({});
  const [cepLoading, setCepLoading] = useState(false);
  const [cepNotice, setCepNotice] = useState<{ kind: "ok" | "err"; msg: string } | null>(null);
  const numberRef = useRef<HTMLInputElement | null>(null);
  const lastFetchedCepRef = useRef<string>("");

  const saveMut = useMutation({
    mutationFn: (form: AddressForm) =>
      saveFn({
        data: {
          id: form.id,
          label: form.label.trim() || undefined,
          cep: onlyDigits(form.cep),
          street: form.street.trim(),
          number: form.number.trim(),
          complement: form.complement.trim() || undefined,
          district: form.district.trim(),
          city: form.city.trim(),
          state: form.state.toUpperCase(),
          is_default: form.is_default,
        },
      }),
    onSuccess: () => {
      setEditing(null);
      setErrors({});
      qc.invalidateQueries({ queryKey: ["my-addresses"] });
    },
  });

  const delMut = useMutation({
    mutationFn: async (a: { id: string; is_default: boolean }) => {
      await delFn({ data: { id: a.id } });
      // If we removed the default, promote the next remaining address.
      if (a.is_default) {
        const remaining = data.filter((x) => x.id !== a.id);
        if (remaining.length > 0) {
          await defaultFn({ data: { id: remaining[0].id } });
        }
      }
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my-addresses"] }),
  });

  const defaultMut = useMutation({
    mutationFn: (id: string) => defaultFn({ data: { id } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["my-addresses"] }),
  });

  // Auto-fetch CEP as soon as 8 digits are typed.
  useEffect(() => {
    if (!editing) return;
    const cep = onlyDigits(editing.cep);
    if (cep.length !== 8) {
      setCepNotice(null);
      return;
    }
    if (cep === lastFetchedCepRef.current) return;
    lastFetchedCepRef.current = cep;
    let alive = true;
    setCepLoading(true);
    setCepNotice(null);
    fetchCep(cep)
      .then((r) => {
        if (!alive) return;
        setEditing((prev) =>
          prev
            ? {
                ...prev,
                street: r.logradouro || prev.street,
                district: r.bairro || prev.district,
                city: r.localidade || prev.city,
                state: (r.uf || prev.state).toUpperCase(),
              }
            : prev,
        );
        setCepNotice({ kind: "ok", msg: "Endereço preenchido pelo CEP." });
        setErrors((e) => ({ ...e, cep: undefined, street: undefined, district: undefined, city: undefined, state: undefined }));
        // Focus number field, the only piece the user must complete.
        setTimeout(() => numberRef.current?.focus(), 50);
      })
      .catch((err) => {
        if (!alive) return;
        setCepNotice({ kind: "err", msg: (err as Error).message });
      })
      .finally(() => {
        if (alive) setCepLoading(false);
      });
    return () => {
      alive = false;
    };
  }, [editing?.cep]); // eslint-disable-line react-hooks/exhaustive-deps

  const openNew = () => {
    setErrors({});
    setCepNotice(null);
    lastFetchedCepRef.current = "";
    // First address is default by default.
    setEditing({ ...emptyForm, is_default: data.length === 0 });
  };

  const openEdit = (a: (typeof data)[number]) => {
    setErrors({});
    setCepNotice(null);
    lastFetchedCepRef.current = onlyDigits(a.cep);
    setEditing({
      id: a.id,
      label: a.label ?? "",
      cep: maskCep(a.cep),
      street: a.street,
      number: a.number,
      complement: a.complement ?? "",
      district: a.district,
      city: a.city,
      state: a.state,
      is_default: a.is_default,
    });
  };

  const submit = () => {
    if (!editing) return;
    const e = validate(editing);
    setErrors(e);
    if (Object.keys(e).length > 0) return;
    saveMut.mutate(editing);
  };

  const formErrors = editing ? validate(editing) : {};
  const canSave = editing != null && Object.keys(formErrors).length === 0 && !cepLoading;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold">Meus Endereços</h1>
          <p className="text-sm text-muted-foreground">Cadastre endereços para usar no checkout.</p>
        </div>
        <button
          onClick={openNew}
          className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground hover:bg-primary-glow"
        >
          <Plus className="h-4 w-4" /> Novo
        </button>
      </div>

      {isLoading ? (
        <div className="text-muted-foreground">Carregando…</div>
      ) : data.length === 0 ? (
        <div className="rounded-3xl border border-dashed border-border bg-surface p-10 text-center text-sm text-muted-foreground">
          <MapPin className="mx-auto h-8 w-8 opacity-50" />
          <p className="mt-3">Você ainda não cadastrou endereços.</p>
        </div>
      ) : (
        <div className="grid gap-3 md:grid-cols-2">
          {data.map((a) => (
            <div key={a.id} className="rounded-2xl border border-border bg-surface p-5">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-display font-semibold">{a.label ?? "Endereço"}</span>
                    {a.is_default && (
                      <span className="inline-flex items-center gap-1 rounded-full bg-primary/15 px-2 py-0.5 text-[10px] font-semibold text-primary">
                        <Star className="h-2.5 w-2.5" /> Principal
                      </span>
                    )}
                  </div>
                  <div className="mt-2 text-sm text-muted-foreground">
                    {a.street}, {a.number}
                    {a.complement ? ` — ${a.complement}` : ""}
                    <br />
                    {a.district} · {a.city}/{a.state} · CEP {maskCep(a.cep)}
                  </div>
                </div>
              </div>
              <div className="mt-4 flex flex-wrap gap-2">
                <button
                  onClick={() => openEdit(a)}
                  className="rounded-lg border border-border bg-background px-3 py-1.5 text-xs hover:bg-surface-elevated"
                >
                  Editar
                </button>
                {!a.is_default && (
                  <button
                    onClick={() => defaultMut.mutate(a.id)}
                    disabled={defaultMut.isPending}
                    className="rounded-lg border border-border bg-background px-3 py-1.5 text-xs hover:bg-surface-elevated disabled:opacity-50"
                  >
                    Tornar principal
                  </button>
                )}
                <button
                  onClick={() => {
                    if (confirm("Excluir este endereço?")) {
                      delMut.mutate({ id: a.id, is_default: a.is_default });
                    }
                  }}
                  disabled={delMut.isPending}
                  className="ml-auto inline-flex items-center gap-1 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-1.5 text-xs text-destructive hover:bg-destructive/20 disabled:opacity-50"
                >
                  <Trash2 className="h-3 w-3" /> Excluir
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      {editing && (
        <div className="fixed inset-0 z-50 grid place-items-center bg-background/80 p-4 backdrop-blur">
          <div className="w-full max-w-lg rounded-3xl border border-border bg-surface p-6 max-h-[90vh] overflow-y-auto">
            <div className="flex items-center justify-between">
              <h2 className="font-display text-lg font-bold">{editing.id ? "Editar" : "Novo"} endereço</h2>
              <button onClick={() => setEditing(null)} className="text-muted-foreground hover:text-foreground">
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="mt-5 grid gap-3 md:grid-cols-2">
              <F
                label="Rótulo (ex: Casa, Trabalho)"
                value={editing.label}
                onChange={(v) => setEditing({ ...editing, label: v })}
                error={errors.label}
                className="md:col-span-2"
              />
              <div className="md:col-span-2">
                <F
                  label="CEP"
                  value={editing.cep}
                  inputMode="numeric"
                  onChange={(v) => setEditing({ ...editing, cep: maskCep(v) })}
                  error={errors.cep}
                  rightSlot={
                    cepLoading ? (
                      <Loader2 className="h-4 w-4 animate-spin text-muted-foreground" />
                    ) : null
                  }
                />
                {cepNotice && (
                  <div
                    className={`mt-1 flex items-center gap-1 text-xs ${
                      cepNotice.kind === "ok" ? "text-emerald-500" : "text-destructive"
                    }`}
                  >
                    {cepNotice.kind === "ok" ? (
                      <CheckCircle2 className="h-3 w-3" />
                    ) : (
                      <AlertCircle className="h-3 w-3" />
                    )}
                    {cepNotice.msg}
                  </div>
                )}
              </div>
              <F
                label="Rua"
                value={editing.street}
                onChange={(v) => setEditing({ ...editing, street: v })}
                error={errors.street}
                className="md:col-span-2"
              />
              <F
                label="Número"
                value={editing.number}
                onChange={(v) => setEditing({ ...editing, number: v })}
                error={errors.number}
                inputRef={numberRef}
              />
              <F
                label="Complemento (opcional)"
                value={editing.complement}
                onChange={(v) => setEditing({ ...editing, complement: v })}
              />
              <F
                label="Bairro"
                value={editing.district}
                onChange={(v) => setEditing({ ...editing, district: v })}
                error={errors.district}
              />
              <F
                label="Cidade"
                value={editing.city}
                onChange={(v) => setEditing({ ...editing, city: v })}
                error={errors.city}
              />
              <F
                label="UF"
                value={editing.state}
                onChange={(v) => setEditing({ ...editing, state: v.toUpperCase().slice(0, 2) })}
                error={errors.state}
              />
              <label className="flex items-center gap-2 text-sm md:col-span-2">
                <input
                  type="checkbox"
                  checked={editing.is_default}
                  onChange={(e) => setEditing({ ...editing, is_default: e.target.checked })}
                />
                Definir como endereço principal
              </label>
            </div>
            {saveMut.error && (
              <div className="mt-3 rounded-lg border border-destructive/40 bg-destructive/10 px-3 py-2 text-sm text-destructive">
                {(saveMut.error as Error).message}
              </div>
            )}
            <div className="mt-5 flex justify-end gap-2">
              <button onClick={() => setEditing(null)} className="rounded-xl border border-border px-4 py-2 text-sm">
                Cancelar
              </button>
              <button
                onClick={submit}
                disabled={!canSave || saveMut.isPending}
                className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-bold text-primary-foreground hover:bg-primary-glow disabled:opacity-50"
              >
                {saveMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
                Salvar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function F({
  label,
  value,
  onChange,
  className = "",
  error,
  inputMode,
  rightSlot,
  inputRef,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  className?: string;
  error?: string;
  inputMode?: "numeric" | "text";
  rightSlot?: React.ReactNode;
  inputRef?: React.RefObject<HTMLInputElement | null>;
}) {
  return (
    <label className={`flex flex-col gap-1 ${className}`}>
      <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{label}</span>
      <div className="relative">
        <input
          ref={inputRef}
          value={value}
          inputMode={inputMode}
          onChange={(e) => onChange(e.target.value)}
          className={`h-11 w-full rounded-xl border bg-background px-3 pr-9 text-sm outline-none focus:border-primary ${
            error ? "border-destructive" : "border-border"
          }`}
        />
        {rightSlot && (
          <div className="pointer-events-none absolute right-3 top-1/2 -translate-y-1/2">{rightSlot}</div>
        )}
      </div>
      {error && <span className="text-[11px] text-destructive">{error}</span>}
    </label>
  );
}
