import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ShieldCheck, Trash2, Plus, Loader2, Mail, CheckCircle2, Clock } from "lucide-react";
import {
  listAdminEmails,
  addAdminEmail,
  removeAdminEmail,
} from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin/admins")({
  component: AdminsPage,
});

function AdminsPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-emails"],
    queryFn: () => listAdminEmails(),
  });

  const [email, setEmail] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const addMut = useMutation({
    mutationFn: (value: string) => addAdminEmail({ data: { email: value } }),
    onSuccess: (res) => {
      setEmail("");
      setError(null);
      setSuccess(
        res.granted
          ? "E-mail adicionado e permissão de admin aplicada imediatamente."
          : "E-mail adicionado. A permissão será aplicada no próximo login.",
      );
      qc.invalidateQueries({ queryKey: ["admin-emails"] });
    },
    onError: (e: Error) => {
      setSuccess(null);
      setError(e.message);
    },
  });

  const removeMut = useMutation({
    mutationFn: (value: string) => removeAdminEmail({ data: { email: value } }),
    onSuccess: () => {
      setError(null);
      setSuccess("E-mail removido e permissão revogada.");
      qc.invalidateQueries({ queryKey: ["admin-emails"] });
    },
    onError: (e: Error) => {
      setSuccess(null);
      setError(e.message);
    },
  });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const v = email.trim().toLowerCase();
    if (!v) return;
    addMut.mutate(v);
  };

  return (
    <div>
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15 text-primary">
          <ShieldCheck className="h-5 w-5" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold">Administradores</h1>
          <p className="text-sm text-muted-foreground">
            E-mails autorizados recebem permissão de admin automaticamente ao entrar com Google.
          </p>
        </div>
      </div>

      <form
        onSubmit={onSubmit}
        className="mt-6 rounded-2xl border border-border bg-surface p-4"
      >
        <label className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
          Adicionar e-mail
        </label>
        <div className="mt-2 flex flex-col gap-2 sm:flex-row">
          <div className="relative flex-1">
            <Mail className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              type="email"
              required
              autoComplete="off"
              placeholder="email@exemplo.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full rounded-xl border border-border bg-background py-2.5 pl-9 pr-3 text-sm outline-none focus:border-primary"
            />
          </div>
          <button
            type="submit"
            disabled={addMut.isPending}
            className="inline-flex items-center justify-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-glow disabled:opacity-60"
          >
            {addMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Plus className="h-4 w-4" />}
            Adicionar
          </button>
        </div>
        {error && (
          <p className="mt-3 text-sm text-destructive">{error}</p>
        )}
        {success && (
          <p className="mt-3 text-sm text-success">{success}</p>
        )}
      </form>

      <div className="mt-6 rounded-2xl border border-border bg-surface">
        <div className="border-b border-border px-4 py-3 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
          E-mails autorizados
        </div>
        {isLoading ? (
          <div className="grid place-items-center p-8 text-muted-foreground">
            <Loader2 className="h-5 w-5 animate-spin" />
          </div>
        ) : !data || data.length === 0 ? (
          <div className="p-6 text-sm text-muted-foreground">Nenhum e-mail cadastrado.</div>
        ) : (
          <ul className="divide-y divide-border">
            {data.map((row) => (
              <li
                key={row.email}
                className="flex flex-col gap-2 px-4 py-3 sm:flex-row sm:items-center sm:justify-between"
              >
                <div className="min-w-0">
                  <div className="truncate text-sm font-medium">{row.email}</div>
                  <div className="mt-0.5 flex flex-wrap items-center gap-2 text-xs text-muted-foreground">
                    {row.active ? (
                      <span className="inline-flex items-center gap-1 text-success">
                        <CheckCircle2 className="h-3.5 w-3.5" /> Ativo
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1">
                        <Clock className="h-3.5 w-3.5" /> Aguardando primeiro login
                      </span>
                    )}
                    {row.last_sign_in_at && (
                      <span>· Último acesso {new Date(row.last_sign_in_at).toLocaleString("pt-BR")}</span>
                    )}
                  </div>
                </div>
                <button
                  onClick={() => {
                    if (confirm(`Remover ${row.email} dos administradores?`)) {
                      removeMut.mutate(row.email);
                    }
                  }}
                  disabled={removeMut.isPending}
                  className="inline-flex items-center gap-1.5 self-start rounded-lg border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground hover:border-destructive hover:text-destructive disabled:opacity-60"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                  Remover
                </button>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}
