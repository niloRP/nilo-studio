import { createFileRoute, Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  User as UserIcon,
  ShoppingBag,
  MapPin,
  Heart,
  Settings as SettingsIcon,
  LogOut,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useProfile } from "@/lib/use-profile";

export const Route = createFileRoute("/_authenticated/conta")({
  component: AccountLayout,
});

function AccountLayout() {
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { data: profile } = useProfile();

  const links = [
    { to: "/conta", label: "Minha Conta", icon: UserIcon, exact: true },
    { to: "/conta/dados", label: "Meus Dados", icon: UserIcon },
    { to: "/conta/pedidos", label: "Meus Pedidos", icon: ShoppingBag },
    { to: "/conta/enderecos", label: "Endereços", icon: MapPin },
    { to: "/conta/favoritos", label: "Favoritos", icon: Heart },
    { to: "/conta/configuracoes", label: "Configurações", icon: SettingsIcon },
  ];

  const initial = (profile?.name ?? profile?.email ?? "U").trim().charAt(0).toUpperCase();

  return (
    <div className="mx-auto grid max-w-7xl gap-6 px-4 py-6 md:grid-cols-[260px_1fr] md:px-6">
      <aside className="md:sticky md:top-20 md:self-start">
        <div className="rounded-2xl border border-border bg-surface p-4">
          <div className="flex items-center gap-3">
            {profile?.avatar_url ? (
              <img
                src={profile.avatar_url}
                alt={profile.name ?? ""}
                className="h-12 w-12 rounded-xl object-cover"
              />
            ) : (
              <div className="grid h-12 w-12 place-items-center rounded-xl bg-primary font-display text-lg font-bold text-primary-foreground">
                {initial}
              </div>
            )}
            <div className="min-w-0">
              <div className="truncate font-display text-sm font-semibold">
                {profile?.name ?? "Cliente"}
              </div>
              <div className="truncate text-[11px] text-muted-foreground">{profile?.email}</div>
            </div>
          </div>

          <nav className="mt-4 flex flex-col gap-0.5">
            {links.map((l) => {
              const active = l.exact ? path === l.to : path.startsWith(l.to);
              return (
                <Link
                  key={l.to}
                  to={l.to}
                  className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors ${
                    active
                      ? "bg-primary/15 text-primary"
                      : "text-muted-foreground hover:bg-surface-elevated hover:text-foreground"
                  }`}
                >
                  <l.icon className="h-4 w-4" />
                  {l.label}
                </Link>
              );
            })}
          </nav>

          <button
            onClick={async () => {
              await supabase.auth.signOut();
              navigate({ to: "/" });
            }}
            className="mt-3 flex w-full items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm text-muted-foreground hover:text-foreground"
          >
            <LogOut className="h-4 w-4" />
            Sair
          </button>
        </div>
      </aside>

      <main>
        <Outlet />
      </main>
    </div>
  );
}
