import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, CheckCircle2, AlertTriangle, Wallet } from "lucide-react";
import {
  getPaymentSettings,
  savePaymentSettings,
  testVirtualPayConnection,
  getVirtualPayBalance,
} from "@/lib/payments.functions";

export const Route = createFileRoute("/_authenticated/admin/pagamentos")({
  component: PagamentosAdmin,
});

function PagamentosAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["payment-settings"],
    queryFn: () => getPaymentSettings(),
  });

  const [form, setForm] = useState({
    client_id: "",
    client_secret: "",
    api_url: "https://api.virtualpay.online/v2",
    webhook_secret: "",
    webhook_signature_header: "x-webhook-signature",
    active: false,
  });
  const [testResult, setTestResult] = useState<{ ok: boolean; message: string } | null>(null);
  const [balance, setBalance] = useState<any>(null);
  const [balanceErr, setBalanceErr] = useState<string | null>(null);

  useEffect(() => {
    if (data) {
      setForm({
        client_id: data.client_id || "",
        client_secret: data.client_secret || "",
        api_url: data.api_url || "https://api.virtualpay.online/v2",
        webhook_secret: data.webhook_secret || "",
        webhook_signature_header: data.webhook_signature_header || "x-webhook-signature",
        active: !!data.active,
      });
    }
  }, [data]);

  const saveMut = useMutation({
    mutationFn: () => savePaymentSettings({ data: form }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["payment-settings"] }),
  });

  const testMut = useMutation({
    mutationFn: () => testVirtualPayConnection(),
    onSuccess: (r) => setTestResult(r),
    onError: (e) => setTestResult({ ok: false, message: e instanceof Error ? e.message : "Erro" }),
  });

  const balMut = useMutation({
    mutationFn: () => getVirtualPayBalance(),
    onSuccess: (r) => {
      setBalance(r);
      setBalanceErr(null);
    },
    onError: (e) => {
      setBalance(null);
      setBalanceErr(e instanceof Error ? e.message : "Erro");
    },
  });

  if (isLoading) {
    return (
      <div className="grid h-40 place-items-center text-muted-foreground">
        <Loader2 className="h-5 w-5 animate-spin" />
      </div>
    );
  }

  const webhookUrl =
    typeof window !== "undefined"
      ? `${window.location.origin}/api/public/webhooks/virtualpay`
      : "/api/public/webhooks/virtualpay";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="font-display text-2xl font-bold">Pagamentos · VirtualPay PIX</h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Único meio de pagamento da loja. Configure as credenciais para começar a receber.
        </p>
      </div>

      <div className="rounded-2xl border border-border bg-surface p-6">
        <div className="grid gap-4 md:grid-cols-2">
          <Field
            label="Client ID *"
            value={form.client_id}
            onChange={(v) => setForm({ ...form, client_id: v })}
          />
          <Field
            label="Client Secret *"
            value={form.client_secret}
            onChange={(v) => setForm({ ...form, client_secret: v })}
            type="password"
          />
          <Field
            label="URL da API *"
            value={form.api_url}
            onChange={(v) => setForm({ ...form, api_url: v })}
            className="md:col-span-2"
          />
          <Field
            label="Webhook Secret (HMAC SHA256)"
            value={form.webhook_secret}
            onChange={(v) => setForm({ ...form, webhook_secret: v })}
            type="password"
          />
          <Field
            label="Header de assinatura"
            value={form.webhook_signature_header}
            onChange={(v) => setForm({ ...form, webhook_signature_header: v })}
          />
          <div className="md:col-span-2">
            <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
              URL do Webhook (configurar na VirtualPay)
            </div>
            <code className="mt-1 block break-all rounded-xl border border-border bg-background px-3 py-2 text-xs font-mono">
              {webhookUrl}
            </code>
          </div>

          <label className="md:col-span-2 flex items-center gap-2 rounded-xl border border-border bg-background px-4 py-3">
            <input
              type="checkbox"
              checked={form.active}
              onChange={(e) => setForm({ ...form, active: e.target.checked })}
              className="h-4 w-4 accent-primary"
            />
            <span className="text-sm">Integração ativa (checkout liberado)</span>
          </label>
        </div>

        <div className="mt-6 flex flex-wrap gap-3">
          <button
            onClick={() => saveMut.mutate()}
            disabled={saveMut.isPending}
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-glow disabled:opacity-60"
          >
            {saveMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Salvar
          </button>
          <button
            onClick={() => testMut.mutate()}
            disabled={testMut.isPending}
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-surface-elevated px-5 py-2.5 text-sm font-semibold hover:bg-surface disabled:opacity-60"
          >
            {testMut.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
            Testar conexão
          </button>
          <button
            onClick={() => balMut.mutate()}
            disabled={balMut.isPending}
            className="inline-flex items-center gap-2 rounded-xl border border-border bg-surface-elevated px-5 py-2.5 text-sm font-semibold hover:bg-surface disabled:opacity-60"
          >
            {balMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Wallet className="h-4 w-4" />}
            Atualizar saldo
          </button>
        </div>

        {saveMut.isSuccess && (
          <div className="mt-4 inline-flex items-center gap-2 text-xs text-success">
            <CheckCircle2 className="h-4 w-4" /> Salvo.
          </div>
        )}
        {testResult && (
          <div
            className={`mt-4 flex items-start gap-2 rounded-xl border px-3 py-2 text-xs ${
              testResult.ok
                ? "border-success/40 bg-success/10 text-success"
                : "border-destructive/40 bg-destructive/10 text-destructive"
            }`}
          >
            {testResult.ok ? <CheckCircle2 className="h-4 w-4" /> : <AlertTriangle className="h-4 w-4" />}
            <span>{testResult.message}</span>
          </div>
        )}
      </div>

      {(balance || balanceErr) && (
        <div className="rounded-2xl border border-border bg-surface p-6">
          <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
            Saldo VirtualPay
          </div>
          {balanceErr ? (
            <div className="mt-2 text-sm text-destructive">{balanceErr}</div>
          ) : (
            <pre className="mt-2 overflow-auto rounded-xl border border-border bg-background p-3 text-xs">
              {JSON.stringify(balance, null, 2)}
            </pre>
          )}
        </div>
      )}
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  className = "",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  className?: string;
}) {
  return (
    <label className={`flex flex-col gap-1.5 ${className}`}>
      <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 rounded-xl border border-border bg-background px-3.5 text-sm text-foreground outline-none focus:border-primary focus:ring-2 focus:ring-ring/30"
      />
    </label>
  );
}
