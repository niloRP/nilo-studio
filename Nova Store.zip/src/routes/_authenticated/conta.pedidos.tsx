import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Package, Truck, Check, X, Clock, ShoppingBag } from "lucide-react";
import { listMyOrders } from "@/lib/account.functions";
import { useAuth } from "@/lib/use-auth";
import { formatBRL } from "@/lib/products";

export const Route = createFileRoute("/_authenticated/conta/pedidos")({
  component: MyOrders,
});

const STATUS_META: Record<string, { label: string; icon: typeof Package; color: string; emoji: string }> = {
  aguardando_pagamento: { label: "Aguardando pagamento", icon: Clock, color: "text-amber-400", emoji: "⏳" },
  pago: { label: "Pago — em preparação", icon: Package, color: "text-primary", emoji: "📦" },
  separando: { label: "Em preparação", icon: Package, color: "text-primary", emoji: "📦" },
  em_envio: { label: "Enviado", icon: Truck, color: "text-blue-400", emoji: "🚚" },
  entregue: { label: "Entregue", icon: Check, color: "text-success", emoji: "✅" },
  cancelado: { label: "Cancelado", icon: X, color: "text-destructive", emoji: "❌" },
};

function MyOrders() {
  const { user } = useAuth();
  const fn = useServerFn(listMyOrders);
  const { data = [], isLoading } = useQuery({
    queryKey: ["my-orders", user?.id],
    queryFn: () => fn(),
    enabled: !!user,
  });

  if (isLoading) return <div className="p-8 text-muted-foreground">Carregando…</div>;

  if (data.length === 0) {
    return (
      <div className="rounded-3xl border border-dashed border-border bg-surface p-10 text-center text-sm text-muted-foreground">
        <ShoppingBag className="mx-auto h-8 w-8 opacity-50" />
        <p className="mt-3">Você ainda não fez nenhum pedido.</p>
      </div>
    );
  }

  return (
    <div className="space-y-4">
      <h1 className="font-display text-2xl font-bold">Meus Pedidos</h1>
      <div className="space-y-3">
        {data.map((o) => {
          const meta = STATUS_META[o.status] ?? STATUS_META.aguardando_pagamento;
          return (
            <details
              key={o.id}
              className="group rounded-2xl border border-border bg-surface p-5 open:border-border-strong"
            >
              <summary className="flex cursor-pointer list-none flex-wrap items-center justify-between gap-3">
                <div className="flex items-center gap-3">
                  <span className="text-2xl">{meta.emoji}</span>
                  <div>
                    <div className="font-mono text-xs text-muted-foreground">Pedido {o.code}</div>
                    <div className={`font-display font-semibold ${meta.color}`}>{meta.label}</div>
                  </div>
                </div>
                <div className="flex items-center gap-4 text-sm">
                  <span className="text-muted-foreground">
                    {new Date(o.created_at).toLocaleDateString("pt-BR")}
                  </span>
                  <span className="font-display text-lg font-bold text-price">{formatBRL(Number(o.total))}</span>
                </div>
              </summary>
              <div className="mt-4 border-t border-border pt-4">
                <ul className="divide-y divide-border">
                  {(o.order_items ?? []).map((it, i) => (
                    <li key={i} className="flex items-center justify-between py-2 text-sm">
                      <div>
                        <div className="font-medium">{it.product_name}</div>
                        <div className="text-xs text-muted-foreground">
                          {it.qty}× {formatBRL(Number(it.unit_price))}
                        </div>
                      </div>
                      <div className="font-mono">{formatBRL(Number(it.subtotal))}</div>
                    </li>
                  ))}
                </ul>
                <div className="mt-3 text-xs text-muted-foreground">
                  Entrega: {o.address_city}/{o.address_uf}
                </div>
              </div>
            </details>
          );
        })}
      </div>
    </div>
  );
}
