import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import {
  ShoppingCart,
  DollarSign,
  Package,
  AlertTriangle,
  Clock,
  CheckCircle2,
  Truck,
} from "lucide-react";
import { getDashboardStats } from "@/lib/admin.functions";
import { formatBRL } from "@/lib/products";

export const Route = createFileRoute("/_authenticated/admin/")({
  component: Dashboard,
});

function Dashboard() {
  const { data, isLoading } = useQuery({
    queryKey: ["dashboard"],
    queryFn: () => getDashboardStats(),
  });

  if (isLoading || !data) {
    return <div className="text-sm text-muted-foreground">Carregando estatísticas…</div>;
  }

  const cards = [
    { label: "Total de pedidos", value: data.ordersTotal, icon: ShoppingCart, accent: "text-primary" },
    { label: "Total vendido", value: formatBRL(data.revenue), icon: DollarSign, accent: "text-price" },
    { label: "Produtos cadastrados", value: data.productsCount, icon: Package, accent: "text-foreground" },
    { label: "Sem estoque", value: data.outOfStock, icon: AlertTriangle, accent: "text-destructive" },
    { label: "Pedidos pendentes", value: data.pending, icon: Clock, accent: "text-muted-foreground" },
    { label: "Pagos", value: data.paid, icon: CheckCircle2, accent: "text-success" },
    { label: "Entregues", value: data.delivered, icon: Truck, accent: "text-primary" },
    { label: "Estoque baixo", value: data.lowStock, icon: AlertTriangle, accent: "text-discount" },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Dashboard</h1>
      <p className="mt-1 text-sm text-muted-foreground">Visão geral da loja em tempo real.</p>

      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border border-border bg-surface p-5">
            <div className="flex items-center justify-between">
              <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                {c.label}
              </div>
              <c.icon className={`h-4 w-4 ${c.accent}`} />
            </div>
            <div className={`mt-2 font-display text-2xl font-bold ${c.accent}`}>{c.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
