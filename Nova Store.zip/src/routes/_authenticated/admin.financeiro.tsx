import { createFileRoute } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { DollarSign, TrendingUp, Clock, ShoppingBag, Receipt } from "lucide-react";
import { getFinancialStats } from "@/lib/payments.functions";
import { formatBRL } from "@/lib/products";

export const Route = createFileRoute("/_authenticated/admin/financeiro")({
  component: Financeiro,
});

function Financeiro() {
  const { data, isLoading } = useQuery({
    queryKey: ["financial-stats"],
    queryFn: () => getFinancialStats(),
    refetchInterval: 15000,
  });

  if (isLoading || !data) {
    return <div className="text-sm text-muted-foreground">Carregando…</div>;
  }

  const cards = [
    { label: "Vendas hoje", value: formatBRL(data.salesToday), icon: TrendingUp, accent: "text-primary" },
    { label: "Vendas no mês", value: formatBRL(data.salesMonth), icon: TrendingUp, accent: "text-primary" },
    { label: "Total recebido", value: formatBRL(data.received), icon: DollarSign, accent: "text-success" },
    { label: "Total pendente", value: formatBRL(data.pending), icon: Clock, accent: "text-discount" },
    { label: "Pedidos", value: data.ordersCount, icon: ShoppingBag, accent: "text-foreground" },
    { label: "Ticket médio", value: formatBRL(data.avgTicket), icon: Receipt, accent: "text-price" },
  ];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Financeiro</h1>
      <p className="mt-1 text-sm text-muted-foreground">Atualizado automaticamente a cada 15 segundos.</p>
      <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {cards.map((c) => (
          <div key={c.label} className="rounded-2xl border border-border bg-surface p-5">
            <div className="flex items-center justify-between">
              <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{c.label}</div>
              <c.icon className={`h-4 w-4 ${c.accent}`} />
            </div>
            <div className={`mt-2 font-display text-2xl font-bold ${c.accent}`}>{c.value}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
