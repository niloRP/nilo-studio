import { createFileRoute } from "@tanstack/react-router";
import { useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Loader2,
  MessageSquareQuote,
  Plus,
  Save,
  Star,
  Trash2,
  Upload,
  Pencil,
  X,
} from "lucide-react";
import {
  listAdminTestimonials,
  upsertTestimonial,
  deleteTestimonial,
  createBrandUploadUrl,
  finalizeBrandUpload,
  type Testimonial,
} from "@/lib/settings.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/admin/depoimentos")({
  component: TestimonialsPage,
});

type Draft = {
  id?: string;
  customer_name: string;
  city: string;
  comment: string;
  rating: number;
  image_url: string;
  storage_path: string | null;
  sort_order: number;
  active: boolean;
};

const empty: Draft = {
  customer_name: "",
  city: "",
  comment: "",
  rating: 5,
  image_url: "",
  storage_path: null,
  sort_order: 0,
  active: true,
};

function TestimonialsPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["testimonials-admin"],
    queryFn: () => listAdminTestimonials(),
  });
  const [draft, setDraft] = useState<Draft | null>(null);

  const save = useMutation({
    mutationFn: (d: Draft) =>
      upsertTestimonial({
        data: {
          id: d.id ?? null,
          customer_name: d.customer_name,
          city: d.city || null,
          comment: d.comment,
          rating: d.rating,
          image_url: d.image_url || null,
          storage_path: d.storage_path,
          sort_order: d.sort_order,
          active: d.active,
        },
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["testimonials-admin"] });
      qc.invalidateQueries({ queryKey: ["testimonials-public"] });
      setDraft(null);
    },
  });

  const del = useMutation({
    mutationFn: (id: string) => deleteTestimonial({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["testimonials-admin"] });
      qc.invalidateQueries({ queryKey: ["testimonials-public"] });
    },
  });

  return (
    <div>
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15 text-primary">
          <MessageSquareQuote className="h-5 w-5" />
        </div>
        <div className="flex-1">
          <h1 className="font-display text-2xl font-bold">Depoimentos dos clientes</h1>
          <p className="text-sm text-muted-foreground">
            Aparecem no carrossel infinito da página inicial.
          </p>
        </div>
        <button
          onClick={() => setDraft({ ...empty })}
          className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary-glow"
        >
          <Plus className="h-4 w-4" /> Novo
        </button>
      </div>

      {draft && (
        <DraftForm
          draft={draft}
          onChange={setDraft}
          onCancel={() => setDraft(null)}
          onSave={() => save.mutate(draft)}
          saving={save.isPending}
          error={save.error instanceof Error ? save.error.message : null}
        />
      )}

      <div className="mt-6">
        {isLoading ? (
          <div className="grid place-items-center p-12 text-muted-foreground">
            <Loader2 className="h-6 w-6 animate-spin" />
          </div>
        ) : !data || data.length === 0 ? (
          <div className="rounded-2xl border border-dashed border-border bg-surface/40 p-8 text-center text-sm text-muted-foreground">
            Nenhum depoimento cadastrado. Clique em "Novo" para começar.
          </div>
        ) : (
          <ul className="grid gap-3 md:grid-cols-2">
            {data.map((t) => (
              <TestimonialRow
                key={t.id}
                t={t}
                onEdit={() =>
                  setDraft({
                    id: t.id,
                    customer_name: t.customer_name,
                    city: t.city ?? "",
                    comment: t.comment,
                    rating: t.rating,
                    image_url: t.image_url ?? "",
                    storage_path: t.storage_path,
                    sort_order: t.sort_order,
                    active: t.active,
                  })
                }
                onDelete={() => {
                  if (confirm(`Excluir depoimento de ${t.customer_name}?`)) del.mutate(t.id);
                }}
              />
            ))}
          </ul>
        )}
      </div>
    </div>
  );
}

function TestimonialRow({
  t,
  onEdit,
  onDelete,
}: {
  t: Testimonial;
  onEdit: () => void;
  onDelete: () => void;
}) {
  return (
    <li className="rounded-2xl border border-border bg-surface p-4">
      <div className="flex items-start gap-3">
        {t.image_url ? (
          <img src={t.image_url} alt={t.customer_name} className="h-14 w-14 rounded-full object-cover" />
        ) : (
          <div className="h-14 w-14 rounded-full bg-surface-elevated" />
        )}
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-2">
            <span className="truncate text-sm font-semibold">{t.customer_name}</span>
            {!t.active && (
              <span className="rounded-full bg-muted/40 px-2 py-0.5 text-[10px] uppercase text-muted-foreground">Inativo</span>
            )}
            <span className="ml-auto flex gap-0.5">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star key={i} className={`h-3 w-3 ${i < t.rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/30"}`} />
              ))}
            </span>
          </div>
          {t.city && <div className="text-xs text-muted-foreground">{t.city}</div>}
          <p className="mt-2 line-clamp-3 text-sm text-muted-foreground">"{t.comment}"</p>
          <div className="mt-3 flex gap-2">
            <button onClick={onEdit} className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-background px-3 py-1.5 text-xs hover:bg-surface-elevated">
              <Pencil className="h-3 w-3" /> Editar
            </button>
            <button onClick={onDelete} className="inline-flex items-center gap-1.5 rounded-lg border border-border bg-background px-3 py-1.5 text-xs text-muted-foreground hover:border-destructive hover:text-destructive">
              <Trash2 className="h-3 w-3" /> Excluir
            </button>
            <span className="ml-auto self-center text-[11px] text-muted-foreground">Ordem: {t.sort_order}</span>
          </div>
        </div>
      </div>
    </li>
  );
}

function DraftForm({
  draft,
  onChange,
  onCancel,
  onSave,
  saving,
  error,
}: {
  draft: Draft;
  onChange: (d: Draft) => void;
  onCancel: () => void;
  onSave: () => void;
  saving: boolean;
  error: string | null;
}) {
  const ref = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [upErr, setUpErr] = useState<string | null>(null);

  const upload = async (file: File) => {
    setUploading(true);
    setUpErr(null);
    try {
      const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const up = await createBrandUploadUrl({ data: { scope: "testimonial", filename: safe } });
      const { error } = await supabase.storage
        .from("product-media")
        .uploadToSignedUrl(up.path, up.token, file, {
          contentType: file.type || "application/octet-stream",
        });
      if (error) throw new Error(error.message);
      const done = await finalizeBrandUpload({ data: { path: up.path } });
      onChange({ ...draft, image_url: done.url, storage_path: done.path });
    } catch (e) {
      setUpErr(e instanceof Error ? e.message : "Falha no upload");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="mt-6 rounded-2xl border border-border bg-surface p-4 md:p-5">
      <div className="flex items-center justify-between">
        <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
          {draft.id ? "Editar depoimento" : "Novo depoimento"}
        </div>
        <button onClick={onCancel} className="text-muted-foreground hover:text-foreground">
          <X className="h-4 w-4" />
        </button>
      </div>

      <div className="mt-4 grid gap-4 md:grid-cols-[120px_1fr]">
        <div>
          <div className="grid h-28 w-28 place-items-center overflow-hidden rounded-2xl border border-border bg-background">
            {draft.image_url ? (
              <img src={draft.image_url} alt="" className="h-full w-full object-cover" />
            ) : (
              <Upload className="h-5 w-5 text-muted-foreground" />
            )}
          </div>
          <button
            type="button"
            onClick={() => ref.current?.click()}
            disabled={uploading}
            className="mt-2 inline-flex w-28 items-center justify-center gap-1.5 rounded-lg border border-border bg-background px-2 py-1.5 text-xs hover:bg-surface-elevated disabled:opacity-60"
          >
            {uploading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Upload className="h-3 w-3" />}
            Enviar
          </button>
          <input
            ref={ref}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) upload(f);
              if (ref.current) ref.current.value = "";
            }}
          />
          {upErr && <div className="mt-1 text-[11px] text-destructive">{upErr}</div>}
        </div>

        <div className="grid gap-3">
          <div className="grid gap-3 md:grid-cols-2">
            <Field label="Nome">
              <input className="adm-input" value={draft.customer_name} onChange={(e) => onChange({ ...draft, customer_name: e.target.value })} />
            </Field>
            <Field label="Cidade">
              <input className="adm-input" value={draft.city} onChange={(e) => onChange({ ...draft, city: e.target.value })} />
            </Field>
          </div>
          <Field label="Comentário">
            <textarea className="adm-input min-h-[80px]" value={draft.comment} onChange={(e) => onChange({ ...draft, comment: e.target.value })} />
          </Field>
          <div className="grid gap-3 md:grid-cols-3">
            <Field label="Estrelas">
              <div className="flex items-center gap-1">
                {[1, 2, 3, 4, 5].map((n) => (
                  <button
                    type="button"
                    key={n}
                    onClick={() => onChange({ ...draft, rating: n })}
                    className="p-0.5"
                  >
                    <Star className={`h-5 w-5 ${n <= draft.rating ? "fill-yellow-400 text-yellow-400" : "text-muted-foreground/40"}`} />
                  </button>
                ))}
              </div>
            </Field>
            <Field label="Ordem">
              <input type="number" className="adm-input" value={draft.sort_order} onChange={(e) => onChange({ ...draft, sort_order: Number(e.target.value) || 0 })} />
            </Field>
            <Field label="Status">
              <label className="mt-1 inline-flex cursor-pointer items-center gap-2 text-sm">
                <input
                  type="checkbox"
                  checked={draft.active}
                  onChange={(e) => onChange({ ...draft, active: e.target.checked })}
                />
                Ativo
              </label>
            </Field>
          </div>
        </div>
      </div>

      {error && <div className="mt-3 rounded-lg border border-destructive/40 bg-destructive/10 p-2 text-xs text-destructive">{error}</div>}

      <div className="mt-4 flex gap-2">
        <button
          onClick={onSave}
          disabled={saving || !draft.customer_name || !draft.comment}
          className="inline-flex items-center gap-2 rounded-xl bg-primary px-4 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary-glow disabled:opacity-60"
        >
          {saving ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
          Salvar
        </button>
        <button onClick={onCancel} className="rounded-xl border border-border bg-background px-4 py-2 text-sm hover:bg-surface-elevated">
          Cancelar
        </button>
      </div>

      <style>{`
        .adm-input { width:100%; background: var(--color-background); border:1px solid var(--color-border); border-radius:0.625rem; padding:0.5rem 0.625rem; font-size:0.875rem; outline:none; }
        .adm-input:focus { border-color: var(--color-primary); }
      `}</style>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1 text-xs font-medium">{label}</div>
      {children}
    </label>
  );
}
