import { createFileRoute, Link } from "@tanstack/react-router";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Plus, Pencil, Trash2, Eye, EyeOff, Loader2 } from "lucide-react";
import {
  deleteProduct,
  listAllProducts,
  toggleProductActive,
} from "@/lib/admin.functions";
import { formatBRL } from "@/lib/products";

export const Route = createFileRoute("/_authenticated/admin/produtos/")({
  component: ProductsAdmin,
});

type Row = {
  id: string;
  slug: string;
  name: string;
  brand: string | null;
  category_slug: string | null;
  price: number | string;
  old_price: number | string | null;
  stock: number;
  low_stock_threshold: number;
  active: boolean;
  product_images: { url: string; is_primary: boolean; sort_order: number }[] | null;
};

function img(p: Row) {
  const imgs = p.product_images ?? [];
  const primary = imgs.find((x) => x.is_primary) ?? imgs[0];
  return primary?.url ?? "https://placehold.co/120x120?text=...";
}

function ProductsAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-products"],
    queryFn: () => listAllProducts(),
  });

  const toggleMut = useMutation({
    mutationFn: (v: { id: string; active: boolean }) =>
      toggleProductActive({ data: v }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-products"] });
      qc.invalidateQueries({ queryKey: ["catalog"] });
    },
  });

  const deleteMut = useMutation({
    mutationFn: (id: string) => deleteProduct({ data: { id } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-products"] });
      qc.invalidateQueries({ queryKey: ["catalog"] });
    },
  });

  const rows = (data as Row[] | undefined) ?? [];

  return (
    <div>
      <div className="flex items-center justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold">Produtos</h1>
          <p className="mt-1 text-sm text-muted-foreground">
            {rows.length} produtos cadastrados.
          </p>
        </div>
        <Link
          to="/admin/produtos/$id"
          params={{ id: "novo" }}
          className="inline-flex items-center gap-1.5 rounded-xl bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-glow"
        >
          <Plus className="h-4 w-4" />
          Novo produto
        </Link>
      </div>

      {isLoading && <div className="mt-6 text-sm text-muted-foreground">Carregando…</div>}

      <div className="mt-6 overflow-hidden rounded-2xl border border-border bg-surface">
        <table className="w-full text-sm">
          <thead className="bg-surface-elevated text-left text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
            <tr>
              <th className="p-3">Produto</th>
              <th className="p-3">Categoria</th>
              <th className="p-3 text-right">Preço</th>
              <th className="p-3 text-right">Estoque</th>
              <th className="p-3">Status</th>
              <th className="p-3" />
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {rows.map((p) => {
              const low = p.stock > 0 && p.stock <= p.low_stock_threshold;
              return (
                <tr key={p.id} className="align-middle">
                  <td className="p-3">
                    <div className="flex items-center gap-3">
                      <img src={img(p)} alt="" className="h-12 w-12 rounded-lg object-cover" />
                      <div>
                        <div className="font-medium">{p.name}</div>
                        <div className="text-xs text-muted-foreground">{p.brand ?? "—"} · /{p.slug}</div>
                      </div>
                    </div>
                  </td>
                  <td className="p-3 text-muted-foreground">{p.category_slug ?? "—"}</td>
                  <td className="p-3 text-right font-mono">{formatBRL(Number(p.price))}</td>
                  <td className={`p-3 text-right font-mono ${p.stock <= 0 ? "text-destructive" : low ? "text-discount" : ""}`}>
                    {p.stock}
                  </td>
                  <td className="p-3">
                    <button
                      onClick={() => toggleMut.mutate({ id: p.id, active: !p.active })}
                      className={`inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${
                        p.active ? "bg-success/15 text-success" : "bg-muted text-muted-foreground"
                      }`}
                    >
                      {p.active ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                      {p.active ? "Ativo" : "Inativo"}
                    </button>
                  </td>
                  <td className="p-3">
                    <div className="flex items-center justify-end gap-1">
                      <Link
                        to="/admin/produtos/$id"
                        params={{ id: p.id }}
                        className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-surface-elevated hover:text-foreground"
                      >
                        <Pencil className="h-4 w-4" />
                      </Link>
                      <button
                        onClick={() => {
                          if (confirm(`Excluir "${p.name}"? Esta ação não pode ser desfeita.`))
                            deleteMut.mutate(p.id);
                        }}
                        className="grid h-8 w-8 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                      >
                        {deleteMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Trash2 className="h-4 w-4" />}
                      </button>
                    </div>
                  </td>
                </tr>
              );
            })}
            {!isLoading && rows.length === 0 && (
              <tr>
                <td colSpan={6} className="p-10 text-center text-muted-foreground">
                  Nenhum produto cadastrado.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
