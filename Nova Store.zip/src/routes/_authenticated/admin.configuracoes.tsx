import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Loader2, Save, Settings as SettingsIcon, Upload, Trash2 } from "lucide-react";
import {
  getStoreSettings,
  updateStoreSettings,
  createBrandUploadUrl,
  finalizeBrandUpload,
  type StoreSettings,
} from "@/lib/settings.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/admin/configuracoes")({
  component: SettingsPage,
});

type FormState = StoreSettings;

const empty: FormState = {
  store_name: "iPhone SP",
  tagline: "",
  description: "",
  logo_url: "",
  favicon_url: "",
  primary_color: "",
  contact_email: "",
  contact_phone: "",
  whatsapp: "",
  address: "",
  cnpj: "",
  instagram_url: "",
  facebook_url: "",
  twitter_url: "",
  youtube_url: "",
  tiktok_url: "",
  footer_text: "",
};

function SettingsPage() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["store-settings"],
    queryFn: () => getStoreSettings(),
  });
  const [form, setForm] = useState<FormState>(empty);
  const [saved, setSaved] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (data) {
      const merged: FormState = { ...empty };
      (Object.keys(empty) as (keyof FormState)[]).forEach((k) => {
        const v = (data as Record<string, unknown>)[k as string];
        (merged as Record<string, unknown>)[k as string] = v ?? "";
      });
      setForm(merged);
    }
  }, [data]);

  const saveMut = useMutation({
    mutationFn: (payload: FormState) =>
      updateStoreSettings({
        data: {
          ...payload,
          // empty strings -> null for clean DB
          ...Object.fromEntries(
            Object.entries(payload).map(([k, v]) => [k, v === "" ? null : v]),
          ),
          store_name: payload.store_name || "Minha Loja",
        } as never,
      }),
    onSuccess: () => {
      setSaved(true);
      setError(null);
      qc.invalidateQueries({ queryKey: ["store-settings"] });
      setTimeout(() => setSaved(false), 2500);
    },
    onError: (e: Error) => setError(e.message),
  });

  const onSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    saveMut.mutate(form);
  };

  const upd = (k: keyof FormState) => (v: string) =>
    setForm((s) => ({ ...s, [k]: v }));

  if (isLoading) {
    return (
      <div className="grid place-items-center p-12 text-muted-foreground">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  return (
    <div>
      <div className="flex items-center gap-3">
        <div className="grid h-10 w-10 place-items-center rounded-xl bg-primary/15 text-primary">
          <SettingsIcon className="h-5 w-5" />
        </div>
        <div>
          <h1 className="font-display text-2xl font-bold">Configurações da loja</h1>
          <p className="text-sm text-muted-foreground">
            Edite nome, logo, contato e redes sociais. Aplica em toda a loja.
          </p>
        </div>
      </div>

      <form onSubmit={onSubmit} className="mt-6 space-y-6">
        <Card title="Identidade">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Nome da loja" required>
              <input
                className="input"
                value={form.store_name}
                onChange={(e) => upd("store_name")(e.target.value)}
                required
              />
            </Field>
            <Field label="Slogan / tagline">
              <input
                className="input"
                value={form.tagline ?? ""}
                onChange={(e) => upd("tagline")(e.target.value)}
              />
            </Field>
            <Field label="Descrição" hint="Aparece no rodapé e nas metatags.">
              <textarea
                className="input min-h-[90px]"
                value={form.description ?? ""}
                onChange={(e) => upd("description")(e.target.value)}
              />
            </Field>
            <Field label="Cor principal (hex ou oklch)" hint="Ex.: #22c55e">
              <input
                className="input"
                value={form.primary_color ?? ""}
                onChange={(e) => upd("primary_color")(e.target.value)}
              />
            </Field>
          </div>
          <div className="mt-4 grid gap-4 md:grid-cols-2">
            <ImageUpload
              label="Logo"
              scope="logo"
              value={form.logo_url ?? ""}
              onChange={upd("logo_url")}
            />
            <ImageUpload
              label="Favicon"
              scope="favicon"
              value={form.favicon_url ?? ""}
              onChange={upd("favicon_url")}
            />
          </div>
        </Card>

        <Card title="Contato">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="E-mail">
              <input className="input" value={form.contact_email ?? ""} onChange={(e) => upd("contact_email")(e.target.value)} />
            </Field>
            <Field label="Telefone">
              <input className="input" value={form.contact_phone ?? ""} onChange={(e) => upd("contact_phone")(e.target.value)} />
            </Field>
            <Field label="WhatsApp (com DDI)">
              <input className="input" value={form.whatsapp ?? ""} onChange={(e) => upd("whatsapp")(e.target.value)} placeholder="5511999999999" />
            </Field>
            <Field label="CNPJ">
              <input className="input" value={form.cnpj ?? ""} onChange={(e) => upd("cnpj")(e.target.value)} />
            </Field>
            <Field label="Endereço">
              <input className="input" value={form.address ?? ""} onChange={(e) => upd("address")(e.target.value)} />
            </Field>
          </div>
        </Card>

        <Card title="Redes sociais">
          <div className="grid gap-4 md:grid-cols-2">
            <Field label="Instagram URL"><input className="input" value={form.instagram_url ?? ""} onChange={(e) => upd("instagram_url")(e.target.value)} /></Field>
            <Field label="Facebook URL"><input className="input" value={form.facebook_url ?? ""} onChange={(e) => upd("facebook_url")(e.target.value)} /></Field>
            <Field label="Twitter URL"><input className="input" value={form.twitter_url ?? ""} onChange={(e) => upd("twitter_url")(e.target.value)} /></Field>
            <Field label="YouTube URL"><input className="input" value={form.youtube_url ?? ""} onChange={(e) => upd("youtube_url")(e.target.value)} /></Field>
            <Field label="TikTok URL"><input className="input" value={form.tiktok_url ?? ""} onChange={(e) => upd("tiktok_url")(e.target.value)} /></Field>
          </div>
        </Card>

        <Card title="Rodapé">
          <Field label="Texto do rodapé">
            <input className="input" value={form.footer_text ?? ""} onChange={(e) => upd("footer_text")(e.target.value)} placeholder="Todos os direitos reservados." />
          </Field>
        </Card>

        {error && <div className="rounded-xl border border-destructive/40 bg-destructive/10 p-3 text-sm text-destructive">{error}</div>}

        <div className="flex items-center gap-3">
          <button
            type="submit"
            disabled={saveMut.isPending}
            className="inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-glow disabled:opacity-60"
          >
            {saveMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Save className="h-4 w-4" />}
            Salvar configurações
          </button>
          {saved && <span className="text-sm text-success">Salvo!</span>}
        </div>
      </form>

      <style>{`
        .input { width:100%; background: var(--color-background); border:1px solid var(--color-border); border-radius:0.75rem; padding:0.625rem 0.75rem; font-size:0.875rem; outline:none; }
        .input:focus { border-color: var(--color-primary); }
      `}</style>
    </div>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section className="rounded-2xl border border-border bg-surface p-4 md:p-5">
      <div className="mb-3 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{title}</div>
      {children}
    </section>
  );
}

function Field({ label, hint, required, children }: { label: string; hint?: string; required?: boolean; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1.5 text-xs font-medium text-foreground">
        {label}{required && <span className="text-destructive"> *</span>}
      </div>
      {children}
      {hint && <div className="mt-1 text-[11px] text-muted-foreground">{hint}</div>}
    </label>
  );
}

function ImageUpload({
  label,
  scope,
  value,
  onChange,
}: {
  label: string;
  scope: "logo" | "favicon";
  value: string;
  onChange: (url: string) => void;
}) {
  const ref = useRef<HTMLInputElement | null>(null);
  const [uploading, setUploading] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  const handle = async (file: File) => {
    setUploading(true);
    setErr(null);
    try {
      const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      const up = await createBrandUploadUrl({ data: { scope, filename: safe } });
      const { error: upErr } = await supabase.storage
        .from("product-media")
        .uploadToSignedUrl(up.path, up.token, file, {
          contentType: file.type || "application/octet-stream",
        });
      if (upErr) throw new Error(upErr.message);
      const done = await finalizeBrandUpload({ data: { path: up.path } });
      onChange(done.url);
    } catch (e) {
      setErr(e instanceof Error ? e.message : "Falha no upload");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div>
      <div className="mb-1.5 text-xs font-medium">{label}</div>
      <div className="flex items-center gap-3">
        <div className="grid h-16 w-16 place-items-center overflow-hidden rounded-xl border border-border bg-background">
          {value ? (
            <img src={value} alt={label} className="h-full w-full object-cover" />
          ) : (
            <Upload className="h-5 w-5 text-muted-foreground" />
          )}
        </div>
        <div className="flex flex-col gap-2">
          <button
            type="button"
            onClick={() => ref.current?.click()}
            disabled={uploading}
            className="inline-flex items-center gap-2 rounded-lg border border-border bg-background px-3 py-1.5 text-xs hover:bg-surface-elevated disabled:opacity-60"
          >
            {uploading ? <Loader2 className="h-3.5 w-3.5 animate-spin" /> : <Upload className="h-3.5 w-3.5" />}
            Enviar arquivo
          </button>
          {value && (
            <button
              type="button"
              onClick={() => onChange("")}
              className="inline-flex items-center gap-1.5 text-xs text-muted-foreground hover:text-destructive"
            >
              <Trash2 className="h-3 w-3" /> Remover
            </button>
          )}
        </div>
        <input
          ref={ref}
          type="file"
          accept="image/*"
          className="hidden"
          onChange={(e) => {
            const f = e.target.files?.[0];
            if (f) handle(f);
            if (ref.current) ref.current.value = "";
          }}
        />
      </div>
      {err && <div className="mt-2 text-xs text-destructive">{err}</div>}
    </div>
  );
}
