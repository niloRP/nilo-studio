import { createFileRoute, useNavigate, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowLeft, Upload, Trash2, Star, StarOff, Loader2, Plus, X, Video } from "lucide-react";
import {
  addProductImage,
  addProductVideo,
  createMediaUploadUrl,
  getAdminProduct,
  removeProductImage,
  removeProductVideo,
  setPrimaryImage,
  upsertProduct,
} from "@/lib/admin.functions";
import { listPublicCatalog } from "@/lib/products.functions";
import { supabase } from "@/integrations/supabase/client";

export const Route = createFileRoute("/_authenticated/admin/produtos/$id")({
  component: ProductEditor,
});

const TAG_OPTIONS = ["destaque", "promocao", "lancamento", "maisVendido"] as const;
const BRAND_OPTIONS = ["Apple", "Xiaomi"] as const;
const CONDITION_OPTIONS = [
  { value: "novo", label: "Novo" },
  { value: "seminovo", label: "Seminovo" },
] as const;

type FormState = {
  slug: string;
  name: string;
  brand: string;
  model: string;
  color: string;
  storage: string;
  ram: string;
  condition: "novo" | "seminovo";
  category_slug: string;
  price: string;
  promo_price: string;
  old_price: string;
  badge: string;
  stock: string;
  low_stock_threshold: string;
  short_description: string;
  description: string;
  active: boolean;
  featured: boolean;
  tags: string[];
  specs: { label: string; value: string }[];
};

const empty: FormState = {
  slug: "",
  name: "",
  brand: "Apple",
  model: "",
  color: "",
  storage: "",
  ram: "",
  condition: "novo",
  category_slug: "iphone",
  price: "0",
  promo_price: "",
  old_price: "",
  badge: "",
  stock: "0",
  low_stock_threshold: "5",
  short_description: "",
  description: "",
  active: true,
  featured: false,
  tags: [],
  specs: [],
};

function ProductEditor() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const qc = useQueryClient();
  const isNew = id === "novo";

  const { data: catalog } = useQuery({ queryKey: ["catalog"], queryFn: () => listPublicCatalog() });
  const productQ = useQuery({
    queryKey: ["admin-product", id],
    queryFn: () => getAdminProduct({ data: { id } }),
    enabled: !isNew,
  });

  const [form, setForm] = useState<FormState>(empty);

  useEffect(() => {
    if (!isNew && productQ.data) {
      const p = productQ.data as Record<string, unknown>;
      setForm({
        slug: String(p.slug ?? ""),
        name: String(p.name ?? ""),
        brand: String(p.brand ?? "Apple"),
        model: String(p.model ?? ""),
        color: String(p.color ?? ""),
        storage: String(p.storage ?? ""),
        ram: String(p.ram ?? ""),
        condition: (p.condition === "seminovo" ? "seminovo" : "novo"),
        category_slug: String(p.category_slug ?? ""),
        price: String(p.price ?? "0"),
        promo_price: p.promo_price == null ? "" : String(p.promo_price),
        old_price: p.old_price == null ? "" : String(p.old_price),
        badge: String(p.badge ?? ""),
        stock: String(p.stock ?? "0"),
        low_stock_threshold: String(p.low_stock_threshold ?? "5"),
        short_description: String(p.short_description ?? ""),
        description: String(p.description ?? ""),
        active: Boolean(p.active),
        featured: Boolean(p.featured),
        tags: (p.tags as string[] | null) ?? [],
        specs: ((p.specs as { label: string; value: string }[] | null) ?? []),
      });
    }
  }, [isNew, productQ.data]);

  const save = useMutation({
    mutationFn: () =>
      upsertProduct({
        data: {
          id: isNew ? undefined : id,
          slug: form.slug.trim(),
          name: form.name.trim(),
          brand: form.brand.trim() || null,
          model: form.model.trim() || null,
          color: form.color.trim() || null,
          storage: form.storage.trim() || null,
          ram: form.ram.trim() || null,
          condition: form.condition,
          category_slug: form.category_slug || null,
          price: Number(form.price),
          promo_price: form.promo_price ? Number(form.promo_price) : null,
          old_price: form.old_price ? Number(form.old_price) : null,
          badge: form.badge.trim() || null,
          stock: Number(form.stock),
          low_stock_threshold: Number(form.low_stock_threshold),
          short_description: form.short_description.trim() || null,
          description: form.description.trim() || null,
          specs: form.specs.filter((s) => s.label.trim() && s.value.trim()),
          tags: form.tags,
          featured: form.featured,
          active: form.active,
        },
      }),
    onSuccess: (res) => {
      qc.invalidateQueries({ queryKey: ["admin-products"] });
      qc.invalidateQueries({ queryKey: ["catalog"] });
      if (isNew) navigate({ to: "/admin/produtos/$id", params: { id: res.id } });
      else qc.invalidateQueries({ queryKey: ["admin-product", id] });
    },
  });

  return (
    <div>
      <Link to="/admin/produtos" className="inline-flex items-center gap-1 text-xs text-muted-foreground hover:text-foreground">
        <ArrowLeft className="h-3 w-3" /> Voltar
      </Link>
      <h1 className="mt-2 font-display text-2xl font-bold">
        {isNew ? "Novo produto" : form.name || "Editar produto"}
      </h1>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="space-y-4">
          <Card title="Informações">
            <div className="grid gap-4 md:grid-cols-2">
              <Field label="Nome *" value={form.name} onChange={(v) => setForm({ ...form, name: v })} className="md:col-span-2" />
              <Field label="Slug (URL) *" value={form.slug} onChange={(v) => setForm({ ...form, slug: v.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "") })} />
              <SelectField
                label="Marca *"
                value={form.brand}
                onChange={(v) => setForm({ ...form, brand: v, category_slug: v === "Apple" ? "iphone" : v === "Xiaomi" ? "xiaomi" : form.category_slug })}
                options={BRAND_OPTIONS.map((b) => ({ value: b, label: b }))}
              />
              <SelectField
                label="Categoria *"
                value={form.category_slug}
                onChange={(v) => setForm({ ...form, category_slug: v })}
                options={(catalog?.categories ?? []).map((c) => ({ value: c.slug, label: c.name }))}
              />
              <Field label="Modelo (ex: 15 Pro Max, Redmi Note 13)" value={form.model} onChange={(v) => setForm({ ...form, model: v })} />
              <Field label="Cor" value={form.color} onChange={(v) => setForm({ ...form, color: v })} />
              <Field label="Armazenamento (ex: 256GB)" value={form.storage} onChange={(v) => setForm({ ...form, storage: v })} />
              <Field label="Memória RAM (ex: 8GB)" value={form.ram} onChange={(v) => setForm({ ...form, ram: v })} />
              <SelectField
                label="Estado *"
                value={form.condition}
                onChange={(v) => setForm({ ...form, condition: v as "novo" | "seminovo" })}
                options={CONDITION_OPTIONS.map((c) => ({ value: c.value, label: c.label }))}
              />
              <Field label="Selo (ex: -30%, Lançamento)" value={form.badge} onChange={(v) => setForm({ ...form, badge: v })} />
            </div>
          </Card>

          <Card title="Preços & estoque">
            <div className="grid gap-4 md:grid-cols-4">
              <Field label="Preço (R$) *" type="number" value={form.price} onChange={(v) => setForm({ ...form, price: v })} />
              <Field label="Preço promocional (R$)" type="number" value={form.promo_price} onChange={(v) => setForm({ ...form, promo_price: v })} />
              <Field label="Estoque" type="number" value={form.stock} onChange={(v) => setForm({ ...form, stock: v })} />
              <Field label="Alerta estoque baixo" type="number" value={form.low_stock_threshold} onChange={(v) => setForm({ ...form, low_stock_threshold: v })} />
            </div>
          </Card>

          <Card title="Descrição">
            <Field label="Descrição curta (vitrine)" value={form.short_description} onChange={(v) => setForm({ ...form, short_description: v })} />
            <label className="mt-4 flex flex-col gap-1.5">
              <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                Descrição completa
              </span>
              <textarea
                value={form.description}
                onChange={(e) => setForm({ ...form, description: e.target.value })}
                rows={6}
                className="rounded-xl border border-border bg-background p-3 text-sm outline-none focus:border-primary"
              />
            </label>
          </Card>

          <Card title="Especificações técnicas">
            <div className="space-y-2">
              {form.specs.map((s, i) => (
                <div key={i} className="grid gap-2 md:grid-cols-[1fr_2fr_auto]">
                  <input
                    placeholder="Atributo"
                    value={s.label}
                    onChange={(e) => {
                      const v = [...form.specs];
                      v[i] = { ...v[i], label: e.target.value };
                      setForm({ ...form, specs: v });
                    }}
                    className="h-10 rounded-lg border border-border bg-background px-3 text-sm"
                  />
                  <input
                    placeholder="Valor"
                    value={s.value}
                    onChange={(e) => {
                      const v = [...form.specs];
                      v[i] = { ...v[i], value: e.target.value };
                      setForm({ ...form, specs: v });
                    }}
                    className="h-10 rounded-lg border border-border bg-background px-3 text-sm"
                  />
                  <button
                    onClick={() => setForm({ ...form, specs: form.specs.filter((_, j) => j !== i) })}
                    className="grid h-10 w-10 place-items-center rounded-lg text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                  >
                    <X className="h-4 w-4" />
                  </button>
                </div>
              ))}
              <button
                type="button"
                onClick={() => setForm({ ...form, specs: [...form.specs, { label: "", value: "" }] })}
                className="inline-flex items-center gap-1 rounded-lg border border-dashed border-border px-3 py-1.5 text-xs text-muted-foreground hover:text-foreground"
              >
                <Plus className="h-3 w-3" /> Adicionar especificação
              </button>
            </div>
          </Card>

          <Card title="Tags promocionais">
            <div className="flex flex-wrap gap-2">
              {TAG_OPTIONS.map((t) => {
                const on = form.tags.includes(t);
                return (
                  <button
                    key={t}
                    onClick={() =>
                      setForm({ ...form, tags: on ? form.tags.filter((x) => x !== t) : [...form.tags, t] })
                    }
                    className={`rounded-full border px-3 py-1 text-xs font-semibold transition-colors ${
                      on
                        ? "border-primary bg-primary text-primary-foreground"
                        : "border-border text-muted-foreground hover:text-foreground"
                    }`}
                  >
                    {t}
                  </button>
                );
              })}
            </div>
          </Card>
        </div>

        <div className="space-y-4">
          <Card title="Status">
            <label className="flex items-center justify-between rounded-xl bg-background p-3">
              <div>
                <div className="text-sm font-semibold">Produto ativo</div>
                <div className="text-xs text-muted-foreground">Visível na loja se ativo.</div>
              </div>
              <input
                type="checkbox"
                checked={form.active}
                onChange={(e) => setForm({ ...form, active: e.target.checked })}
                className="h-5 w-5 accent-primary"
              />
            </label>
            <label className="mt-2 flex items-center justify-between rounded-xl bg-background p-3">
              <div>
                <div className="text-sm font-semibold">Destaque no banner</div>
                <div className="text-xs text-muted-foreground">Aparece no banner principal da home.</div>
              </div>
              <input
                type="checkbox"
                checked={form.featured}
                onChange={(e) => setForm({ ...form, featured: e.target.checked })}
                className="h-5 w-5 accent-primary"
              />
            </label>
            <button
              onClick={() => save.mutate()}
              disabled={save.isPending}
              className="mt-4 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-4 py-3 font-display text-sm font-bold text-primary-foreground hover:bg-primary-glow disabled:opacity-60"
            >
              {save.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
              {isNew ? "Criar produto" : "Salvar alterações"}
            </button>
            {save.error && (
              <div className="mt-2 text-xs text-destructive">
                {save.error instanceof Error ? save.error.message : "Erro"}
              </div>
            )}
          </Card>

          {!isNew && productQ.data && (
            <MediaPanel productId={id} product={productQ.data as ProductDetail} />
          )}
        </div>
      </div>
    </div>
  );
}

type ProductDetail = {
  product_images: { id: string; url: string; storage_path?: string | null; is_primary: boolean; sort_order: number }[] | null;
  product_videos: { id: string; url: string; storage_path?: string | null; title: string | null }[] | null;
};

const IMAGE_TYPES = new Set(["image/png", "image/jpeg", "image/webp"]);

function validateImageFile(file: File) {
  const ext = file.name.split(".").pop()?.toLowerCase();
  const supportedExt = ext === "png" || ext === "jpg" || ext === "jpeg" || ext === "webp";
  if (!IMAGE_TYPES.has(file.type) && !supportedExt) {
    throw new Error("Formato inválido. Envie imagens PNG, JPG, JPEG ou WEBP.");
  }
}

function validateImageUrl(url: string) {
  return new Promise<void>((resolve, reject) => {
    const img = new Image();
    img.onload = () => resolve();
    img.onerror = () => reject(new Error("A imagem foi salva, mas a URL retornada não pôde ser renderizada."));
    img.src = url;
  });
}

function MediaPanel({ productId, product }: { productId: string; product: ProductDetail }) {
  const qc = useQueryClient();
  const imgInput = useRef<HTMLInputElement>(null);
  const vidInput = useRef<HTMLInputElement>(null);
  const [urlImg, setUrlImg] = useState("");
  const [urlVid, setUrlVid] = useState("");
  const [uploading, setUploading] = useState(false);
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [localImages, setLocalImages] = useState(product.product_images ?? []);

  useEffect(() => {
    const loaded = product.product_images ?? [];
    console.log("[upload imagem] Dados carregados do banco", loaded.map((im) => ({ id: im.id, storage_path: im.storage_path, url: im.url })));
    setLocalImages(loaded);
  }, [product.product_images]);

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["admin-product", productId] });
    qc.invalidateQueries({ queryKey: ["catalog"] });
  };

  const addImgMut = useMutation({
    mutationFn: (v: { url?: string | null; storage_path?: string | null; is_primary?: boolean }) =>
      addProductImage({ data: { product_id: productId, ...v } }),
    onSuccess: (saved) => {
      setLocalImages((prev) => [saved, ...prev.filter((im) => im.id !== saved.id)]);
      refresh();
    },
  });
  const rmImgMut = useMutation({
    mutationFn: (id: string) => removeProductImage({ data: { id } }),
    onSuccess: (_, removedId) => {
      setLocalImages((prev) => prev.filter((im) => im.id !== removedId));
      refresh();
    },
  });
  const primaryMut = useMutation({
    mutationFn: (imgId: string) => setPrimaryImage({ data: { id: imgId, product_id: productId } }),
    onSuccess: refresh,
  });
  const addVidMut = useMutation({
    mutationFn: (v: { url?: string | null; storage_path?: string | null }) =>
      addProductVideo({ data: { product_id: productId, ...v } }),
    onSuccess: refresh,
  });
  const rmVidMut = useMutation({
    mutationFn: (id: string) => removeProductVideo({ data: { id } }),
    onSuccess: refresh,
  });

  const uploadFile = async (file: File, kind: "image" | "video") => {
    setUploading(true);
    setUploadError(null);
    try {
      if (kind === "image") validateImageFile(file);
      const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
      console.log("[upload imagem] Upload iniciado", { name: file.name, type: file.type, size: file.size, kind });
      const up = await createMediaUploadUrl({
        data: { product_id: productId, filename: safeName, kind },
      });
      console.log("[upload imagem] URL de upload retornada", { path: up.path });
      const { data: uploaded, error: uploadErr } = await supabase.storage
        .from("product-media")
        .uploadToSignedUrl(up.path, up.token, file, {
          contentType: file.type || "application/octet-stream",
        });
      if (uploadErr) throw new Error(`Falha no upload para o storage: ${uploadErr.message}`);
      if (!uploaded?.path) throw new Error("Falha no upload: o storage não confirmou o arquivo salvo.");
      console.log("[upload imagem] Upload concluído", uploaded);
      if (kind === "image") {
        const saved = await addImgMut.mutateAsync({ storage_path: up.path });
        console.log("[upload imagem] URL salva no banco", { id: saved.id, storage_path: saved.storage_path, url: saved.url });
        await validateImageUrl(saved.url);
        console.log("[upload imagem] URL usada pelo componente de imagem", saved.url);
        await qc.invalidateQueries({ queryKey: ["admin-product", productId] });
        await qc.invalidateQueries({ queryKey: ["admin-products"] });
        await qc.invalidateQueries({ queryKey: ["catalog"] });
      } else {
        await addVidMut.mutateAsync({ storage_path: up.path });
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : "Erro real não identificado no upload.";
      console.error("[upload imagem] Falha no fluxo", err);
      setUploadError(message);
      throw err;
    } finally {
      setUploading(false);
    }
  };

  const handleImageFile = (file: File) => {
    console.log("[upload imagem] Arquivo selecionado", { name: file.name, type: file.type, size: file.size });
    uploadFile(file, "image").catch(() => undefined);
  };

  const handleVideoFile = (file: File) => {
    uploadFile(file, "video").catch(() => undefined);
  };

  const images = localImages;
  const videos = product.product_videos ?? [];

  return (
    <>
      <Card title="Fotos">
        <div className="grid grid-cols-3 gap-2">
          {images.map((im) => (
            <div key={im.id} className="group relative aspect-square overflow-hidden rounded-lg border border-border bg-surface-elevated">
              <img
                src={im.url}
                alt=""
                className="h-full w-full object-cover"
                onLoad={() => console.log("[upload imagem] URL usada pelo componente de imagem", im.url)}
                onError={() => console.error("[upload imagem] Falha ao renderizar imagem", { id: im.id, storage_path: im.storage_path, url: im.url })}
              />
              {im.is_primary && (
                <span className="absolute left-1 top-1 rounded bg-primary px-1.5 py-0.5 text-[9px] font-bold uppercase text-primary-foreground">
                  Principal
                </span>
              )}
              <div className="absolute inset-0 flex items-center justify-center gap-1 bg-background/70 opacity-0 transition-opacity group-hover:opacity-100">
                {!im.is_primary && (
                  <button
                    onClick={() => primaryMut.mutate(im.id)}
                    className="grid h-8 w-8 place-items-center rounded-lg bg-primary text-primary-foreground"
                    title="Definir como principal"
                  >
                    <Star className="h-3.5 w-3.5" />
                  </button>
                )}
                {im.is_primary && (
                  <span className="grid h-8 w-8 place-items-center rounded-lg bg-surface text-muted-foreground">
                    <StarOff className="h-3.5 w-3.5" />
                  </span>
                )}
                <button
                  onClick={() => rmImgMut.mutate(im.id)}
                  className="grid h-8 w-8 place-items-center rounded-lg bg-destructive text-destructive-foreground"
                >
                  <Trash2 className="h-3.5 w-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        <div className="mt-3 space-y-2">
          <button
            disabled={uploading}
            onClick={() => imgInput.current?.click()}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-border px-3 py-2.5 text-sm text-muted-foreground hover:text-foreground disabled:opacity-50"
          >
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            Enviar foto
          </button>
          <input
            ref={imgInput}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleImageFile(f);
              e.target.value = "";
            }}
          />
          {uploadError && <div className="text-xs text-destructive">{uploadError}</div>}
          <div className="flex gap-2">
            <input
              value={urlImg}
              onChange={(e) => setUrlImg(e.target.value)}
              placeholder="ou cole uma URL de imagem"
              className="h-9 flex-1 rounded-lg border border-border bg-background px-3 text-xs"
            />
            <button
              onClick={() => {
                if (urlImg.trim()) {
                  addImgMut.mutate({ url: urlImg.trim() });
                  setUrlImg("");
                }
              }}
              className="rounded-lg bg-primary px-3 text-xs font-semibold text-primary-foreground"
            >
              Adicionar
            </button>
          </div>
        </div>
      </Card>

      <Card title="Vídeos">
        <div className="space-y-2">
          {videos.map((v) => (
            <div key={v.id} className="flex items-center gap-2 rounded-lg border border-border bg-background p-2 text-xs">
              <Video className="h-4 w-4 text-primary" />
              <a href={v.url} target="_blank" rel="noreferrer" className="flex-1 truncate hover:text-primary">
                {v.title ?? v.url}
              </a>
              <button onClick={() => rmVidMut.mutate(v.id)} className="text-muted-foreground hover:text-destructive">
                <Trash2 className="h-3.5 w-3.5" />
              </button>
            </div>
          ))}
        </div>

        <div className="mt-3 space-y-2">
          <button
            disabled={uploading}
            onClick={() => vidInput.current?.click()}
            className="inline-flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-border px-3 py-2.5 text-sm text-muted-foreground hover:text-foreground disabled:opacity-50"
          >
            {uploading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Upload className="h-4 w-4" />}
            Enviar vídeo
          </button>
          <input
            ref={vidInput}
            type="file"
            accept="video/*"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleVideoFile(f);
              e.target.value = "";
            }}
          />
          <div className="flex gap-2">
            <input
              value={urlVid}
              onChange={(e) => setUrlVid(e.target.value)}
              placeholder="ou cole uma URL de vídeo"
              className="h-9 flex-1 rounded-lg border border-border bg-background px-3 text-xs"
            />
            <button
              onClick={() => {
                if (urlVid.trim()) {
                  addVidMut.mutate({ url: urlVid.trim() });
                  setUrlVid("");
                }
              }}
              className="rounded-lg bg-primary px-3 text-xs font-semibold text-primary-foreground"
            >
              Adicionar
            </button>
          </div>
        </div>
      </Card>
    </>
  );
}

function Card({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-surface p-5">
      <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{title}</div>
      <div className="mt-3">{children}</div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  className = "",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  className?: string;
}) {
  return (
    <label className={`flex flex-col gap-1.5 ${className}`}>
      <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{label}</span>
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-10 rounded-lg border border-border bg-background px-3 text-sm outline-none focus:border-primary"
      />
    </label>
  );
}

function SelectField({
  label,
  value,
  onChange,
  options,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  options: { value: string; label: string }[];
}) {
  return (
    <label className="flex flex-col gap-1.5">
      <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{label}</span>
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="h-10 rounded-lg border border-border bg-background px-3 text-sm outline-none focus:border-primary"
      >
        {options.map((o) => (
          <option key={o.value} value={o.value}>
            {o.label}
          </option>
        ))}
      </select>
    </label>
  );
}
