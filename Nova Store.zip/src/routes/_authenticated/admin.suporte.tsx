import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Search, Send, X, Trash2, Download, CheckCircle2, Loader2 } from "lucide-react";
import {
  listConversations,
  getConversation,
  replyAsAdmin,
  closeConversation,
  deleteConversation,
  getSupportStatus,
  setSupportStatus,
  type SupportConversation,
  type SupportMessage,
} from "@/lib/support.functions";

export const Route = createFileRoute("/_authenticated/admin/suporte")({
  component: AdminSupport,
});

function AdminSupport() {
  const qc = useQueryClient();
  const [q, setQ] = useState("");
  const [activeId, setActiveId] = useState<string | null>(null);
  const [reply, setReply] = useState("");
  const lastCountRef = useRef<number>(0);

  const list = useQuery({
    queryKey: ["support-list", q],
    queryFn: () => listConversations({ data: { q } }),
    refetchInterval: 5000,
  });

  const statusQ = useQuery({
    queryKey: ["support-status"],
    queryFn: () => getSupportStatus(),
  });

  const conv = useQuery({
    queryKey: ["support-conv", activeId],
    queryFn: () => getConversation({ data: { id: activeId! } }),
    enabled: !!activeId,
    refetchInterval: 4000,
  });

  // beep on new admin-side message
  useEffect(() => {
    const total = (list.data ?? []).reduce((acc, c) => acc + (c.unread_admin ?? 0), 0);
    if (total > lastCountRef.current) {
      try {
        const AC = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
        const ctx = new AC();
        const o = ctx.createOscillator();
        const g = ctx.createGain();
        o.frequency.value = 660;
        o.connect(g); g.connect(ctx.destination);
        g.gain.value = 0.04;
        o.start();
        setTimeout(() => { o.stop(); ctx.close(); }, 180);
      } catch {}
    }
    lastCountRef.current = total;
  }, [list.data]);

  const sendMut = useMutation({
    mutationFn: (content: string) => replyAsAdmin({ data: { id: activeId!, content } }),
    onSuccess: () => {
      setReply("");
      qc.invalidateQueries({ queryKey: ["support-conv", activeId] });
      qc.invalidateQueries({ queryKey: ["support-list"] });
    },
  });

  const closeMut = useMutation({
    mutationFn: () => closeConversation({ data: { id: activeId! } }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["support-conv", activeId] });
      qc.invalidateQueries({ queryKey: ["support-list"] });
    },
  });

  const delMut = useMutation({
    mutationFn: (id: string) => deleteConversation({ data: { id } }),
    onSuccess: () => {
      setActiveId(null);
      qc.invalidateQueries({ queryKey: ["support-list"] });
    },
  });

  const statusMut = useMutation({
    mutationFn: (s: "online" | "away" | "offline") => setSupportStatus({ data: { status: s } }),
    onSuccess: () => qc.invalidateQueries({ queryKey: ["support-status"] }),
  });

  const conversations = list.data ?? [];
  const active = conv.data?.conversation;
  const messages = conv.data?.messages ?? [];

  const waiting = useMemo(() => conversations.filter((c) => c.status === "waiting").length, [conversations]);
  const online = useMemo(() => conversations.filter((c) => c.status === "active" || c.status === "waiting").length, [conversations]);

  const exportConv = () => {
    if (!active || !messages) return;
    const lines = [
      `Atendimento: ${active.id}`,
      `Cliente: ${active.customer_name ?? "-"} (${active.customer_phone ?? "-"})`,
      `Email: ${active.customer_email ?? "-"}`,
      `Status: ${active.status}`,
      "",
      ...messages.map((m) => `[${new Date(m.created_at).toLocaleString("pt-BR")}] ${m.sender}: ${m.content}`),
    ];
    const blob = new Blob([lines.join("\n")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `atendimento-${active.id.slice(0, 8)}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="font-display text-2xl font-bold">Suporte ao cliente</h1>
          <p className="text-sm text-muted-foreground">
            {waiting} aguardando · {online} ativos
          </p>
        </div>
        <div className="flex items-center gap-2">
          <span className="text-xs text-muted-foreground">Status do atendimento:</span>
          {(["online", "away", "offline"] as const).map((s) => (
            <button
              key={s}
              onClick={() => statusMut.mutate(s)}
              className={`rounded-lg px-3 py-1.5 text-xs font-semibold ${
                statusQ.data?.status === s
                  ? s === "online"
                    ? "bg-emerald-500 text-white"
                    : s === "away"
                      ? "bg-amber-500 text-white"
                      : "bg-zinc-500 text-white"
                  : "border border-border bg-surface text-muted-foreground"
              }`}
            >
              {s === "online" ? "Online" : s === "away" ? "Ausente" : "Offline"}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-[320px_1fr]">
        {/* List */}
        <div className="rounded-2xl border border-border bg-surface">
          <div className="border-b border-border p-3">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <input
                value={q}
                onChange={(e) => setQ(e.target.value)}
                placeholder="Buscar nome, telefone, e-mail…"
                className="w-full rounded-lg border border-border bg-background py-2 pl-9 pr-3 text-sm"
              />
            </div>
          </div>
          <div className="max-h-[70vh] overflow-y-auto">
            {list.isLoading && <div className="p-4 text-sm text-muted-foreground">Carregando…</div>}
            {!list.isLoading && conversations.length === 0 && (
              <div className="p-6 text-center text-sm text-muted-foreground">Nenhum atendimento.</div>
            )}
            {conversations.map((c: SupportConversation) => (
              <button
                key={c.id}
                onClick={() => setActiveId(c.id)}
                className={`flex w-full flex-col items-start gap-1 border-b border-border px-3 py-2.5 text-left transition-colors hover:bg-surface-elevated ${
                  activeId === c.id ? "bg-surface-elevated" : ""
                }`}
              >
                <div className="flex w-full items-center gap-2">
                  <span className="truncate text-sm font-semibold">
                    {c.customer_name ?? "Visitante"}
                  </span>
                  <span
                    className={`ml-auto rounded-full px-2 py-0.5 text-[10px] font-mono uppercase ${
                      c.status === "waiting"
                        ? "bg-amber-500/20 text-amber-500"
                        : c.status === "active"
                          ? "bg-emerald-500/20 text-emerald-500"
                          : c.status === "closed"
                            ? "bg-zinc-500/20 text-zinc-400"
                            : "bg-primary/20 text-primary"
                    }`}
                  >
                    {c.status}
                  </span>
                  {c.unread_admin > 0 && (
                    <span className="grid h-5 min-w-5 place-items-center rounded-full bg-destructive px-1 text-[10px] font-bold text-destructive-foreground">
                      {c.unread_admin}
                    </span>
                  )}
                </div>
                <div className="truncate text-xs text-muted-foreground">
                  {c.customer_phone ?? c.customer_email ?? "—"}
                </div>
                <div className="text-[10px] text-muted-foreground">
                  {new Date(c.last_message_at).toLocaleString("pt-BR")}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Conversation */}
        <div className="flex min-h-[70vh] flex-col overflow-hidden rounded-2xl border border-border bg-surface">
          {!active ? (
            <div className="grid flex-1 place-items-center text-sm text-muted-foreground">
              Selecione uma conversa.
            </div>
          ) : (
            <>
              <div className="flex items-center gap-3 border-b border-border px-4 py-3">
                <div className="min-w-0 flex-1">
                  <div className="truncate font-semibold">{active.customer_name ?? "Visitante"}</div>
                  <div className="truncate text-xs text-muted-foreground">
                    {active.customer_phone ?? "—"}
                    {active.customer_email ? ` · ${active.customer_email}` : ""}
                  </div>
                </div>
                <button
                  onClick={exportConv}
                  title="Exportar"
                  className="grid h-9 w-9 place-items-center rounded-lg border border-border hover:bg-surface-elevated"
                >
                  <Download className="h-4 w-4" />
                </button>
                <button
                  onClick={() => closeMut.mutate()}
                  disabled={closeMut.isPending || active.status === "closed"}
                  title="Encerrar"
                  className="inline-flex items-center gap-1 rounded-lg border border-border px-3 py-2 text-xs font-semibold hover:bg-surface-elevated disabled:opacity-50"
                >
                  <CheckCircle2 className="h-3.5 w-3.5" /> Encerrar
                </button>
                <button
                  onClick={() => {
                    if (confirm("Excluir esta conversa?")) delMut.mutate(active.id);
                  }}
                  title="Excluir"
                  className="grid h-9 w-9 place-items-center rounded-lg border border-destructive/40 text-destructive hover:bg-destructive/10"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>

              <div className="flex-1 space-y-3 overflow-y-auto bg-background px-4 py-4">
                {messages.map((m: SupportMessage) => {
                  if (m.sender === "system") {
                    return (
                      <div key={m.id} className="text-center text-xs text-muted-foreground">
                        {m.content}
                      </div>
                    );
                  }
                  const right = m.sender === "admin";
                  return (
                    <div key={m.id} className={`flex ${right ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-[75%] rounded-2xl px-3.5 py-2 text-sm ${
                          right
                            ? "bg-primary text-primary-foreground rounded-br-md"
                            : m.sender === "bot"
                              ? "bg-surface-elevated text-muted-foreground border border-border"
                              : "bg-surface border border-border"
                        }`}
                      >
                        <div className="mb-0.5 text-[10px] font-mono uppercase opacity-70">
                          {m.sender}
                        </div>
                        {m.content}
                      </div>
                    </div>
                  );
                })}
              </div>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  if (!reply.trim()) return;
                  sendMut.mutate(reply.trim());
                }}
                className="flex items-center gap-2 border-t border-border bg-surface px-3 py-2.5"
              >
                <input
                  value={reply}
                  onChange={(e) => setReply(e.target.value)}
                  placeholder="Responder…"
                  maxLength={2000}
                  className="flex-1 rounded-xl border border-border bg-background px-3 py-2 text-sm"
                />
                <button
                  type="submit"
                  disabled={!reply.trim() || sendMut.isPending}
                  className="inline-flex h-10 items-center gap-2 rounded-xl bg-primary px-4 text-sm font-semibold text-primary-foreground hover:bg-primary-glow disabled:opacity-50"
                >
                  {sendMut.isPending ? <Loader2 className="h-4 w-4 animate-spin" /> : <Send className="h-4 w-4" />}
                  Enviar
                </button>
              </form>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
