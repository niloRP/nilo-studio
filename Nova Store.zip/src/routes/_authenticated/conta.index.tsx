import { createFileRoute, Link } from "@tanstack/react-router";
import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { BadgeCheck, Calendar, Mail, ShoppingBag, Heart, MapPin } from "lucide-react";
import { useProfile } from "@/lib/use-profile";
import { listMyOrders, listMyFavorites, listMyAddresses } from "@/lib/account.functions";
import { useAuth } from "@/lib/use-auth";

export const Route = createFileRoute("/_authenticated/conta/")({
  component: AccountDashboard,
});

function AccountDashboard() {
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const ordersFn = useServerFn(listMyOrders);
  const favFn = useServerFn(listMyFavorites);
  const addrFn = useServerFn(listMyAddresses);

  const { data: orders = [] } = useQuery({
    queryKey: ["my-orders-count", user?.id],
    queryFn: () => ordersFn(),
    enabled: !!user,
  });
  const { data: favs = [] } = useQuery({
    queryKey: ["my-favorites", user?.id],
    queryFn: () => favFn(),
    enabled: !!user,
  });
  const { data: addrs = [] } = useQuery({
    queryKey: ["my-addresses", user?.id],
    queryFn: () => addrFn(),
    enabled: !!user,
  });

  const initial = (profile?.name ?? profile?.email ?? "U").trim().charAt(0).toUpperCase();
  const since = profile?.created_at
    ? new Date(profile.created_at).toLocaleDateString("pt-BR", { month: "long", year: "numeric" })
    : "—";

  return (
    <div className="space-y-6">
      <div className="rounded-3xl border border-border bg-surface p-6 md:p-8">
        <div className="flex flex-col items-start gap-6 md:flex-row md:items-center">
          {profile?.avatar_url ? (
            <img
              src={profile.avatar_url}
              alt={profile.name ?? ""}
              className="h-20 w-20 rounded-2xl object-cover ring-2 ring-primary/40"
            />
          ) : (
            <div className="grid h-20 w-20 place-items-center rounded-2xl bg-primary font-display text-3xl font-bold text-primary-foreground">
              {initial}
            </div>
          )}
          <div className="flex-1">
            <div className="flex flex-wrap items-center gap-2">
              <h1 className="font-display text-2xl font-bold">{profile?.name ?? "Cliente"}</h1>
              <span className="inline-flex items-center gap-1 rounded-full bg-success/15 px-2 py-0.5 text-[11px] font-semibold text-success">
                <BadgeCheck className="h-3 w-3" /> Cliente Verificado
              </span>
            </div>
            <div className="mt-2 flex flex-wrap gap-4 text-sm text-muted-foreground">
              <span className="inline-flex items-center gap-1.5">
                <Mail className="h-3.5 w-3.5" /> {profile?.email}
              </span>
              <span className="inline-flex items-center gap-1.5">
                <Calendar className="h-3.5 w-3.5" /> Cliente desde {since}
              </span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <StatCard to="/conta/pedidos" icon={ShoppingBag} label="Meus Pedidos" value={orders.length} />
        <StatCard to="/conta/favoritos" icon={Heart} label="Favoritos" value={favs.length} />
        <StatCard to="/conta/enderecos" icon={MapPin} label="Endereços" value={addrs.length} />
      </div>
    </div>
  );
}

function StatCard({
  to,
  icon: Icon,
  label,
  value,
}: {
  to: string;
  icon: typeof ShoppingBag;
  label: string;
  value: number;
}) {
  return (
    <Link
      to={to}
      className="group rounded-2xl border border-border bg-surface p-5 transition-colors hover:border-border-strong hover:bg-surface-elevated"
    >
      <div className="flex items-center justify-between">
        <Icon className="h-5 w-5 text-primary" />
        <span className="font-display text-2xl font-bold">{value}</span>
      </div>
      <div className="mt-2 text-sm text-muted-foreground group-hover:text-foreground">{label}</div>
    </Link>
  );
}
