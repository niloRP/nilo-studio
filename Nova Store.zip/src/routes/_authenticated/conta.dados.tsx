import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { Check, Loader2 } from "lucide-react";
import { useProfile } from "@/lib/use-profile";
import { updateMyProfile } from "@/lib/account.functions";

export const Route = createFileRoute("/_authenticated/conta/dados")({
  component: MyData,
});

const onlyDigits = (v: string) => v.replace(/\D/g, "");
const maskCpf = (v: string) =>
  onlyDigits(v)
    .slice(0, 11)
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
const maskPhone = (v: string) => {
  const d = onlyDigits(v).slice(0, 11);
  if (d.length <= 10) return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{4})(\d)/, "$1-$2");
  return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
};

function MyData() {
  const { data: profile, isLoading } = useProfile();
  const qc = useQueryClient();
  const updateFn = useServerFn(updateMyProfile);
  const [form, setForm] = useState({ name: "", phone: "", cpf: "" });
  const [saved, setSaved] = useState(false);

  useEffect(() => {
    if (profile) {
      setForm({
        name: profile.name ?? "",
        phone: profile.phone ? maskPhone(profile.phone) : "",
        cpf: profile.cpf ? maskCpf(profile.cpf) : "",
      });
    }
  }, [profile]);

  const mutation = useMutation({
    mutationFn: () =>
      updateFn({
        data: {
          name: form.name,
          phone: onlyDigits(form.phone) || undefined,
          cpf: onlyDigits(form.cpf) || undefined,
        },
      }),
    onSuccess: () => {
      setSaved(true);
      setTimeout(() => setSaved(false), 2500);
      qc.invalidateQueries({ queryKey: ["my-profile"] });
    },
  });

  if (isLoading) return <div className="p-8 text-muted-foreground">Carregando…</div>;

  return (
    <div className="rounded-3xl border border-border bg-surface p-6 md:p-8">
      <h1 className="font-display text-2xl font-bold">Meus Dados</h1>
      <p className="mt-1 text-sm text-muted-foreground">Atualize seus dados pessoais.</p>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <Field label="Nome completo" value={form.name} onChange={(v) => setForm({ ...form, name: v })} className="md:col-span-2" />
        <Field label="E-mail" value={profile?.email ?? ""} disabled onChange={() => {}} />
        <Field label="Telefone" value={form.phone} onChange={(v) => setForm({ ...form, phone: maskPhone(v) })} />
        <Field label="CPF" value={form.cpf} onChange={(v) => setForm({ ...form, cpf: maskCpf(v) })} />
      </div>

      {mutation.error && (
        <div className="mt-4 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          {(mutation.error as Error).message}
        </div>
      )}

      <button
        onClick={() => mutation.mutate()}
        disabled={mutation.isPending || form.name.trim().length < 2}
        className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground hover:bg-primary-glow disabled:opacity-50"
      >
        {mutation.isPending && <Loader2 className="h-4 w-4 animate-spin" />}
        {saved && <Check className="h-4 w-4" />}
        {saved ? "Salvo" : "Salvar Alterações"}
      </button>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  className = "",
  disabled = false,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  className?: string;
  disabled?: boolean;
}) {
  return (
    <label className={`flex flex-col gap-1.5 ${className}`}>
      <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{label}</span>
      <input
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
        className="h-11 rounded-xl border border-border bg-background px-3 text-sm outline-none focus:border-primary disabled:opacity-60"
      />
    </label>
  );
}
