import { createFileRoute, Link, Outlet, useNavigate, useRouterState } from "@tanstack/react-router";
import { useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import {
  LayoutDashboard,
  Package,
  ShoppingCart,
  ShieldCheck,
  MessageSquareQuote,
  MessageCircle,
  Settings as SettingsIcon,
  CreditCard,
  Wallet,
  LogOut,
  ShieldAlert,
  Loader2,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { checkIsAdmin } from "@/lib/admin.functions";

export const Route = createFileRoute("/_authenticated/admin")({
  component: AdminLayout,
});

function AdminLayout() {
  const navigate = useNavigate();
  const path = useRouterState({ select: (s) => s.location.pathname });
  const { data, isLoading } = useQuery({
    queryKey: ["is-admin"],
    queryFn: () => checkIsAdmin(),
    retry: false,
  });

  useEffect(() => {
    if (!isLoading && data && !data.isAdmin) {
      const t = setTimeout(() => navigate({ to: "/" }), 1800);
      return () => clearTimeout(t);
    }
  }, [isLoading, data, navigate]);

  if (isLoading) {
    return (
      <div className="grid min-h-[60vh] place-items-center text-muted-foreground">
        <Loader2 className="h-6 w-6 animate-spin" />
      </div>
    );
  }

  if (!data?.isAdmin) {
    return (
      <div className="mx-auto max-w-lg p-8 text-center">
        <div className="mx-auto grid h-14 w-14 place-items-center rounded-2xl bg-destructive/15 text-destructive">
          <ShieldAlert className="h-7 w-7" />
        </div>
        <h1 className="mt-4 font-display text-2xl font-bold">Acesso restrito</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Esta área é exclusiva para administradores autorizados. Redirecionando para a loja…
        </p>
        <button
          onClick={() => navigate({ to: "/" })}
          className="mt-6 inline-flex items-center gap-2 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-glow"
        >
          Ir para a loja
        </button>
        <button
          onClick={async () => {
            await supabase.auth.signOut();
            navigate({ to: "/" });
          }}
          className="mt-4 block w-full text-xs text-muted-foreground hover:text-foreground"
        >
          Sair
        </button>
      </div>
    );
  }

  const links = [
    { to: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
    { to: "/admin/produtos", label: "Produtos", icon: Package },
    { to: "/admin/pedidos", label: "Pedidos", icon: ShoppingCart },
    { to: "/admin/financeiro", label: "Financeiro", icon: Wallet },
    { to: "/admin/pagamentos", label: "Pagamentos", icon: CreditCard },
    { to: "/admin/depoimentos", label: "Depoimentos", icon: MessageSquareQuote },
    { to: "/admin/suporte", label: "Suporte", icon: MessageCircle },
    { to: "/admin/configuracoes", label: "Configurações", icon: SettingsIcon },
    { to: "/admin/admins", label: "Administradores", icon: ShieldCheck },
  ];

  return (
    <div className="mx-auto grid max-w-7xl gap-6 px-4 py-6 md:grid-cols-[220px_1fr] md:px-6">
      <aside className="md:sticky md:top-20 md:self-start">
        <div className="rounded-2xl border border-border bg-surface p-3">
          <div className="px-3 py-2 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
            Painel
          </div>
          <nav className="flex flex-col gap-0.5">
            {links.map((l) => {
              const active = l.exact ? path === l.to : path.startsWith(l.to);
              return (
                <Link
                  key={l.to}
                  to={l.to}
                  className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm transition-colors ${
                    active
                      ? "bg-primary/15 text-primary"
                      : "text-muted-foreground hover:bg-surface-elevated hover:text-foreground"
                  }`}
                >
                  <l.icon className="h-4 w-4" />
                  {l.label}
                </Link>
              );
            })}
          </nav>
          <button
            onClick={async () => {
              await supabase.auth.signOut();
              navigate({ to: "/" });
            }}
            className="mt-3 flex w-full items-center gap-2 rounded-lg border border-border bg-background px-3 py-2 text-sm text-muted-foreground hover:text-foreground"
          >
            <LogOut className="h-4 w-4" />
            Sair
          </button>
        </div>
      </aside>

      <main>
        <Outlet />
      </main>
    </div>
  );
}
