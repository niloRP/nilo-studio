import { createFileRoute } from "@tanstack/react-router";
import { Fragment } from "react";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useState } from "react";
import { ChevronDown, ChevronRight, Loader2 } from "lucide-react";
import { listOrders, updateOrderStatus } from "@/lib/admin.functions";
import { formatBRL, ORDER_STATUSES, type OrderStatus } from "@/lib/products";

export const Route = createFileRoute("/_authenticated/admin/pedidos")({
  component: OrdersAdmin,
});

type Order = {
  id: string;
  code: string;
  customer_name: string;
  customer_phone: string;
  customer_email: string | null;
  total: number | string;
  status: OrderStatus;
  created_at: string;
  order_items: {
    id: string;
    product_name: string;
    qty: number;
    unit_price: number | string;
    subtotal: number | string;
  }[];
};

const statusColor: Record<OrderStatus, string> = {
  aguardando_pagamento: "bg-discount/15 text-discount",
  pago: "bg-success/15 text-success",
  separando: "bg-primary/15 text-primary",
  em_envio: "bg-primary/15 text-primary",
  entregue: "bg-success/15 text-success",
  cancelado: "bg-destructive/15 text-destructive",
};

function OrdersAdmin() {
  const qc = useQueryClient();
  const { data, isLoading } = useQuery({
    queryKey: ["admin-orders"],
    queryFn: () => listOrders(),
  });
  const [expanded, setExpanded] = useState<string | null>(null);

  const mut = useMutation({
    mutationFn: (v: { id: string; status: OrderStatus }) => updateOrderStatus({ data: v }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["admin-orders"] });
      qc.invalidateQueries({ queryKey: ["dashboard"] });
    },
  });

  const orders = (data as Order[] | undefined) ?? [];

  return (
    <div>
      <h1 className="font-display text-2xl font-bold">Pedidos</h1>
      <p className="mt-1 text-sm text-muted-foreground">{orders.length} pedidos recebidos.</p>

      {isLoading && <div className="mt-6 text-sm text-muted-foreground">Carregando…</div>}

      <div className="mt-6 overflow-hidden rounded-2xl border border-border bg-surface">
        <table className="w-full text-sm">
          <thead className="bg-surface-elevated text-left text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
            <tr>
              <th className="p-3" />
              <th className="p-3">Pedido</th>
              <th className="p-3">Cliente</th>
              <th className="p-3">Telefone</th>
              <th className="p-3">Data</th>
              <th className="p-3 text-right">Total</th>
              <th className="p-3">Status</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-border">
            {orders.map((o) => (
              <Fragment key={o.id}>
                <tr className="align-middle">
                  <td className="p-2">
                    <button
                      onClick={() => setExpanded(expanded === o.id ? null : o.id)}
                      className="grid h-7 w-7 place-items-center rounded-lg text-muted-foreground hover:bg-surface-elevated"
                    >
                      {expanded === o.id ? <ChevronDown className="h-4 w-4" /> : <ChevronRight className="h-4 w-4" />}
                    </button>
                  </td>
                  <td className="p-3 font-mono text-xs">{o.code}</td>
                  <td className="p-3">
                    <div className="font-medium">{o.customer_name}</div>
                    {o.customer_email && (
                      <div className="text-xs text-muted-foreground">{o.customer_email}</div>
                    )}
                  </td>
                  <td className="p-3 font-mono">{o.customer_phone}</td>
                  <td className="p-3 text-xs text-muted-foreground">
                    {new Date(o.created_at).toLocaleString("pt-BR")}
                  </td>
                  <td className="p-3 text-right font-mono font-semibold">{formatBRL(Number(o.total))}</td>
                  <td className="p-3">
                    <div className="flex items-center gap-2">
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-bold uppercase ${statusColor[o.status]}`}>
                        {ORDER_STATUSES.find((s) => s.value === o.status)?.label}
                      </span>
                      <select
                        value={o.status}
                        onChange={(e) => mut.mutate({ id: o.id, status: e.target.value as OrderStatus })}
                        className="h-8 rounded-lg border border-border bg-background px-2 text-xs outline-none focus:border-primary"
                      >
                        {ORDER_STATUSES.map((s) => (
                          <option key={s.value} value={s.value}>
                            {s.label}
                          </option>
                        ))}
                      </select>
                      {mut.isPending && mut.variables?.id === o.id && (
                        <Loader2 className="h-3.5 w-3.5 animate-spin text-muted-foreground" />
                      )}
                    </div>
                  </td>
                </tr>
                {expanded === o.id && (
                  <tr>
                    <td colSpan={7} className="bg-surface-elevated p-4">
                      <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                        Itens do pedido
                      </div>
                      <ul className="mt-2 divide-y divide-border">
                        {o.order_items.map((it) => (
                          <li key={it.id} className="flex justify-between gap-3 py-2 text-sm">
                            <span>
                              {it.qty}× {it.product_name}
                            </span>
                            <span className="font-mono">{formatBRL(Number(it.subtotal))}</span>
                          </li>
                        ))}
                      </ul>
                    </td>
                  </tr>
                )}
              </Fragment>
            ))}
            {!isLoading && orders.length === 0 && (
              <tr>
                <td colSpan={7} className="p-10 text-center text-muted-foreground">
                  Nenhum pedido ainda. Faça um pedido de teste na loja.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
