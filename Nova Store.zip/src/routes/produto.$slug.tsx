import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Star, ShieldCheck, Truck, Zap, Minus, Plus, ShoppingBag, CheckCircle2, Heart } from "lucide-react";
import { effectivePrice, formatBRL, type Product } from "@/lib/products";
import { getPublicProductBySlug } from "@/lib/products.functions";
import { useCart } from "@/lib/cart";
import { useFavorites } from "@/lib/use-favorites";
import { registerRecentlyViewed } from "@/lib/account.functions";
import { useAuth } from "@/lib/use-auth";

export const Route = createFileRoute("/produto/$slug")({
  loader: async ({ params }) => {
    const product = await getPublicProductBySlug({ data: { slug: params.slug } });
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => ({
    meta: loaderData
      ? [
          { title: `${loaderData.product.name} — IPHONE SP` },
          { name: "description", content: loaderData.product.short_description ?? "" },
          { property: "og:title", content: `${loaderData.product.name} — IPHONE SP` },
          { property: "og:description", content: loaderData.product.short_description ?? "" },
          { property: "og:image", content: loaderData.product.image },
          { name: "twitter:image", content: loaderData.product.image },
        ]
      : [],
  }),
  component: ProductPage,
  errorComponent: ({ error }) => (
    <div className="p-8 text-center text-sm text-muted-foreground">Erro: {error.message}</div>
  ),
  notFoundComponent: () => (
    <div className="p-8 text-center">
      Produto não encontrado.{" "}
      <Link to="/" className="text-primary">
        Voltar
      </Link>
    </div>
  ),
});

function ProductPage() {
  const { product } = Route.useLoaderData() as { product: Product };
  const [qty, setQty] = useState(1);
  const [activeImg, setActiveImg] = useState(0);
  const { add, setOpen } = useCart();
  const navigate = useNavigate();
  const { user } = useAuth();
  const fav = useFavorites();
  const isFav = fav.isFavorite(product.id);
  const registerFn = useServerFn(registerRecentlyViewed);

  useEffect(() => {
    if (user) {
      registerFn({ data: { product_id: product.id } }).catch(() => {});
    }
  }, [user, product.id, registerFn]);

  const gallery = product.images.length > 0 ? product.images.map((i) => i.url) : [product.image];
  const price = effectivePrice(product);
  const hasPromo = product.promo_price != null && product.promo_price < product.price;
  const discount = hasPromo ? Math.round(((product.price - product.promo_price!) / product.price) * 100) : 0;

  const techSpecs = [
    product.model && { label: "Modelo", value: product.model },
    product.color && { label: "Cor", value: product.color },
    product.storage && { label: "Armazenamento", value: product.storage },
    product.ram && { label: "Memória RAM", value: product.ram },
    { label: "Estado", value: product.condition === "seminovo" ? "Seminovo" : "Novo (Lacrado)" },
    ...product.specs,
  ].filter(Boolean) as { label: string; value: string }[];

  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-6 md:py-10">
      <Link
        to="/"
        className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-muted-foreground hover:text-primary"
      >
        <ArrowLeft className="h-3 w-3" />
        Voltar para a loja
      </Link>

      <div className="mt-6 grid gap-8 md:grid-cols-2 lg:gap-12">
        <div className="flex flex-col gap-3">
          <div className="relative aspect-square overflow-hidden rounded-3xl border border-border bg-surface">
            {product.badge && (
              <span className="absolute left-4 top-4 z-10 rounded-full bg-primary px-3 py-1 text-[10px] font-bold uppercase tracking-wider text-primary-foreground">
                {product.badge}
              </span>
            )}
            <img src={gallery[activeImg]} alt={product.name} className="h-full w-full object-cover" />
          </div>
          {gallery.length > 1 && (
            <div className="grid grid-cols-4 gap-2">
              {gallery.map((g, i) => (
                <button
                  key={i}
                  type="button"
                  onClick={() => setActiveImg(i)}
                  className={`aspect-square overflow-hidden rounded-xl border bg-surface transition-all ${
                    i === activeImg ? "border-primary" : "border-border hover:border-border-strong"
                  }`}
                >
                  <img src={g} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
          )}
          {product.videos.length > 0 && (
            <div className="mt-2 space-y-2">
              {product.videos.map((v) => (
                <video key={v.id} src={v.url} controls className="w-full rounded-xl border border-border bg-surface" />
              ))}
            </div>
          )}
        </div>

        <div className="flex flex-col">
          <div className="flex items-center gap-3 text-[10px] font-mono uppercase tracking-wider text-muted-foreground">
            <span>{product.brand ?? "Loja"}</span>
            <span className="h-1 w-1 rounded-full bg-border-strong" />
            <span>SKU {product.id.slice(0, 8).toUpperCase()}</span>
          </div>

          <h1 className="mt-2 font-display text-3xl font-bold leading-tight md:text-4xl">{product.name}</h1>

          <div className="mt-3 flex items-center gap-3 text-sm">
            <div className="flex items-center gap-1">
              {Array.from({ length: 5 }).map((_, i) => (
                <Star
                  key={i}
                  className={`h-3.5 w-3.5 ${
                    i < Math.round(product.rating) ? "fill-primary text-primary" : "text-border-strong"
                  }`}
                />
              ))}
              <span className="ml-1 font-mono text-xs text-muted-foreground">
                {product.rating.toFixed(1)} · {product.reviews} avaliações
              </span>
            </div>
          </div>

          <p className="mt-4 text-sm text-muted-foreground">{product.short_description}</p>

          <div className="mt-6 rounded-2xl border border-border bg-surface p-5">
            {hasPromo && (
              <div className="flex items-center gap-2 text-sm">
                <span className="text-muted-foreground line-through">{formatBRL(product.price)}</span>
                <span className="rounded-md bg-discount/15 px-2 py-0.5 font-mono text-xs font-semibold text-discount">
                  −{discount}%
                </span>
              </div>
            )}
            <div className="mt-1 flex items-end gap-3">
              <div className="font-display text-4xl font-bold text-price">{formatBRL(price)}</div>
              <span className="mb-1 chip">
                <Zap className="h-3 w-3 fill-primary text-primary" />
                via Pix
              </span>
            </div>
            <div className="mt-1 text-xs text-muted-foreground">Aprovação instantânea · Sem juros · Sem cartão</div>

            <div className="mt-5 flex items-center gap-3">
              <div className="flex items-center rounded-xl border border-border">
                <button
                  type="button"
                  onClick={() => setQty(Math.max(1, qty - 1))}
                  className="grid h-11 w-11 place-items-center text-muted-foreground hover:text-foreground"
                  aria-label="Diminuir"
                >
                  <Minus className="h-4 w-4" />
                </button>
                <span className="w-10 text-center font-mono">{qty}</span>
                <button
                  type="button"
                  onClick={() => setQty(qty + 1)}
                  className="grid h-11 w-11 place-items-center text-muted-foreground hover:text-foreground"
                  aria-label="Aumentar"
                >
                  <Plus className="h-4 w-4" />
                </button>
              </div>
              <button
                type="button"
                disabled={product.stock <= 0}
                onClick={() => {
                  add(
                    {
                      id: product.id,
                      slug: product.slug,
                      name: product.name,
                      brand: product.brand,
                      price,
                      image: product.image,
                    },
                    qty,
                  );
                  setOpen(true);
                }}
                className="flex flex-1 items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3 font-display text-sm font-bold text-primary-foreground transition-all hover:bg-primary-glow hover:shadow-[var(--shadow-glow)] disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <ShoppingBag className="h-4 w-4" />
                {product.stock <= 0 ? "Sem estoque" : "Adicionar ao carrinho"}
              </button>
              <button
                type="button"
                aria-label={isFav ? "Remover dos favoritos" : "Favoritar"}
                onClick={() => {
                  if (!fav.isLoggedIn) {
                    navigate({ to: "/auth" });
                    return;
                  }
                  fav.toggle(product.id);
                }}
                className={`grid h-12 w-12 place-items-center rounded-xl border transition-all ${
                  isFav
                    ? "border-destructive/40 bg-destructive/10 text-destructive"
                    : "border-border bg-background text-muted-foreground hover:text-foreground"
                }`}
              >
                <Heart className={`h-5 w-5 ${isFav ? "fill-current" : ""}`} />
              </button>
            </div>

            {product.stock > 0 ? (
              <div className="mt-4 flex items-center gap-2 text-xs text-success">
                <CheckCircle2 className="h-3.5 w-3.5" />
                Em estoque · {product.stock} unidades · Pronta entrega
              </div>
            ) : (
              <div className="mt-4 text-xs text-destructive">Produto temporariamente sem estoque.</div>
            )}
          </div>

          <ul className="mt-5 grid gap-2 text-sm">
            {[
              { i: Truck, t: "Envio em 24h para todo o Brasil" },
              { i: ShieldCheck, t: "Garantia oficial de 12 meses + Nota Fiscal" },
              { i: Zap, t: "10% extra no Pix já incluso no preço" },
            ].map(({ i: Icon, t }) => (
              <li
                key={t}
                className="flex items-center gap-2 rounded-xl border border-border bg-surface px-3 py-2.5 text-muted-foreground"
              >
                <Icon className="h-4 w-4 text-primary" />
                {t}
              </li>
            ))}
          </ul>
        </div>
      </div>

      {(product.description || techSpecs.length > 0) && (
        <div className="mt-14 grid gap-8 md:grid-cols-[1.3fr_1fr]">
          {product.description && (
            <div>
              <div className="text-[10px] font-mono uppercase tracking-widest text-primary">Sobre o produto</div>
              <h2 className="mt-1 font-display text-2xl font-bold">Descrição completa</h2>
              <p className="mt-4 leading-relaxed text-muted-foreground whitespace-pre-line">{product.description}</p>
            </div>
          )}
          {techSpecs.length > 0 && (
            <div className="rounded-2xl border border-border bg-surface p-5">
              <div className="text-[10px] font-mono uppercase tracking-widest text-primary">Especificações</div>
              <h3 className="mt-1 font-display text-xl font-bold">Ficha técnica</h3>
              <dl className="mt-4 divide-y divide-border">
                {techSpecs.map((s, i) => (
                  <div key={`${s.label}-${i}`} className="flex justify-between gap-4 py-3 text-sm">
                    <dt className="text-muted-foreground">{s.label}</dt>
                    <dd className="font-medium text-foreground text-right">{s.value}</dd>
                  </div>
                ))}
              </dl>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
