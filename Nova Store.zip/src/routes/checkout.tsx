import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";

import { useQuery } from "@tanstack/react-query";
import { useServerFn } from "@tanstack/react-start";
import { ArrowLeft, Copy, Check, Zap, ShieldCheck, Truck, ClipboardList, Loader2, MapPin } from "lucide-react";
import { useCart } from "@/lib/cart";
import { formatBRL } from "@/lib/products";
import { createOrder } from "@/lib/orders.functions";
import { createPixCharge, getPixStatus } from "@/lib/payments.functions";
import { fetchCep } from "@/lib/use-cep";
import { useAuth } from "@/lib/use-auth";
import { useProfile } from "@/lib/use-profile";
import { listMyAddresses, linkOrderToMe } from "@/lib/account.functions";

const onlyDigits = (value: string) => value.replace(/\D/g, "");
const maskCpf = (value: string) =>
  onlyDigits(value)
    .slice(0, 11)
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d)/, "$1.$2")
    .replace(/(\d{3})(\d{1,2})$/, "$1-$2");
const maskPhone = (value: string) => {
  const d = onlyDigits(value).slice(0, 11);
  if (d.length <= 10) return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{4})(\d)/, "$1-$2");
  return d.replace(/(\d{2})(\d)/, "($1) $2").replace(/(\d{5})(\d)/, "$1-$2");
};
const maskCep = (value: string) => onlyDigits(value).slice(0, 8).replace(/(\d{5})(\d)/, "$1-$2");

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout via Pix — IPHONE SPk" },
      { name: "description", content: "Finalize seu pedido com Pix. Aprovação instantânea." },
    ],
  }),
  component: Checkout,
});


function Checkout() {
  const navigate = useNavigate();
  const { detailed, total, items, clear } = useCart();
  const { user } = useAuth();
  const { data: profile } = useProfile();
  const addrFn = useServerFn(listMyAddresses);
  const linkFn = useServerFn(linkOrderToMe);
  const { data: addresses = [] } = useQuery({
    queryKey: ["my-addresses", user?.id],
    queryFn: () => addrFn(),
    enabled: !!user,
  });
  const [selectedAddressId, setSelectedAddressId] = useState<string | "new" | null>(null);
  const [step, setStep] = useState<"dados" | "pix" | "pago">("dados");
  const [copied, setCopied] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [orderCode, setOrderCode] = useState<string>("");
  const [pix, setPix] = useState<{
    reference: string;
    copy_paste: string | null;
    qr_code: string | null;
    amount: number;
    status: string;
  } | null>(null);
  const [form, setForm] = useState({
    name: "",
    document: "",
    phone: "",
    email: "",
    cep: "",
    street: "",
    number: "",
    complement: "",
    neighborhood: "",
    city: "",
    uf: "",
  });
  const [cepLoading, setCepLoading] = useState(false);
  const [cepNotice, setCepNotice] = useState<{ kind: "ok" | "err"; msg: string } | null>(null);
  const numberRef = useRef<HTMLInputElement>(null);
  const lastFetchedCepRef = useRef<string>("");

  // Prefill personal data from profile
  useEffect(() => {
    if (!profile) return;
    setForm((f) => ({
      ...f,
      name: f.name || profile.name || "",
      email: f.email || profile.email || user?.email || "",
      phone: f.phone || (profile.phone ? maskPhone(profile.phone) : ""),
      document: f.document || (profile.cpf ? maskCpf(profile.cpf) : ""),
    }));
  }, [profile, user]);

  // Prefill default address
  useEffect(() => {
    if (selectedAddressId || addresses.length === 0) return;
    const def = addresses.find((a) => a.is_default) ?? addresses[0];
    if (def) {
      setSelectedAddressId(def.id);
      setForm((f) => ({
        ...f,
        cep: maskCep(def.cep),
        street: def.street,
        number: def.number,
        complement: def.complement ?? "",
        neighborhood: def.district,
        city: def.city,
        uf: def.state,
      }));
      lastFetchedCepRef.current = onlyDigits(def.cep);
    }
  }, [addresses, selectedAddressId]);

  const pickAddress = (id: string) => {
    setSelectedAddressId(id);
    setCepNotice(null);
    if (id === "new") {
      setForm((f) => ({
        ...f,
        cep: "",
        street: "",
        number: "",
        complement: "",
        neighborhood: "",
        city: "",
        uf: "",
      }));
      lastFetchedCepRef.current = "";
      return;
    }
    const a = addresses.find((x) => x.id === id);
    if (a) {
      setForm((f) => ({
        ...f,
        cep: maskCep(a.cep),
        street: a.street,
        number: a.number,
        complement: a.complement ?? "",
        neighborhood: a.district,
        city: a.city,
        uf: a.state,
      }));
      lastFetchedCepRef.current = onlyDigits(a.cep);
    }
  };

  // Auto fetch CEP when 8 digits are entered
  useEffect(() => {
    const cep = onlyDigits(form.cep);
    if (cep.length !== 8) {
      if (cep.length === 0) setCepNotice(null);
      return;
    }
    if (lastFetchedCepRef.current === cep) return;
    let active = true;
    setCepLoading(true);
    setCepNotice(null);
    fetchCep(cep)
      .then((r) => {
        if (!active) return;
        lastFetchedCepRef.current = cep;
        setForm((f) => ({
          ...f,
          street: r.logradouro || f.street,
          neighborhood: r.bairro || f.neighborhood,
          city: r.localidade || f.city,
          uf: r.uf || f.uf,
        }));
        setCepNotice({ kind: "ok", msg: "CEP encontrado. Informe o número da residência." });
        setTimeout(() => numberRef.current?.focus(), 60);
      })
      .catch((e) => {
        if (!active) return;
        setCepNotice({ kind: "err", msg: e instanceof Error ? e.message : "Erro ao buscar CEP." });
      })
      .finally(() => {
        if (active) setCepLoading(false);
      });
    return () => {
      active = false;
    };
  }, [form.cep]);


  // QR: usa imagem da VirtualPay se vier base64/url, senão gera a partir do copia-e-cola
  const qrSrc = pix?.qr_code
    ? pix.qr_code.startsWith("data:") || pix.qr_code.startsWith("http")
      ? pix.qr_code
      : `data:image/png;base64,${pix.qr_code}`
    : pix?.copy_paste
      ? `https://api.qrserver.com/v1/create-qr-code/?size=320x320&margin=10&data=${encodeURIComponent(pix.copy_paste)}`
      : "";

  // Polling do status enquanto na etapa pix
  useEffect(() => {
    if (step !== "pix" || !pix?.reference) return;
    let active = true;
    const tick = async () => {
      try {
        const r = await getPixStatus({ data: { reference: pix.reference } });
        if (!active) return;
        if (r.status === "paid") {
          clear();
          setStep("pago");
        } else if (r.status !== pix.status) {
          setPix({ ...pix, status: r.status });
        }
      } catch {}
    };
    const id = setInterval(tick, 4000);
    return () => {
      active = false;
      clearInterval(id);
    };
  }, [step, pix, clear]);

  if (detailed.length === 0 && step === "dados") {
    return (
      <div className="mx-auto flex max-w-md flex-col items-center px-4 py-20 text-center">
        <div className="grid h-16 w-16 place-items-center rounded-2xl bg-surface text-muted-foreground">
          <ClipboardList className="h-7 w-7" />
        </div>
        <h1 className="mt-4 font-display text-2xl font-bold">Seu carrinho está vazio</h1>
        <p className="mt-2 text-sm text-muted-foreground">Adicione produtos para finalizar um pedido.</p>
        <Link
          to="/"
          className="mt-6 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-glow"
        >
          Voltar para a loja
        </Link>
      </div>
    );
  }

  const canContinue =
    form.name.trim().length > 2 &&
    onlyDigits(form.document).length === 11 &&
    onlyDigits(form.phone).length >= 10 &&
    /^\S+@\S+\.\S+$/.test(form.email.trim()) &&
    onlyDigits(form.cep).length === 8 &&
    form.street.trim().length > 1 &&
    form.number.trim().length >= 1 &&
    form.neighborhood.trim().length > 1 &&
    form.city.trim().length > 1 &&
    form.uf.trim().length === 2 &&
    !cepLoading;

  const handleSubmit = async () => {
    if (!form.number.trim()) {
      setError("Informe o número da residência para continuar.");
      numberRef.current?.focus();
      return;
    }
    setSubmitting(true);
    setError(null);
    try {
      const res = await createOrder({
        data: {
          customer_name: form.name.trim(),
          customer_document: onlyDigits(form.document),
          customer_phone: onlyDigits(form.phone),
          customer_email: form.email.trim(),
          address_cep: onlyDigits(form.cep),
          address_street: form.street.trim(),
          address_number: form.number.trim(),
          address_complement: form.complement.trim() || undefined,
          address_neighborhood: form.neighborhood.trim(),
          address_city: form.city.trim(),
          address_uf: form.uf.trim().toUpperCase(),
          items: items.map((i) => ({ product_id: i.id, qty: i.qty })),
        },
      });
      setOrderCode(res.code);
      if (user) {
        linkFn({ data: { order_id: res.id } }).catch(() => {});
      }
      const charge = await createPixCharge({ data: { order_id: res.id } });
      setPix({
        reference: charge.reference,
        copy_paste: charge.copy_paste,
        qr_code: charge.qr_code,
        amount: charge.amount,
        status: charge.status,
      });
      setStep("pix");
    } catch (e) {
      setError(e instanceof Error ? e.message : "Erro ao enviar pedido.");
    } finally {
      setSubmitting(false);
    }
  };


  return (
    <div className="mx-auto max-w-7xl px-4 py-6 md:px-6 md:py-10">
      <Link
        to="/"
        className="inline-flex items-center gap-1.5 text-xs font-mono uppercase tracking-wider text-muted-foreground hover:text-primary"
      >
        <ArrowLeft className="h-3 w-3" />
        Continuar comprando
      </Link>

      <div className="mt-6 flex items-center gap-3">
        {orderCode && <span className="chip">Pedido {orderCode}</span>}
        <Stepper step={step} />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-[1.4fr_1fr]">
        <div className="rounded-3xl border border-border bg-surface p-6 md:p-8">
          {step === "dados" && (
            <>
              <h1 className="font-display text-2xl font-bold">Seus dados</h1>
              <p className="mt-1 text-sm text-muted-foreground">
                Informe os dados do comprador para emissão segura da cobrança Pix.
              </p>

              {user && addresses.length > 0 && (
                <div className="mt-6 rounded-2xl border border-border bg-background p-4">
                  <div className="flex items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                    <MapPin className="h-3 w-3" /> Endereços salvos
                  </div>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {addresses.map((a) => (
                      <button
                        key={a.id}
                        type="button"
                        onClick={() => pickAddress(a.id)}
                        className={`rounded-xl border px-3 py-2 text-left text-xs transition-colors ${
                          selectedAddressId === a.id
                            ? "border-primary bg-primary/10 text-foreground"
                            : "border-border bg-surface text-muted-foreground hover:text-foreground"
                        }`}
                      >
                        <div className="font-semibold text-foreground">{a.label ?? "Endereço"}</div>
                        <div>{a.street}, {a.number} — {a.city}/{a.state}</div>
                      </button>
                    ))}
                    <button
                      type="button"
                      onClick={() => pickAddress("new")}
                      className={`rounded-xl border px-3 py-2 text-xs ${
                        selectedAddressId === "new"
                          ? "border-primary bg-primary/10 text-foreground"
                          : "border-dashed border-border text-muted-foreground hover:text-foreground"
                      }`}
                    >
                      + Novo endereço
                    </button>
                  </div>
                </div>
              )}

              <div className="mt-6 grid gap-4 md:grid-cols-2">
                <Field
                  label="Nome completo *"
                  value={form.name}
                  onChange={(v) => setForm({ ...form, name: v })}
                  className="md:col-span-2"
                />
                <Field
                  label="CPF *"
                  value={form.document}
                  onChange={(v) => setForm({ ...form, document: maskCpf(v) })}
                />
                <Field
                  label="Celular / WhatsApp *"
                  value={form.phone}
                  onChange={(v) => setForm({ ...form, phone: maskPhone(v) })}
                />
                <Field
                  label="E-mail *"
                  type="email"
                  value={form.email}
                  onChange={(v) => setForm({ ...form, email: v })}
                  className="md:col-span-2"
                />
                <div className="md:col-span-2">
                  <Field
                    label="CEP *"
                    value={form.cep}
                    onChange={(v) => setForm({ ...form, cep: maskCep(v) })}
                    placeholder="00000-000"
                  />
                  {cepLoading && (
                    <div className="mt-1 flex items-center gap-1.5 text-[11px] text-muted-foreground">
                      <Loader2 className="h-3 w-3 animate-spin" /> Buscando endereço…
                    </div>
                  )}
                  {cepNotice && (
                    <div
                      className={`mt-1 text-[11px] ${cepNotice.kind === "ok" ? "text-success" : "text-destructive"}`}
                    >
                      {cepNotice.msg}
                    </div>
                  )}
                </div>
                <Field
                  label="Rua *"
                  value={form.street}
                  onChange={(v) => setForm({ ...form, street: v })}
                  className="md:col-span-2"
                />
                <Field
                  label="Número *"
                  value={form.number}
                  onChange={(v) => setForm({ ...form, number: v })}
                  inputRef={numberRef}
                  placeholder="Ex.: 123"
                />
                <Field
                  label="Complemento"
                  value={form.complement}
                  onChange={(v) => setForm({ ...form, complement: v })}
                  placeholder="Apto, bloco, referência"
                />
                <Field
                  label="Bairro *"
                  value={form.neighborhood}
                  onChange={(v) => setForm({ ...form, neighborhood: v })}
                  className="md:col-span-2"
                />
                <Field label="Cidade *" value={form.city} onChange={(v) => setForm({ ...form, city: v })} />
                <Field
                  label="Estado / UF *"
                  value={form.uf}
                  onChange={(v) => setForm({ ...form, uf: v.toUpperCase().slice(0, 2) })}
                />

              </div>

              {error && (
                <div className="mt-4 rounded-xl border border-destructive/40 bg-destructive/10 px-4 py-3 text-sm text-destructive">
                  {error}
                </div>
              )}

              <button
                type="button"
                disabled={!canContinue || submitting}
                onClick={handleSubmit}
                className="mt-8 inline-flex w-full items-center justify-center gap-2 rounded-xl bg-primary px-5 py-3.5 font-display text-sm font-bold text-primary-foreground transition-all hover:bg-primary-glow hover:shadow-[var(--shadow-glow)] disabled:cursor-not-allowed disabled:opacity-50 disabled:hover:shadow-none md:w-auto"
              >
                {submitting ? "Enviando…" : "Gerar Pix"}
                <Zap className="h-4 w-4 fill-current" />
              </button>
            </>
          )}

          {step === "pix" && (
            <div className="flex flex-col items-center text-center">
              <span className="chip">
                {pix?.status === "paid" ? (
                  <>
                    <Check className="h-3 w-3 text-success" />
                    Pago
                  </>
                ) : (
                  <>
                    <Loader2 className="h-3 w-3 animate-spin text-primary" />
                    Aguardando pagamento
                  </>
                )}
              </span>
              <h1 className="mt-3 font-display text-2xl font-bold">Escaneie o QR Code Pix</h1>
              <p className="mt-1 max-w-sm text-sm text-muted-foreground">
                Abra o app do seu banco, escolha pagar com Pix e escaneie o código. Aprovação é instantânea.
              </p>

              {qrSrc ? (
                <div className="relative mt-6 rounded-2xl border border-border-strong bg-surface-elevated p-3">
                  <img src={qrSrc} alt="QR Code Pix" width={280} height={280} className="rounded-xl" />
                  <div className="pointer-events-none absolute inset-x-3 top-3 h-1 rounded-full scanline" />
                </div>
              ) : (
                <div className="mt-6 grid h-[280px] w-[280px] place-items-center rounded-2xl border border-border bg-surface-elevated text-xs text-muted-foreground">
                  Gerando QR Code…
                </div>
              )}

              <div className="mt-4 text-sm">
                Valor: <strong className="text-price">{formatBRL(pix?.amount ?? total)}</strong>
              </div>

              <div className="mt-5 w-full max-w-sm">
                <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
                  Pix Copia e Cola
                </div>
                <button
                  type="button"
                  disabled={!pix?.copy_paste}
                  onClick={async () => {
                    if (!pix?.copy_paste) return;
                    try {
                      await navigator.clipboard.writeText(pix.copy_paste);
                      setCopied(true);
                      setTimeout(() => setCopied(false), 2200);
                    } catch {}
                  }}
                  className="mt-1 flex w-full items-center justify-between gap-2 rounded-xl border border-border bg-background px-3 py-2.5 text-left text-xs font-mono text-muted-foreground hover:border-primary/40 disabled:opacity-60"
                >
                  <span className="truncate">{pix?.copy_paste ?? "—"}</span>
                  {copied ? (
                    <span className="flex items-center gap-1 text-success">
                      <Check className="h-3.5 w-3.5" /> Copiado
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-primary">
                      <Copy className="h-3.5 w-3.5" /> Copiar
                    </span>
                  )}
                </button>
              </div>

              <button
                type="button"
                onClick={async () => {
                  if (!pix?.reference) return;
                  try {
                    const r = await getPixStatus({ data: { reference: pix.reference } });
                    if (r.status === "paid") {
                      clear();
                      setStep("pago");
                    } else {
                      setPix({ ...pix, status: r.status });
                    }
                  } catch {}
                }}
                className="mt-6 inline-flex items-center gap-2 rounded-xl border border-border bg-surface-elevated px-5 py-2.5 text-sm font-semibold hover:bg-surface"
              >
                Já efetuei o pagamento
                <Check className="h-4 w-4" />
              </button>
            </div>
          )}



          {step === "pago" && (
            <div className="flex flex-col items-center py-6 text-center">
              <div className="grid h-16 w-16 place-items-center rounded-2xl bg-success/15 text-success">
                <Check className="h-8 w-8" />
              </div>
              <h1 className="mt-4 font-display text-2xl font-bold">Pedido recebido!</h1>
              <p className="mt-2 max-w-sm text-sm text-muted-foreground">
                Validaremos seu pagamento em instantes. Vamos te contatar pelo telefone informado para confirmar o
                envio.
              </p>
              <div className="mt-5 rounded-xl border border-border bg-background px-4 py-2 font-mono text-sm">
                Pedido <span className="text-primary">{orderCode}</span>
              </div>
              <button
                onClick={() => navigate({ to: "/" })}
                className="mt-6 rounded-xl bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground hover:bg-primary-glow"
              >
                Voltar para a loja
              </button>
            </div>
          )}
        </div>

        <aside className="flex flex-col gap-4">
          <div className="rounded-3xl border border-border bg-surface p-6">
            <div className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
              Resumo do pedido
            </div>
            <ul className="mt-4 divide-y divide-border">
              {detailed.length > 0 ? (
                detailed.map(({ product, qty, subtotal }) => (
                  <li key={product.id} className="flex gap-3 py-3">
                    <img src={product.image} alt="" className="h-14 w-14 rounded-lg object-cover" />
                    <div className="flex-1 text-sm">
                      <div className="line-clamp-1 font-medium">{product.name}</div>
                      <div className="text-xs text-muted-foreground">
                        {qty}× {formatBRL(product.price)}
                      </div>
                    </div>
                    <div className="font-semibold">{formatBRL(subtotal)}</div>
                  </li>
                ))
              ) : (
                <li className="py-6 text-center text-sm text-muted-foreground">Pedido finalizado.</li>
              )}
            </ul>

            <dl className="mt-4 space-y-1.5 border-t border-border pt-4 text-sm">
              <div className="flex justify-between text-muted-foreground">
                <dt>Subtotal</dt>
                <dd>{formatBRL(total)}</dd>
              </div>
              <div className="flex justify-between text-muted-foreground">
                <dt>Frete</dt>
                <dd className="text-success">Grátis</dd>
              </div>
              <div className="flex justify-between border-t border-border pt-3 font-display text-lg font-bold">
                <dt>Total Pix</dt>
                <dd className="text-price">{formatBRL(total)}</dd>
              </div>
            </dl>
          </div>

          <ul className="space-y-2 text-xs text-muted-foreground">
            {[
              { i: Zap, t: "Aprovação instantânea via Pix" },
              { i: Truck, t: "Envio em 24h após confirmação" },
              { i: ShieldCheck, t: "Compra protegida + NF emitida" },
            ].map(({ i: Icon, t }) => (
              <li key={t} className="flex items-center gap-2 rounded-xl border border-border bg-surface px-3 py-2.5">
                <Icon className="h-4 w-4 text-primary" />
                {t}
              </li>
            ))}
          </ul>
        </aside>
      </div>
    </div>
  );
}

function Field({
  label,
  value,
  onChange,
  type = "text",
  className = "",
  onBlur,
  inputRef,
  placeholder,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  type?: string;
  className?: string;
  onBlur?: () => void;
  inputRef?: React.Ref<HTMLInputElement>;
  placeholder?: string;
}) {
  return (
    <label className={`flex flex-col gap-1.5 ${className}`}>
      <span className="text-[10px] font-mono uppercase tracking-widest text-muted-foreground">{label}</span>
      <input
        ref={inputRef}
        type={type}
        value={value}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        onBlur={onBlur}
        className="h-11 rounded-xl border border-border bg-background px-3.5 text-sm text-foreground outline-none transition-colors placeholder:text-muted-foreground focus:border-primary focus:ring-2 focus:ring-ring/30"
      />
    </label>
  );
}


function Stepper({ step }: { step: "dados" | "pix" | "pago" }) {
  const steps = [
    { id: "dados", label: "Dados" },
    { id: "pix", label: "Pix" },
    { id: "pago", label: "Confirmado" },
  ] as const;
  const idx = steps.findIndex((s) => s.id === step);
  return (
    <ol className="flex flex-1 items-center gap-2 text-[10px] font-mono uppercase tracking-widest text-muted-foreground">
      {steps.map((s, i) => (
        <li key={s.id} className="flex flex-1 items-center gap-2">
          <span
            className={`grid h-5 w-5 place-items-center rounded-full border text-[10px] ${
              i <= idx ? "border-primary bg-primary text-primary-foreground" : "border-border-strong"
            }`}
          >
            {i + 1}
          </span>
          <span className={i === idx ? "text-foreground" : ""}>{s.label}</span>
          {i < steps.length - 1 && <span className="h-px flex-1 bg-border" />}
        </li>
      ))}
    </ol>
  );
}
