import { createFileRoute } from "@tanstack/react-router";
import { createHmac, timingSafeEqual } from "crypto";
import { applyStatusChange } from "@/lib/payments.functions";

export const Route = createFileRoute("/api/public/webhooks/virtualpay")({
  server: {
    handlers: {
      POST: async ({ request }) => {
        const { supabaseAdmin } = await import("@/integrations/supabase/client.server");

        const { data: settings } = await supabaseAdmin
          .from("payment_settings")
          .select("webhook_secret,webhook_signature_header,active")
          .eq("id", 1)
          .maybeSingle();

        const rawBody = await request.text();

        // Verifica assinatura HMAC se houver segredo configurado
        if (settings?.webhook_secret) {
          const headerName = (settings.webhook_signature_header || "x-webhook-signature").toLowerCase();
          const provided = request.headers.get(headerName) ?? "";
          const cleaned = provided.replace(/^sha256=/i, "").trim();
          const expected = createHmac("sha256", settings.webhook_secret).update(rawBody).digest("hex");
          try {
            const a = Buffer.from(cleaned, "hex");
            const b = Buffer.from(expected, "hex");
            if (a.length !== b.length || !timingSafeEqual(a, b)) {
              return new Response("invalid signature", { status: 401 });
            }
          } catch {
            return new Response("invalid signature", { status: 401 });
          }
        }

        let payload: any = {};
        try {
          payload = JSON.parse(rawBody);
        } catch {
          return new Response("invalid json", { status: 400 });
        }

        // V2: { event: "transaction.updated", data: { uuid, status, externalRef, ... } }
        const tx = payload?.data ?? payload?.transaction ?? payload;
        const reference: string | undefined =
          tx?.externalRef ?? tx?.external_ref ?? tx?.reference ?? payload?.reference;
        const status: string | undefined = (tx?.status ?? payload?.status ?? "").toLowerCase();

        if (!reference || !status) {
          return new Response("missing fields", { status: 400 });
        }

        const { data: row } = await supabaseAdmin
          .from("pix_transactions")
          .select("id,order_id,reference,status")
          .eq("reference", reference)
          .maybeSingle();
        if (!row) return new Response("not found", { status: 404 });

        if (row.status !== status) {
          await applyStatusChange(row.order_id, row.reference, status, payload);
        }

        return Response.json({ ok: true });
      },
    },
  },
});
