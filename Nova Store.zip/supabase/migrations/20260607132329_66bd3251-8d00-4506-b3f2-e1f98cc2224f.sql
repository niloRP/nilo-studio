
REVOKE EXECUTE ON FUNCTION public.set_updated_at() FROM anon, authenticated;
REVOKE EXECUTE ON FUNCTION public.decrement_stock_on_paid() FROM anon, authenticated;

-- Storage policies for product-media bucket
CREATE POLICY "public read product media"
ON storage.objects FOR SELECT TO anon, authenticated
USING (bucket_id = 'product-media');

CREATE POLICY "admins upload product media"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'product-media' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "admins update product media"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'product-media' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "admins delete product media"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'product-media' AND public.has_role(auth.uid(), 'admin'));
