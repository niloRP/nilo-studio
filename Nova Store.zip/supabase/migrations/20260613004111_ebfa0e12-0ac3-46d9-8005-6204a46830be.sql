
-- 1) payment_settings (singleton)
CREATE TABLE public.payment_settings (
  id INT PRIMARY KEY DEFAULT 1,
  provider TEXT NOT NULL DEFAULT 'virtualpay',
  client_id TEXT,
  client_secret TEXT,
  api_url TEXT NOT NULL DEFAULT 'https://api.virtualpay.com.br/v1',
  webhook_secret TEXT,
  webhook_signature_header TEXT NOT NULL DEFAULT 'x-webhook-signature',
  active BOOLEAN NOT NULL DEFAULT false,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  CONSTRAINT payment_settings_singleton CHECK (id = 1)
);

GRANT SELECT, INSERT, UPDATE ON public.payment_settings TO authenticated;
GRANT ALL ON public.payment_settings TO service_role;

ALTER TABLE public.payment_settings ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins manage payment_settings" ON public.payment_settings
  FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_payment_settings_updated_at
  BEFORE UPDATE ON public.payment_settings
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

INSERT INTO public.payment_settings (id) VALUES (1) ON CONFLICT DO NOTHING;

-- 2) pix_transactions
CREATE TABLE public.pix_transactions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  reference TEXT NOT NULL UNIQUE,
  provider TEXT NOT NULL DEFAULT 'virtualpay',
  transaction_id TEXT,
  amount NUMERIC(10,2) NOT NULL,
  amount_sent INT NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  copy_paste TEXT,
  qr_code TEXT,
  raw_response JSONB,
  paid_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_pix_tx_order ON public.pix_transactions(order_id);
CREATE INDEX idx_pix_tx_transaction ON public.pix_transactions(transaction_id);

GRANT SELECT ON public.pix_transactions TO authenticated;
GRANT ALL ON public.pix_transactions TO service_role;

ALTER TABLE public.pix_transactions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "admins read pix_transactions" ON public.pix_transactions
  FOR SELECT TO authenticated
  USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_pix_tx_updated_at
  BEFORE UPDATE ON public.pix_transactions
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();
