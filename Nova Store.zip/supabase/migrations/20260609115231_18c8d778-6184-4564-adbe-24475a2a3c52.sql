
DROP POLICY IF EXISTS "Public read product-media" ON storage.objects;
CREATE POLICY "Public read product-media"
ON storage.objects FOR SELECT
TO anon, authenticated
USING (bucket_id = 'product-media');
