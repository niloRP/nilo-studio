ALTER TABLE public.orders
ADD COLUMN IF NOT EXISTS customer_document text;

COMMENT ON COLUMN public.orders.customer_document IS 'CPF/documento do cliente usado para cobrança PIX';