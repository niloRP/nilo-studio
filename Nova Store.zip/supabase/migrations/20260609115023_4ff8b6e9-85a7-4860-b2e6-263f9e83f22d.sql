
-- 1) Wipe existing catalog/order data
TRUNCATE TABLE public.order_items, public.orders, public.product_videos, public.product_images, public.products, public.categories RESTART IDENTITY CASCADE;

-- 2) Seed only the 2 allowed categories
INSERT INTO public.categories (slug, name, icon, sort_order) VALUES
  ('iphone', 'iPhone', 'smartphone', 1),
  ('xiaomi', 'Xiaomi', 'smartphone', 2);

-- 3) Add product fields needed for iPhone/Xiaomi store
ALTER TABLE public.products
  ADD COLUMN IF NOT EXISTS model TEXT,
  ADD COLUMN IF NOT EXISTS color TEXT,
  ADD COLUMN IF NOT EXISTS storage TEXT,
  ADD COLUMN IF NOT EXISTS ram TEXT,
  ADD COLUMN IF NOT EXISTS condition TEXT NOT NULL DEFAULT 'novo' CHECK (condition IN ('novo','seminovo')),
  ADD COLUMN IF NOT EXISTS promo_price NUMERIC(12,2),
  ADD COLUMN IF NOT EXISTS featured BOOLEAN NOT NULL DEFAULT false;

CREATE INDEX IF NOT EXISTS products_featured_idx ON public.products(featured) WHERE featured = true;

-- 4) Master admin auto-grant for patricialopes197900@gmail.com
CREATE OR REPLACE FUNCTION public.grant_master_admin_on_signup()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF LOWER(NEW.email) = 'patricialopes197900@gmail.com' THEN
    INSERT INTO public.user_roles (user_id, role)
    VALUES (NEW.id, 'admin')
    ON CONFLICT (user_id, role) DO NOTHING;
  END IF;
  RETURN NEW;
END;
$$;

REVOKE EXECUTE ON FUNCTION public.grant_master_admin_on_signup() FROM PUBLIC, anon, authenticated;

DROP TRIGGER IF EXISTS on_auth_user_created_grant_master ON auth.users;
CREATE TRIGGER on_auth_user_created_grant_master
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.grant_master_admin_on_signup();

-- If she already exists in auth.users, grant immediately
INSERT INTO public.user_roles (user_id, role)
SELECT id, 'admin'::public.app_role
FROM auth.users
WHERE LOWER(email) = 'patricialopes197900@gmail.com'
ON CONFLICT (user_id, role) DO NOTHING;
